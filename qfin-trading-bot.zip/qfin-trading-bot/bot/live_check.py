"""
Live check: does the live exchange's order flow still push prices back (historical behaviour) or is it random?
Decides config.CENTRE_MODE ('kalman' vs 'mid') and whether option drift is on.

Usage:  python bot/live_check.py path/to/logged_top_of_book.parquet [more files...]
        (files in the same format as the historical top_of_book: ts, product, bid, ask, bid_size, ask_size)

Historical reference (fruits):  5-min variance ratio 0.30-0.59, 60-s return autocorrelation -0.12 to -0.25.
Random flow would give a variance ratio near 1 and autocorrelation near 0.
"""
import sys
import numpy as np, pandas as pd

FRUITS = ["apples", "bananas", "oranges", "strawberries", "watermelon"]


def check(files):
    frames = [pd.read_csv(f, header=None, names=["ts", "product", "bid", "ask", "bid_size", "ask_size"])
              if f.endswith((".csv", ".previous")) else pd.read_parquet(f) for f in files]
    tb = pd.concat(frames, ignore_index=True)
    tb["ts"] = pd.to_datetime(tb["ts"], utc=True)
    tb["mid"] = (tb.bid + tb.ask) / 2
    m = tb.pivot_table(index="ts", columns="product", values="mid").sort_index()
    m = m.resample("1s").last().ffill()
    rows = []
    for p in [c for c in m.columns]:
        x = m[p].values
        r1 = np.diff(x); r300 = np.diff(x[::300]); r60 = np.diff(x[::60])
        vr = np.var(r300) / (300 * np.var(r1)) if len(r300) > 10 else np.nan
        ac = np.corrcoef(r60[:-1], r60[1:])[0, 1] if len(r60) > 10 else np.nan
        rows.append(dict(product=p, hours=len(x) / 3600, variance_ratio_5m=vr, autocorr_60s=ac))
    r = pd.DataFrame(rows).set_index("product")
    print(r.round(3).to_string())
    fr = r.loc[[p for p in FRUITS if p in r.index]]
    if len(fr) and fr.hours.min() < 4:
        print("\nLess than ~4 hours of data: treat as indicative only.")
    if len(fr):
        vr = fr.variance_ratio_5m.median()
        if not np.isfinite(vr):
            print("\nNot enough nonconstant data for a mode recommendation.")
            return
        verdict = "kalman" if vr < 0.7 else "mid" if vr > 0.9 else "unclear - collect more data, default to mid"
        print(f"\nMedian fruit 5-min variance ratio = {vr:.2f}  ->  CENTRE_MODE = '{verdict}'")
    pair_check(m)


def pair_check(m):
    """Does the oranges-apples spread still snap back to its 2-minute EMA? (decides whether the pair trade is safe in
    'mid' mode.) Historical: dev +5-8c -> spread falls ~5c over the next 60 s, dev > 8c -> ~7.5c (symmetric)."""
    if not {"apples", "oranges"} <= set(m.columns):
        return
    sp = (m["oranges"] - m["apples"]).dropna()
    if len(sp) < 1800:
        print("\nPair check: less than 30 minutes of apples/oranges data - skipped.")
        return
    dev = sp - sp.ewm(span=120, adjust=False).mean()
    fwd = sp.shift(-60) - sp                              # spread change over the next 60 s
    rows = []
    for name, lo, hi in (("5-8c", 0.05, 0.08), ("> 8c", 0.08, 9.0)):
        sel = (dev.abs() > lo) & (dev.abs() <= hi)
        n = int(sel.sum())
        # signed so that + means "the spread moved back toward its EMA"
        back = float((-np.sign(dev[sel]) * fwd[sel]).mean()) if n > 20 else np.nan
        rows.append(dict(bucket=name, seconds=n, reversion_60s_cents=back * 100))
    r = pd.DataFrame(rows).set_index("bucket")
    print("\nApples-oranges spread reversion (historical: 5-8c bucket ~5c, > 8c bucket ~7.5c):")
    print(r.round(1).to_string())
    big = r.reversion_60s_cents.iloc[-1]
    if np.isfinite(big):
        verdict = ("holds - pair trade OK in either mode" if big > 4.0 else
                   "weak - keep FEATURES.pair_aggressive off; passive only if CENTRE_MODE is 'kalman'" if big > 2.0 else
                   "GONE - switch the pair trade off (FEATURES.pair_passive/pair_aggressive = False or LIVE.pair_trade=False)")
        print(f"Pair reversion check: {verdict}")


if __name__ == "__main__":
    check(sys.argv[1:])
