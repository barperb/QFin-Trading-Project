"""For each 5m window where we sent orders inside the close second (late push), compare the actual settle with the
settle we would have got WITHOUT those orders (= last non-our trade in the close second, else the last trade before it).
Our close-second orders are matched to the tape by (side, avg price, qty) of each of our orders (fills grouped by order_id)."""
import os
import sys, numpy as np, pandas as pd
d = sys.argv[1]; L = os.environ.get('QFIN_LIVE_DATA', 'data/live')
f = pd.read_csv(f'{L}/trades-{d}.csv'); f['t'] = f.time_ms / 1000
f['wo_s'] = pd.to_datetime(f.option_window_open, utc=True, errors='coerce').map(lambda x: x.timestamp() if pd.notna(x) else np.nan)
f['sg'] = np.where(f.side == 'buy', 1, -1)
W = pd.read_parquet(f'{L}/option_windows_{d}.parquet'); W['wo_s'] = W.window_open.map(lambda x: x.timestamp()); W['close_s'] = W.wo_s + W.expiry_min * 60
T = pd.read_parquet(f'{L}/trades_{d}.parquet').reset_index(drop=True)
e = T[T['product'] == 'etf'].copy(); e['s'] = e.ts.map(lambda x: x.timestamp())
opt = f[f['product'] == 'up5']
pos = opt.groupby('wo_s').apply(lambda g: (g.sg * g.qty).sum(), include_groups=False)
etf = f[f['product'] == 'etf']
rows = []
for r in W[W.expiry_min == 5].itertuples():
    c = r.close_s
    mine = etf[(etf.t >= c) & (etf.t < c + 1) & (etf.role == 'taker')]
    if not len(mine):
        continue
    orders = mine.groupby('order_id').apply(lambda g: (g.side.iloc[0], round((g.price * g.qty).sum() / g.qty.sum(), 4), int(g.qty.sum()), g.time_ms.min()), include_groups=False)
    tape = e[e.s == c].copy()
    tape['ours'] = False
    used = set()
    for oid, (side, px, q, tm) in orders.items():
        for i, x in tape.iterrows():
            if i in used: continue
            if x.aggressor == side and abs(round(x.price, 4) - px) < 2e-3 and int(x['size']) == q:
                tape.loc[i, 'ours'] = True; used.add(i); break
    prior = e[e.s < c]
    others = tape[~tape.ours]
    without = others.price.iloc[-1] if len(others) else (prior.price.iloc[-1] if len(prior) else np.nan)
    p = pos.get(r.wo_s, 0)
    win = lambda s: (s >= r.strike) if p > 0 else ((s < r.strike) if p < 0 else np.nan)
    last_is_ours = bool(tape.ours.iloc[-1]) if len(tape) else False
    rows.append(dict(close=pd.Timestamp(c, unit='s'), strike=round(r.strike, 3), settle=round(r.settle, 3), without=round(without, 3),
                     pos=int(p), won=win(r.settle), won_without=win(without), matched=int(tape.ours.sum()), n_our_orders=len(orders),
                     others_after_us=int((~tape.ours).iloc[tape.ours.values.argmax():].sum()) if tape.ours.any() else 0,
                     last_is_ours=last_is_ours))
R = pd.DataFrame(rows)
pd.set_option('display.width', 250)
print(R.to_string(index=False))
h = R[R.pos != 0]
print(f"\n{d}: late-pushed windows {len(h)} | won with late push {h.won.mean():.2f} | would have won without it {h.won_without.mean():.2f}")
print('late push turned loss->win:', int(((h.won == 1) & (h.won_without == 0)).sum()), '| win->loss:', int(((h.won == 0) & (h.won_without == 1)).sum()))
