"""DOWN-mode 5m short replay (v16 cap choice): sweep regime threshold x cap x entry mode on Oct 6-12 books, real outcomes."""
import os
import sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, pandas as pd
from option_replay import load, values
LAD=[(0.0,50),(0.02,100),(0.05,200)]
days=['2026-10-06','2026-10-07','2026-10-08','2026-10-09','2026-10-10','2026-10-11','2026-10-12']
D={}
for d in days:
    O=load(d); vl,vs=values(O); O=O.assign(vs=vs)[O.expiry_min==5]
    W=pd.read_parquet(os.environ.get('QFIN_LIVE_DATA', 'data/live') + f'/option_windows_{d}.parquet'); W=W[W.expiry_min==5].sort_values('window_open')
    seq=list(zip(W.window_open, W.up_won.astype(float)))
    G={wo:g for wo,g in O.groupby('window_open',sort=False)}
    D[d]=(seq,G)
def run(cap, rate, open_min=0.10, edge=0.10, n=12, mn=8, open_on=True, take_on=True):
    out={}
    for d,(seq,G) in D.items():
        tot=0; on=0
        for i,(wo,up) in enumerate(seq):
            h=[u for _,u in seq[max(0,i-n):i]]
            if len(h)<mn or np.mean(h)>rate or wo not in G: continue
            on+=1; g=G[wo]; pos=0; cash=0.0
            left=g.left.values; bid=g.bid.values; bsz=g.bid_size.values; vsv=g.vs.values
            for j in range(len(left)):
                since=300-left[j]
                if open_on and j==0 and since<=60:
                    for off,q in LAD:
                        px=bid[j]-off
                        if pos<cap and px>=open_min and px-vsv[j]>0.0:
                            k=min(q,cap-pos); pos+=k; cash+=k*px
                    continue
                if take_on and pos<cap and bid[j]-vsv[j]>edge:
                    k=min(50,bsz[j],cap-pos); pos+=k; cash+=k*bid[j]
            tot+=cash-pos*up
        out[d[5:]]=round(tot); out[d[5:]+'n']=on
    return out
rows=[]
for rate in (0.25,0.35,0.45):
  for cap in (100,200,350,500,800):
    for mode in ('both','open','take'):
      r=run(cap,rate,open_on=mode!='take',take_on=mode!='open')
      tot=sum(v for k,v in r.items() if not k.endswith('n')); nw=sum(v for k,v in r.items() if k.endswith('n'))
      rows.append(dict(rate=rate,cap=cap,mode=mode,windows_on=nw,total=tot,**{k:v for k,v in r.items() if not k.endswith('n')}))
print(pd.DataFrame(rows).to_string(index=False))
