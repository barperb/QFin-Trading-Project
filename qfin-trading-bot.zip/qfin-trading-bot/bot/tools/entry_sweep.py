"""5m option ENTRY policy sweep on the live option-book replay (take at the touch, real outcomes, cap 500).
Policies: edge by time-left band, and a time-staged cap (max position allowed while more than T s are left)."""
import os
import sys, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, pandas as pd
from option_replay import load, values

def prep(O, vl):
    O = O[O.expiry_min == 5].assign(vl=vl[(O.expiry_min == 5).values])
    W = []
    for wo, g in O.groupby('window_open', sort=False):
        W.append((wo, g.left.values, g.ask.values, g.ask_size.values, g.vl.values, float(g.up_won.iloc[0])))
    return W

def sim(W, bands, stage):
    """bands: [(left_min, edge)] checked in order (first with left > left_min); stage: [(left_min, cap)]"""
    out = []
    for wo, left, ask, asz, vl, up in W:
        pos = 0; cost = 0.0
        for i in range(len(left)):
            L = left[i]
            e = next(ed for lm, ed in bands if L > lm)
            cap = next(c for lm, c in stage if L > lm)
            if pos < cap and vl[i] - ask[i] > e:
                q = min(50, asz[i], cap - pos); pos += q; cost += q * ask[i]
        out.append((wo, pos * up - cost, pos))
    return pd.DataFrame(out, columns=['wo', 'pnl', 'pos'])

days = sys.argv[1:] or ['2026-10-08', '2026-10-09', '2026-10-10']
Ws = {}
for d in days:
    O = load(d); vl, vs = values(O); Ws[d] = prep(O, vl)
pols = {}
pols['v9.1 10c flat'] = ([(-1, .10)], [(-1, 500)])
pols['v10 20c >60s, 10c'] = ([(60, .20), (-1, .10)], [(-1, 500)])
for e1, e2, cut in itertools.product([.15, .20, .25, .30], [.06, .08, .10, .12], [60, 120]):
    pols[f'{e1:.2f} >{cut}s, {e2:.2f}'] = ([(cut, e1), (-1, e2)], [(-1, 500)])
for c1, t1, e in itertools.product([150, 250, 350], [120, 180, 240], [.10, .15]):
    pols[f'stage cap {c1} until {t1}s left, edge {e:.2f}'] = ([(-1, e)], [(t1, c1), (-1, 500)])
for c1, e1 in itertools.product([250, 350], [.15, .20]):
    pols[f'stage {c1}<120s + {e1:.2f}>60s/0.10'] = ([(60, e1), (-1, .10)], [(120, c1), (-1, 500)])
rows = []
for name, (b, s) in pols.items():
    r = {'policy': name}
    hr = []
    for d in days:
        res = sim(Ws[d], b, s); r[d[5:]] = round(res.pnl.sum()); r[f'pos{d[8:]}'] = round(res.pos.mean())
        res['h'] = pd.to_datetime(res.wo).dt.floor('h'); hr.append(res.groupby('h').pnl.sum())
    h = pd.concat(hr); r['total'] = sum(r[d[5:]] for d in days); r['hr_mean'] = round(h.mean()); r['hr_sd'] = round(h.std())
    rows.append(r)
D = pd.DataFrame(rows).sort_values('total', ascending=False)
pd.set_option('display.width', 250)
print(D.head(25).to_string(index=False)); print(D[D.policy.str.startswith('v')].to_string(index=False))
D.to_csv('entry_sweep.csv', index=False)
