"""Close-second forensics for the 5m/60m option windows: who printed the settle, and was it us?

Usage: python3 close_second.py <live_dir> <day YYYY-MM-DD> [from_utc HH:MM]
Inputs in live_dir: trades_<day>.parquet (public tape, 1 s resolution, in exchange order), option_windows_<day>.parquet,
trades-<day>.csv (our fills, ms timestamps, order ids).
A taker order shows on the public tape as ONE trade at its average fill price, so each of our orders = one public row.
Per close (window close C): strike/settle/up_won, our up5/up60 position into the close, our early push (fills in
[C-1.5 s, C)), our late push (fills in [C, C+1 s)), and whether anyone traded ETF after our last print in the close second.
Outcome classes for windows we held long UP:
  won / lost_own_print (our last print was the settle and it was on the wrong side) / lost_after_us (someone printed
  after us) / lost_no_push (we sent nothing in the close second).
"""
import sys

import numpy as np
import pandas as pd

L, DAY = sys.argv[1], sys.argv[2]
FROM = sys.argv[3] if len(sys.argv) > 3 else None
EPOCH = pd.Timestamp('1970-01-01', tz='UTC')


def esec(x):
    """epoch seconds of a tz-aware datetime Series/Timestamp, whatever its resolution (ns/us/ms/s)."""
    return (x - EPOCH) // pd.Timedelta('1s')


tape = pd.read_parquet(f'{L}/trades_{DAY}.parquet')
tape = tape[tape['product'] == 'etf'].reset_index(drop=True)
tape['sec'] = esec(tape.ts)
ow = pd.read_parquet(f'{L}/option_windows_{DAY}.parquet')
ow['wo_s'] = esec(ow.window_open)
ow['close'] = ow.wo_s + ow.expiry_min * 60
fills = pd.read_csv(f'{L}/trades-{DAY}.csv')
fills['t'] = fills.time_ms / 1000.0

# our option position per window (net of buys/sells), from fills
opt = fills[fills['product'].str.startswith('up')].copy()
opt['exp'] = opt['product'].str[2:].astype(int)
opt['wo'] = esec(pd.to_datetime(opt.option_window_open, utc=True))
opt['signed'] = np.where(opt.side == 'buy', opt.qty, -opt.qty)
pos = opt.groupby(['exp', 'wo']).signed.sum()

etf = fills[fills['product'] == 'etf'].copy()
etf['signed'] = np.where(etf.side == 'buy', etf.qty, -etf.qty)
orders = etf.groupby('order_id').agg(t=('t', 'min'), side=('side', 'first'), qty=('qty', 'sum'),
                                       px=('price', lambda s: 0.0), role=('role', 'first')).reset_index()
# average fill price per order (the public print)
vw = etf.assign(pq=etf.price * etf.qty).groupby('order_id').agg(pq=('pq', 'sum'), q=('qty', 'sum'))
orders = orders.set_index('order_id')
orders['px'] = (vw.pq / vw.q).round(4)
orders = orders.reset_index()

rows = []
for _, w in ow.iterrows():
    C = int(w.close)
    if FROM and pd.Timestamp(C, unit='s', tz='UTC') < pd.Timestamp(f'{DAY} {FROM}', tz='UTC'):
        continue
    p = pos.get((int(w.expiry_min), int(w.wo_s)), 0)
    sec = tape[tape.sec == C]
    ours_late = orders[(orders.t >= C) & (orders.t < C + 1) & (orders.role == 'taker')].sort_values('t')
    ours_early = orders[(orders.t >= C - 1.5) & (orders.t < C) & (orders.role == 'taker')]
    # match our late orders to public rows by (price, size), in order
    idx_last_ours = None
    used = set()
    for _, o in ours_late.iterrows():
        cand = sec[(abs(sec.price - o.px) < 1e-3) & (sec['size'] == o.qty)]
        cand = [i for i in cand.index if i not in used]
        if cand:
            used.add(cand[0])
            idx_last_ours = max(idx_last_ours or -1, cand[0])
    after = 0 if idx_last_ours is None else int((sec.index > idx_last_ours).sum())
    last = sec.price.iloc[-1] if len(sec) else np.nan
    rows.append(dict(close=pd.Timestamp(C, unit='s', tz='UTC'), exp=int(w.expiry_min), strike=float(w.strike),
                     settle=float(w.settle), up_won=bool(w.up_won), pos=p, n_sec=len(sec), last=last,
                     early_n=len(ours_early), early_units=int(ours_early.qty.sum()),
                     late_n=len(ours_late), late_units=int(ours_late.qty.sum()),
                     late_last_t=(ours_late.t.max() - C) if len(ours_late) else np.nan,
                     our_last_px=ours_late.sort_values('t').px.iloc[-1] if len(ours_late) else np.nan,
                     after_us=after, matched=idx_last_ours is not None))
R = pd.DataFrame(rows)


def cls(r):
    if r.pos <= 0:
        return 'no_up'
    if r.up_won:
        return 'won'
    if r.late_n == 0:
        return 'lost_no_push'
    if r.matched and r.after_us == 0:
        return 'lost_own_print'
    if r.after_us > 0:
        return 'lost_after_us'
    return 'lost_unmatched'


R['cls'] = R.apply(cls, axis=1)
pd.set_option('display.width', 250)
for exp in (5, 60):
    r = R[R.exp == exp]
    print(f'== {exp}m windows {len(r)}; held UP {int((r.pos > 0).sum())}; classes:', r.cls.value_counts().to_dict())
    held = r[r.pos > 0]
    if len(held):
        print('   late push sent in', int((held.late_n > 0).sum()), 'of', len(held), '; won', int(held.up_won.sum()),
              f'({held.up_won.mean():.0%}); someone printed after our late push in', int((held.after_us > 0).sum()))
        g = held.assign(late=held.late_n > 0).groupby('late').up_won.agg(['count', 'mean'])
        print(g.to_string())
lost = R[R.cls.str.startswith('lost')]
print(lost[['close', 'exp', 'strike', 'settle', 'pos', 'early_units', 'late_units', 'late_last_t', 'our_last_px',
            'after_us', 'n_sec', 'cls']].to_string(index=False))
R.to_csv(f'/tmp/close_second_{DAY}.csv', index=False)
print('saved', f'/tmp/close_second_{DAY}.csv')
