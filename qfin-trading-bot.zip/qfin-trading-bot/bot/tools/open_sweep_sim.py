"""Replay: v10 entry rule vs v10 + an 'open sweep' (first N s of each 5m window: take the house ladder in one go while
model value - level price > e_open, up to X contracts). The recorded book has only the top level, so deeper levels use
the house ladder shape seen live (50 at the ask, 100 at +2c, 200 at +5c). Real outcomes, cap 500."""
import os
import sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, pandas as pd
from option_replay import load, values
LAD = [(0.0, 50), (0.02, 100), (0.05, 200)]

def sim(W, X, e_open, open_s, bands=[(60, .20), (-1, .10)]):
    tot = []
    for wo, left, ask, asz, vl, up in W:
        pos = 0; cost = 0.0; swept = False
        for i in range(len(left)):
            L = left[i]; since = 300 - L
            if X and not swept and since <= open_s:
                swept = True
                for off, q in LAD:
                    px = ask[i] + off
                    if pos < X and vl[i] - px > e_open:
                        n = min(q, X - pos); pos += n; cost += n * px
                continue
            e = next(ed for lm, ed in bands if L > lm)
            if pos < 500 and vl[i] - ask[i] > e:
                n = min(50, asz[i], 500 - pos); pos += n; cost += n * ask[i]
        tot.append(pos * up - cost)
    return np.array(tot)

days = ['2026-10-08', '2026-10-09', '2026-10-10']
Ws = {}
for d in days:
    O = load(d); vl, vs = values(O); O = O.assign(vl=vl)[O.expiry_min == 5]
    Ws[d] = [(wo, g.left.values, g.ask.values, g.ask_size.values, g.vl.values, float(g.up_won.iloc[0]))
             for wo, g in O.groupby('window_open', sort=False)]
rows = []
for X, e, s in [(0, 0, 0)] + [(X, e, s) for X in (150, 350, 500) for e in (0.03, 0.06, 0.10) for s in (2, 5)]:
    r = dict(X=X, e_open=e, open_s=s)
    for d in days:
        r[d[5:]] = round(sim(Ws[d], X, e, s).sum())
    r['total'] = sum(r[d[5:]] for d in days); rows.append(r)
print(pd.DataFrame(rows).sort_values('total', ascending=False).to_string(index=False))
