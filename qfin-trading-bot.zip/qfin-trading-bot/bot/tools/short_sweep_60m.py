"""DOWN-mode 60m short replay: sweep the short cap with model short-takes, real outcomes (Oct 6-12 books)."""
import os
import sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, pandas as pd
from option_replay import load, values
days=['2026-10-06','2026-10-07','2026-10-08','2026-10-09','2026-10-10','2026-10-11','2026-10-12']
D={}
for d in days:
    O=load(d); vl,vs=values(O); O=O.assign(vs=vs)[O.expiry_min==60]
    W=pd.read_parquet(os.environ.get('QFIN_LIVE_DATA', 'data/live') + f'/option_windows_{d}.parquet'); W=W[W.expiry_min==60].sort_values('window_open')
    D[d]=(list(zip(W.window_open,W.up_won.astype(float))),{wo:g for wo,g in O.groupby('window_open',sort=False)})
# 60m history spans days: concatenate
seq=[]; G={}
for d in days: seq+=D[d][0]; G.update(D[d][1])
for rate in (0.2,0.34):
  for cap in (50,100,200,350,500):
    tot=0; on=0
    for i,(wo,up) in enumerate(seq):
        h=[u for _,u in seq[max(0,i-6):i]]
        if len(h)<4 or np.mean(h)>rate or wo not in G: continue
        on+=1; g=G[wo]; pos=0; cash=0.0
        for b,bs,v in zip(g.bid.values,g.bid_size.values,g.vs.values):
            if pos<cap and b-v>0.05: k=min(50,bs,cap-pos); pos+=k; cash+=k*b
        tot+=cash-pos*up
    print(rate,cap,on,round(tot))
