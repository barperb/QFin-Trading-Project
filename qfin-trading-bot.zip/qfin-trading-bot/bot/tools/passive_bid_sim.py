"""5m UP entry: takes (v10 rule) + a resting bid one tick above the best bid, filled by later sell_up trades.
Replay on live books + public option tape, real outcomes, cap 500 shared. Sellers hit the best bid, so a bid at
(best bid of the previous second + 1c) is first in line for every sell_up print at or below it."""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, pandas as pd
from option_replay import load, values
L = os.environ.get('QFIN_LIVE_DATA', 'data/live') + '/'
EPOCH = pd.Timestamp('1970-01-01', tz='UTC')

def run(d, S_list, pedges, bands=[(60, .20), (-1, .10)]):
    O = load(d); vl, vs = values(O)
    O = O.assign(vl=vl)[O.expiry_min == 5]
    T = pd.read_parquet(f'{L}option_trades_{d}.parquet'); T = T[(T.expiry_min == 5) & (T.aggressor == 'sell_up')]
    T['t'] = (T.ts - EPOCH) // pd.Timedelta('1s')
    f = pd.read_csv(f'{L}trades-{d}.csv'); f = f[f['product'] == 'up5']; f['t'] = f.time_ms // 1000
    ours = set(zip(f.t, f.price.round(2)))
    T = T[[ (t, round(p, 2)) not in ours for t, p in zip(T.t, T.price_up)]]
    tr = T.groupby(['window_open', 't']).apply(lambda g: list(zip(g.price_up, g['size']))).to_dict()
    res = {}
    for S in S_list:
        for pe in pedges:
            tot = 0; take = 0; pas = 0; npas = 0
            for wo, g in O.groupby('window_open', sort=False):
                up = float(g.up_won.iloc[0]); pos = 0; cost = 0.0; mybid = None
                for r in g.itertuples():
                    # trades this second hit our resting bid (posted last second)
                    if mybid is not None and S > 0:
                        for p, q in tr.get((wo, r.t), []):
                            if p <= mybid + 1e-9 and pos < 500:
                                f_ = min(q, S, 500 - pos); pos += f_; cost += f_ * mybid; pas += f_ * (up - mybid); npas += f_
                    e = next(ed for lm, ed in bands if r.left > lm)
                    if pos < 500 and r.vl - r.ask > e:
                        q = min(50, r.ask_size, 500 - pos); pos += q; cost += q * r.ask; take += q * (up - r.ask)
                    b = round(r.bid + 0.01, 2)
                    mybid = b if (b < r.ask and r.vl - b > pe and pos < 500) else None
                tot += pos * up - cost
            res[(S, pe)] = (round(tot), round(take), round(pas), npas)
    return res

days = sys.argv[1:] or ['2026-10-08', '2026-10-09', '2026-10-10']
S_list = [0, 10, 25, 50]; pedges = [0.05, 0.10, 0.15]
allr = {d: run(d, S_list, pedges) for d in days}
rows = []
for k in allr[days[0]]:
    r = dict(size=k[0], edge=k[1])
    for d in days:
        r[d[5:]] = allr[d][k][0]; r[f'pas{d[8:]}'] = allr[d][k][2]; r[f'npas{d[8:]}'] = allr[d][k][3]
    r['total'] = sum(allr[d][k][0] for d in days); rows.append(r)
pd.set_option('display.width', 250)
print(pd.DataFrame(rows).sort_values('total', ascending=False).to_string(index=False))
