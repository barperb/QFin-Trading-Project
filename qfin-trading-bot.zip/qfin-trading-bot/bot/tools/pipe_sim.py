"""Drive the real SDK pipe transport (QFIN_BACKTEST=1) like the hosted platform: one tick per real second, state stamped
with the real clock, a 5m window whose close falls inside the run, our position long 500 UP with the strike above the ETF
ask (so a push is needed). Records every API call with its timing relative to the tick, and on_tick durations.
Optionally makes one batch call 'stall' for STALL seconds to exercise the cooldown."""
import os, sys, json, time, selectors, subprocess, copy
from pathlib import Path
BOT = Path(sys.argv[1]); KIT = sys.argv[2]; STALL_AT = int(sys.argv[3]) if len(sys.argv) > 3 else -1; STALL = float(sys.argv[4]) if len(sys.argv) > 4 else 0
sys.path.insert(0, str(BOT / "tests")); sys.path.insert(0, str(BOT)); sys.path.insert(0, KIT)
import test_live_adapter as T

start = int(time.time()) + 2
close = (start // 300 + 1) * 300 if (start // 300 + 1) * 300 - start <= 8 else start + 6   # a close ~6 s after start
wo = close - 300
def mkstate(sec_float, pos=500):
    raw = T.state(ts=int(sec_float), positions={"up5": pos, "etf": 0})
    for p in raw["products"]:
        if p["symbol"] == "up5":
            p["option"].update(windowOpen=wo, windowClose=close, strike=50.10)
        if p["symbol"] == "up60":
            p["option"].update(windowOpen=close - 3600, windowClose=close + 3600)
    raw["serverTime"] = int(sec_float * 1000)
    raw["account"]["dayEnd"] = (close + 8 * 3600) * 1000
    raw["books"]["etf"] = {"bids": [{"price": 49.95, "qty": 3}, {"price": 49.90, "qty": 20}],
                           "asks": [{"price": 50.05, "qty": 3}, {"price": 50.08, "qty": 4},
                                    {"price": 50.12, "qty": 10}, {"price": 50.20, "qty": 30}], "lastTradePrice": 50.0}
    return raw

inr, inw = os.pipe(); outr, outw = os.pipe()
script = f"import os,runpy;os.dup2({inr},3);os.dup2({outw},4);runpy.run_path({str(BOT/'bot.py')!r},run_name='__main__')"
env = dict(os.environ, QFIN_BACKTEST="1", PYTHONPATH=f"{KIT}:{BOT}")
proc = subprocess.Popen([sys.executable, "-c", script], cwd=str(BOT), env=env, pass_fds=(inr, outw),
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
os.close(inr); os.close(outw)
src = os.fdopen(inw, "w"); dst = os.fdopen(outr, "r")
sel = selectors.DefaultSelector(); sel.register(dst, selectors.EVENT_READ)
def recv(timeout=10):
    if not sel.select(timeout): raise SystemExit("timeout")
    line = dst.readline()
    if not line: raise SystemExit("bot exited")
    return json.loads(line)
assert recv()["type"] == "ready"
log = []; ncall = 0
for sec in range(start, close + 4):
    while time.time() < sec + 0.05: time.sleep(0.005)
    t_tick = time.time()
    src.write(json.dumps({"type": "tick", "state": mkstate(t_tick)}) + "\n"); src.flush()
    while True:
        m = recv()
        if m["type"] == "done":
            log.append(dict(sec=sec - close, kind="done", t=round(time.time() - t_tick, 3))); break
        if m["type"] == "call":
            ncall += 1
            acts = (m.get("body") or {}).get("actions", [])
            log.append(dict(sec=sec - close, kind="call", t=round(time.time() - t_tick, 3), path=m["path"],
                            n=len(acts), first=[(a.get("type"), a.get("side"), a.get("qty"), a.get("price"), a.get("orderType"))
                                                for a in acts if a.get("productId") in ("etf", None) or a.get("type") == "cancelAll"][:6]))
            if ncall == STALL_AT: time.sleep(STALL)
            src.write(json.dumps({"status": 200, "body": [{"status": "ok"} for _ in acts]}) + "\n"); src.flush()
src.write('{"type":"end"}\n'); src.flush()
out, err = proc.communicate(timeout=15)
for r in log: print(r)
print("STDOUT:", out.decode()[-1500:]); print("STDERR:", err.decode()[-1500:])
