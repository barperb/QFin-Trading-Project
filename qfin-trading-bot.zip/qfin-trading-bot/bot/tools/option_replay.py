"""Replay our live option books (take at the touch, real outcomes) with variants of the option model.
Outcomes are the realised ones, i.e. they include whatever pushing happened that day (mostly UP pushes by us and others),
so DOWN-side results are pessimistic and UP-side results optimistic about the close-second fight.
Usage: python3 option_replay.py   (edit CONFIGS below)"""
import os
import json, sys, numpy as np, pandas as pd
from scipy import stats
from scipy.special import ndtr
L = os.environ.get('QFIN_LIVE_DATA', 'data/live') + '/'
P = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'option_params.json')))
mm = np.array(P['minute_var_mult']); hm = np.array(P['hour_var_mult']); sig2 = P['sigma_per_sqrt_s'] ** 2
w = np.array([mm[(s // 60) % 60] * hm[s // 3600] for s in range(86400)]); w /= w.mean()
cum = np.r_[0, np.cumsum(np.tile(w, 2))]
noise = np.array(P['settle_noise_quantiles'])
FR = ['apples', 'bananas', 'oranges', 'strawberries', 'watermelon']

def load(d):
    O = pd.read_parquet(f'{L}option_top_of_book_{d}.parquet'); W = pd.read_parquet(f'{L}option_windows_{d}.parquet')
    B = pd.read_parquet(f'{L}top_of_book_{d}.parquet').drop_duplicates(['ts', 'product'], keep='last')
    mid = B.assign(m=(B.bid + B.ask) / 2).pivot(index='ts', columns='product', values='m').sort_index()
    sp = B.assign(h=(B.ask - B.bid) / 2).pivot(index='ts', columns='product', values='h').sort_index()
    mid = mid.reindex(pd.date_range(mid.index.min(), mid.index.max(), freq='1s')).ffill(); sp = sp.reindex(mid.index).ffill()
    O = O.merge(W[['expiry_min', 'window_open', 'strike', 'up_won']], on=['expiry_min', 'window_open'])
    O = O[O.ts.isin(mid.index)]
    O['mid'] = mid['etf'].reindex(O.ts).values; O['basket'] = mid[FR].sum(axis=1).reindex(O.ts).values
    O['half'] = sp['etf'].reindex(O.ts).values
    O['t'] = O.ts.astype('int64') // 10**9
    O['left'] = O.window_open.astype('int64') // 10**9 + O.expiry_min * 60 - O.t
    O = O[(O.left > 5) & O.bid.notna() & O.ask.notna()].sort_values(['expiry_min', 'window_open', 't'])
    O['sod'] = O.t % 86400
    O['sd'] = np.sqrt(sig2 * (cum[O.sod.values + O.left.values] - cum[O.sod.values]))
    return O

def values(O, bias=0.012, drift={5: 0.8, 60: 0.3}, nu60=8, pw={5: 0.72, 60: 0.53}, reach=0.10):
    exp = O.expiry_min.values
    dr = np.where(exp == 5, drift[5], drift[60])
    x = (O.mid - O.strike + bias).values + dr * (O.basket - O.mid).values * np.minimum(1, O.left.values / 60)
    sd = O.sd.values
    def F(a):
        r = ndtr(a); m = exp == 60
        r[m] = stats.t.cdf(a[m] * np.sqrt(nu60 / (nu60 - 2)), nu60)
        return r
    pfree = F((x[:, None] + noise[None, :]) / sd[:, None]).mean(1)
    p = np.where(exp == 5, pw[5], pw[60]); h = O.half.values + reach
    return p * F((x + h) / sd) + (1 - p) * pfree, p * F((x - h) / sd) + (1 - p) * pfree

def sim(O, vl, vs, edge={5: 0.10, 60: 0.05}, short_edge={5: 9, 60: 9}, cap=500, short_cap={5: 0, 60: 0}):
    """Long UP when vl - ask > edge; short UP (= long DOWN) when bid - vs > short_edge, up to short_cap."""
    res = []
    O = O.assign(vl=vl, vs=vs)
    for (e, wo), g in O.groupby(['expiry_min', 'window_open'], sort=False):
        pos = 0; cash = 0.0; cl = 0.0; cs = 0.0; ql = 0; qs = 0
        for r in g.itertuples():
            if pos >= 0 and pos < cap and r.vl - r.ask > edge[e]:
                q = min(50, r.ask_size, cap - pos); pos += q; cash -= q * r.ask; cl -= q * r.ask; ql += q
            elif pos <= 0 and -pos < short_cap[e] and r.bid - r.vs > short_edge[e]:
                q = min(50, r.bid_size, short_cap[e] + pos); pos -= q; cash += q * r.bid; cs += q * r.bid; qs += q
        up = float(g.up_won.iloc[0])
        res.append(dict(exp=e, wo=wo, pnl=cash + pos * up, long_pnl=cl + ql * up, short_pnl=cs - qs * up, ql=ql, qs=qs, up=up))
    return pd.DataFrame(res)

if __name__ == '__main__':
    days = sys.argv[1:] or ['2026-10-07', '2026-10-08', '2026-10-09', '2026-10-10']
    Os = {d: load(d) for d in days}
    CONFIGS = [
        ('v9 (UP only)', dict(), dict()),
        ('+ DOWN 5m edge 15c cap 100', dict(), dict(short_edge={5: 0.15, 60: 9}, short_cap={5: 100, 60: 0})),
        ('+ DOWN 5m edge 15c cap 500', dict(), dict(short_edge={5: 0.15, 60: 9}, short_cap={5: 500, 60: 0})),
        ('+ DOWN 5m edge 10c cap 500', dict(), dict(short_edge={5: 0.10, 60: 9}, short_cap={5: 500, 60: 0})),
        ('+ DOWN 5m edge 20c cap 500', dict(), dict(short_edge={5: 0.20, 60: 9}, short_cap={5: 500, 60: 0})),
    ]
    rows = []
    for name, vk, sk in CONFIGS:
        r = {'config': name}
        for d in days:
            vl, vs = values(Os[d], **vk); s = sim(Os[d], vl, vs, **sk)
            r[f'{d[5:]} 5m'] = round(s[s.exp == 5].pnl.sum()); r[f'{d[5:]} 5m DOWN'] = round(s[s.exp == 5].short_pnl.sum())
            r[f'{d[5:]} 60m'] = round(s[s.exp == 60].pnl.sum())
        r['total'] = sum(v for k, v in r.items() if k.endswith('5m') or k.endswith('60m'))
        rows.append(r); print(r, flush=True)
    pd.set_option('display.width', 300)
    print(pd.DataFrame(rows).to_string(index=False))
