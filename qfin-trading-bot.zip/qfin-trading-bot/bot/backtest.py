"""
backtest.py - replay historical days second by second through the bot, with PnL attribution by strategy.

Run from the "QFin Project" folder (data under qfin_project_data/members/):
    python bot/backtest.py 2026-02-12 2026-03-08                 # specific days
    python bot/backtest.py --share 0.25 2026-02-12               # competition: we win 1/4 of eligible flow
    python bot/backtest.py --mode mid 2026-02-12                 # random-flow mode (centre on mid)
    python bot/backtest.py --disable pair_lean,long_run 2026-02-12   # switch features off (see config.FEATURES)
    python bot/backtest.py --set OPTIONS.take_edge=0.04 2026-02-12   # override any config value (tuning)

FILL RULES (simplified - read before trusting $)
  * Resting fruit/ETF quotes: a historical aggressor trade in the next second fills against us first if our
    price is strictly better than the historical best price, for share x its size.
  * Resting option quotes: same rule against historical option trades.
  * Option take orders: fill at the quoted touch, share x qty.
  * IOC fruit/ETF orders (hedge, flatten, nudge): fill at the touch; beyond the displayed size we pay the market
    maker's impact (0.06c/0.09c/0.19c per unit).
  * Settle nudge: our 1-lot sets the settle only if nobody else traded ETF in the close second.
  * Pair trade (FEATURES.pair_passive / pair_aggressive): passive = target inventories steer the normal quotes (same fill
    rules as any quote); aggressive = 'pair' IOCs, both legs the same size, capped at the displayed touch size of both
    legs so they fill fully at the touch. Our own price impact is NOT modelled (like every other order here).
  * Settle push: push orders walk a synthetic ETF book (config SETTLE_PUSH.ladder); the last order's average fill
    price becomes the settle only if nobody else traded ETF in the close second. The price displacement paid is
    charged a second time for unwinding the ETF (SETTLE_PUSH.unwind_mult).
  * The historical market-maker price path is NOT changed by our trading (optimistic) and the historical book
    contains no other teams (competition is approximated by --share).
"""
import sys, os, argparse
from types import SimpleNamespace
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config as C
from strategy import Bot
from pnl_tracker import PnLTracker

D = "qfin_project_data/members/"
LAMBDA = {"apples": 0.0006, "bananas": 0.0006, "oranges": 0.0006, "strawberries": 0.0006,
          "watermelon": 0.0009, "etf": 0.0019}       # market-maker price impact per unit traded


def _index_by_second(sec, n):
    """start[t]..start[t+1] = rows that happened in second t (rows must be sorted by time)."""
    return np.searchsorted(sec, np.arange(n + 1))


def load(day):
    tb = pd.read_parquet(f"{D}top_of_book/date={day}.parquet")
    tr = pd.read_parquet(f"{D}trades/date={day}.parquet")
    ob = pd.read_parquet(f"{D}option_top_of_book/date={day}.parquet")
    ot = pd.read_parquet(f"{D}option_trades/date={day}.parquet")
    ow = pd.read_parquet(f"{D}option_windows/date={day}.parquet")
    idx = pd.DatetimeIndex(tb[tb["product"] == "etf"].ts)
    t0, n = idx[0], len(idx)
    books = {p: tb[tb["product"] == p][["bid", "ask", "bid_size", "ask_size"]].values for p in C.PRODUCTS}
    trades = {}
    for p in C.PRODUCTS:
        g = tr[tr["product"] == p]
        sec = ((g.ts - t0).dt.total_seconds()).astype(int).values
        trades[p] = (g.price.values, g["size"].values.astype(float), g.aggressor.values == "buy",
                     _index_by_second(sec, n))
    opts, otr = {}, {}
    for e in C.OPTION_EXPIRIES:
        o = ob[ob.expiry_min == e]
        opts[e] = (o.bid.values, o.ask.values, list(o.window_open))
        g = ot[ot.expiry_min == e]
        sec = ((g.ts - t0).dt.total_seconds()).astype(int).values
        otr[e] = (g["size"].values.astype(float), g.aggressor.values == "buy_up", _index_by_second(sec, n))
    win = {(int(r.expiry_min), pd.Timestamp(r.window_open)): (float(r.strike), bool(r.up_won))
           for r in ow.itertuples() if r.expiry_min in C.OPTION_EXPIRIES}
    return idx, books, trades, opts, otr, win


def run_day(day, share=1.0, mode=C.CENTRE_MODE, features=None, push_fail=0.0, seed=0):
    idx, books, trades, opts, otr, win = load(day)
    bot = Bot(centre_mode=mode, features=features)
    pnl = PnLTracker()
    inv = {p: 0.0 for p in C.PRODUCTS}             # total inventory (all tags)
    optpos = {}                                    # (exp, wo) -> contracts
    nudged = {}                                    # close second -> our print price
    pending = None
    rng = np.random.default_rng(seed)
    # v8 straw_flow: per-second count of strawberry size-150 BUYS, cumulative, lagged 60 s (the live tape is ~1 min old)
    pr_s, sz_s, isbuy_s, st_s = trades["strawberries"]
    hit = ((sz_s == C.STRAW_FLOW["clip_size"]) & isbuy_s).astype(int)
    per_sec = np.add.reduceat(np.r_[hit, 0], st_s[:-1]) * (np.diff(st_s) > 0) if len(hit) else np.zeros(len(idx))
    cum150 = np.r_[0, np.cumsum(per_sec)]
    for t in range(len(idx)):
        ts = idx[t]
        # ------------------------------------------------------------ 1. execute last second's actions
        if pending is not None:
            # resting fruit / ETF quotes vs historical aggressors
            for p, (b, qb, a, qa) in pending.quotes.items():
                bb, ba = books[p][t - 1][0], books[p][t - 1][1]
                pr, sz, isbuy, st = trades[p]
                for k in range(st[t], st[t + 1]):
                    if isbuy[k] and qa > 0 and a < ba - 1e-9:
                        f = min(qa, sz[k] * share); qa -= f; inv[p] -= f; pnl.fill(f"mm_{p}", p, "-", f, a)
                    elif (not isbuy[k]) and qb > 0 and b > bb + 1e-9:
                        f = min(qb, sz[k] * share); qb -= f; inv[p] += f; pnl.fill(f"mm_{p}", p, "+", f, b)
            # resting option quotes vs historical option aggressors
            for e, (wo, b, nb, a, na) in pending.option_quotes.items():
                ob_, oa_ = opts[e][0][t - 1], opts[e][1][t - 1]
                if pd.Timestamp(opts[e][2][t]) != wo:
                    continue                                   # window rolled over
                sz, isbuy, st = otr[e]
                for k in range(st[t], st[t + 1]):
                    if isbuy[k] and na > 0 and a < oa_ - 1e-9:
                        f = min(na, sz[k] * share); na -= f
                        optpos[(e, wo)] = optpos.get((e, wo), 0) - f; pnl.option_fill(f"opt_quote_{e}", e, wo, "-", f, a)
                    elif (not isbuy[k]) and nb > 0 and b > ob_ + 1e-9:
                        f = min(nb, sz[k] * share); nb -= f
                        optpos[(e, wo)] = optpos.get((e, wo), 0) + f; pnl.option_fill(f"opt_quote_{e}", e, wo, "+", f, b)
            # option take orders
            for e, wo, side, qty, px, tag in pending.option_orders:
                q = qty * share
                optpos[(e, wo)] = optpos.get((e, wo), 0) + (q if side == "+" else -q)
                pnl.option_fill(tag, e, wo, side, q, px)
            # settle push: walk a synthetic ETF ladder (config SETTLE_PUSH.ladder) built from the touch
            pushes = [x for x in pending.ioc if x[4] == "push"]
            if pushes:
                from strategy import synthetic_ladder
                bb, ba = books["etf"][t - 1][0], books["etf"][t - 1][1]
                lb, la = synthetic_ladder(bb, ba)
                ladder = {"+": [list(x) for x in la], "-": [list(x) for x in lb]}
                mid0 = (bb + ba) / 2
                last_print = None
                for p, side, qty, px, tag in pushes:
                    need, cost, disp = qty, 0.0, 0.0
                    for lvl in ladder[side]:
                        if need <= 0:
                            break
                        if (side == "+" and lvl[0] > px + 1e-9) or (side == "-" and lvl[0] < px - 1e-9):
                            break                              # limit reached
                        f = min(need, lvl[1]); lvl[1] -= f; need -= f
                        cost += f * lvl[0]; disp += f * abs(lvl[0] - mid0)
                    ladder[side] = [l for l in ladder[side] if l[1] > 0]
                    done = qty - need
                    if done <= 0:
                        continue
                    avg = cost / done
                    inv["etf"] += done if side == "+" else -done
                    pnl.fill("push", "etf", side, done, avg)
                    pnl.cash["push"] -= C.SETTLE_PUSH["unwind_mult"] * disp   # unwinding costs the displacement again
                    pnl.count["push_units"] += done
                    last_print = avg
                pr, sz, isbuy, st = trades["etf"]
                # our print sets the settle only if nobody else traded ETF this second, and (stress test)
                # another team doesn't out-push us (--push-fail probability)
                if last_print is not None and st[t] == st[t + 1] and rng.random() >= push_fail:
                    nudged[ts] = last_print
                pnl.count["pushes"] += 1
            # immediate fruit / ETF orders
            for p, side, qty, px, tag in [x for x in pending.ioc if x[4] != "push"]:
                bb, ba, bs, as_ = books[p][t - 1]
                touch, depth = (ba, as_) if side == "+" else (bb, bs)
                if (side == "+" and px < touch - 1e-9) or (side == "-" and px > touch + 1e-9):
                    continue                                   # limit no longer marketable
                extra = max(0.0, qty - depth)
                avg = touch + (1 if side == "+" else -1) * LAMBDA[p] * extra * extra / (2 * qty)
                inv[p] += qty if side == "+" else -qty
                pnl.fill(tag, p, side, qty, avg)
                if tag == "nudge":
                    pnl.count["nudges"] += 1
                    pr, sz, isbuy, st = trades["etf"]
                    if st[t] == st[t + 1]:                     # nobody else traded ETF this second
                        nudged[ts] = touch
        # ------------------------------------------------------------ 2. settle options closing now
        for key in [k for k in optpos if k[1] + pd.Timedelta(minutes=k[0]) == ts]:
            e, wo = key
            if (e, wo) in win:
                strike, up = win[(e, wo)]
                if ts in nudged:
                    new_up = nudged[ts] >= strike
                    pnl.count["flips"] += int(new_up != up); up = new_up
                pnl.option_settle(e, wo, up)
            optpos.pop(key)
        # ------------------------------------------------------------ 3. snapshot -> bot
        bk = {p: tuple(books[p][t]) for p in C.PRODUCTS}
        mids = {p: (v[0] + v[1]) / 2 for p, v in bk.items()}
        options = {e: (opts[e][0][t], opts[e][1][t], pd.Timestamp(opts[e][2][t])) for e in C.OPTION_EXPIRIES
                   if not (np.isnan(opts[e][0][t]) or np.isnan(opts[e][1][t]))}
        opt_mids = {(e, wo): (options[e][0] + options[e][1]) / 2 for (e, wo) in optpos if e in options}
        pr, sz, isbuy, st = trades["etf"]
        snap = SimpleNamespace(
            ts=ts, books=bk,
            etf_trades=[(pr[k], sz[k], "buy" if isbuy[k] else "sell") for k in range(st[t], st[t + 1])],
            options=options, positions=dict(inv), opt_positions=dict(optpos),
            straw150_count=(int(cum150[max(0, t - 60)] - cum150[max(0, t - 60 - C.STRAW_FLOW["lookback_s"])])
                            if t >= 60 + C.STRAW_FLOW["min_history_s"] else None),
            pnl=pnl.total(mids, opt_mids))
        pending = bot.on_second(snap)
    tags = pnl.by_tag(mids)
    row = dict(day=day, pnl=sum(tags.values()), end_inv=sum(abs(v) for v in inv.values()),
               nudges=pnl.count["nudges"], pushes=pnl.count["pushes"], push_units=pnl.count["push_units"],
               flips=pnl.count["flips"])
    row.update({f"pair_{k}": v for k, v in bot.pair.stats.items()})      # pair-trade life-cycle counters
    row.update({f"pnl[{k}]": v for k, v in sorted(tags.items())})
    row.update({f"vol[{k}]": v for k, v in sorted(pnl.volume.items())})
    return row


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("days", nargs="+")
    ap.add_argument("--share", type=float, default=1.0, help="fraction of eligible flow we win (competition)")
    ap.add_argument("--mode", default=C.CENTRE_MODE, choices=["kalman", "mid"])
    ap.add_argument("--disable", default="", help="comma-separated feature names to switch off")
    ap.add_argument("--enable", default="", help="comma-separated feature names to switch on")
    ap.add_argument("--push-fail", type=float, default=0.0,
                    help="stress test: probability another team out-pushes our settle print")
    ap.add_argument("--set", action="append", default=[],
                    help="override a config value, e.g. --set OPTIONS.take_edge=0.04 --set QUOTE.apples.size=30")
    a = ap.parse_args()
    for kv in a.set:                                   # parameter overrides for tuning
        path, val = kv.split("="); parts = path.split(".")
        obj = getattr(C, parts[0])
        for k in parts[1:-1]:
            obj = obj[k]
        obj[parts[-1]] = type(obj[parts[-1]])(val)
    feats = {f: False for f in a.disable.split(",") if f}
    feats.update({f: True for f in a.enable.split(",") if f})
    rows = [run_day(d, a.share, a.mode, feats, a.push_fail) for d in a.days]
    r = pd.DataFrame(rows).fillna(0)
    pd.set_option("display.width", 250)
    print(r[["day", "pnl", "end_inv", "pushes", "push_units", "flips"]].round(1).to_string(index=False))
    if r["pair_opens"].sum():
        print("\nPair trade counters (mean per day):")
        print(r[[c for c in r if c.startswith("pair_")]].mean().round(1).to_string())
    print("\nPnL by strategy (mean per day):")
    print(r[[c for c in r if c.startswith("pnl[")]].mean().round(0).to_string())
    print("\nVolume by strategy (mean per day):")
    print(r[[c for c in r if c.startswith("vol[")]].mean().round(0).to_string())
    if len(r) > 1:
        print(f"\nmean ${r.pnl.mean():.0f}  sd ${r.pnl.std():.0f}  score ${r.pnl.mean() - r.pnl.std():.0f}")
