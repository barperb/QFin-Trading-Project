# QFin trading bot (v1)

The trading logic is kept separate from the exchange connection. The same `bot.py` runs in the backtester and live; only `exchange_adapter.py` talks to the exchange.

## Files
| file | what it is |
|---|---|
| `config.py` | **every parameter and feature switch**, each commented with where it came from (data or guess) |
| `bot.py` | the trading logic: `Bot.on_second(snapshot) -> Actions` (snapshot and actions are documented at the top of the file) |
| `models.py` | Kalman fair values for the fruits; option P(up) model, with and without control of the settle |
| `option_params.json` | option model inputs fitted from the data: volatility, intraday volatility profile, settle-noise distribution |
| `pnl_tracker.py` | PnL by strategy (every fill is tagged) |
| `backtest.py` | replays historical days second by second through the bot |
| `live_check.py` | checks whether live prices still snap back; sets `CENTRE_MODE` |
| `exchange_adapter.py` | **template for the dev**: fill in the TODOs against the exchange API |

## What the bot does each second
1. **Fruit and ETF market making** (`mm_<product>`).
   - **Centre:** the Kalman fair value (or the mid in `mid` mode).
   - **Price:** 1 tick better than the best price anyone else is showing, but never closer to our centre than `min_edge`. When another team is already tighter, we stop at our limit instead of chasing.
   - **Inventory:** quotes lean against inventory, relative to a target inventory set by the long-run signal.
2. **Signals** that shift the centre:

   | signal | what it does | modes |
   |---|---|---|
   | ETF ↔ basket inventory lean | long ETF leans fruit quotes toward selling, and vice versa | both |
   | apples–oranges pair lean | trades the spread back to its 2-minute average | kalman only |
   | long-run level | holds up to ±100 units toward each fruit's 24 h average | kalman only |
   | big-move rules | fades watermelon jumps, follows strawberry jumps | kalman only (**off** by default) |
3. **ETF protection.**
   - **Hedge (off by default):** if net basket exposure (ETF + average fruit inventory) passes 40 units, hedge it with fruit (`hedge`).
   - **Size-30 bot guard:** don't quote the side the size-30 ETF trades are about to hit (when the basket gap is over 8c).
4. **Options.**
   - **Strike:** recorded as the last ETF trade at the window open.
   - **Value:** P(up) is priced each second. The pricing includes the 72% (5-minute) / 53% (60-minute) chance that our own 1-lot sets the settle.
   - **Take** (`opt_take_*`): cross the spread when the edge is over 5c.
   - **Quote** (`opt_quote_*`): otherwise rest quotes 1 tick inside the best, at least 3c from our value.
   - **Cap:** ±50 contracts per window.
5. **Settle nudge** (`nudge`). In the second before a close, if a position can be decided by a 1-lot ETF print (ETF within 7.5c of the strike), send it at the ask (want UP) or the bid (want DOWN). When the 5-minute and 60-minute windows close in the same second, the bot sends one order for the net side.
6. **Risk.**
   - Inventory caps per product.
   - After a $1,500 daily loss, only quote the side that reduces inventory.
   - From 23:30 UTC, caps shrink and only reducing quotes are sent. From 23:55 UTC, cross the spread to get flat (`flatten`).

## Backtest
Four days (Jan, Mar, May, Jun 2026), with `--share 0.25`: we win a quarter of the eligible flow, standing in for competition.

**Feature check: score with each feature switched off, against $21,399/day with everything on:**

| switched off | score $/day | verdict |
|---|---|---|
| compete_quotes | 14,563 | **essential** (+6,800) |
| option_take | 16,970 | **essential** (+4,400) |
| long_run | 20,520 | helps (+880) |
| settle_nudge | 20,617 | helps (+780, though daily sd rises from 195 to 357) |
| option_quote | 21,049 | helps (+350) |
| settle_value | 21,270 | helps (+130, and lowers sd from 548 to 357) |
| pair_lean | 21,230 | helps (+170) |
| etf_bot_guard, etf_basket_lean | 21,381–21,420 | neutral; kept on as safety for live inventory |
| etf_hedge | 21,435 | neutral at 25% share, costs ~$800/day at 100% → **off by default** (the ETF cap of 50 already limits risk) |
| big_moves | 21,403 | neutral → **off by default** |
| vol_widen | 22,129 | costs $730 → **off by default** |
| flatten | 22,153 | costs $750 → kept **on** until we know how the daily reset values positions |

**Final default settings (same 4 days):**

| share of flow | v0 bot score/day | v1 bot score/day | v1 daily sd |
|---|---|---|---|
| 25% | 14,365 | **22,210** | 357 |
| 100% | 28,371 | **46,626** | 615 |

At 25% share the main contributors per day are fruit market making (~$14k), 5-minute option taking (~$6k), ETF market making (~$1.6k) and option quoting (~$0.6k).

**Mode check:** `--mode mid` (random-flow settings) scores about $7,700/day under the same assumptions.

**Caveats:**
- The replay assumes the market maker's prices move exactly as they did historically, whoever trades with it.
- There are no real competitor quotes in the historical data; `--share` only approximates them.
- So treat dollars as upper bounds. Use the backtest to compare variants, not to forecast results.

## Quick start (run from the "QFin Project" folder)
```
pip install pandas pyarrow numpy scipy
python bot/backtest.py 2026-02-12                                   # one day, ~40 s
python bot/backtest.py --share 0.25 2026-01-19 2026-03-26           # with competition
python bot/backtest.py --disable long_run --enable vol_widen 2026-02-12
python bot/backtest.py --set OPTIONS.take_edge=0.04 --set QUOTE.apples.size=30 2026-02-12
python bot/live_check.py live_tob_*.parquet                         # after logging a few hours of live data
```

## For the dev: going live
- [ ] Fill in `exchange_adapter.py`:
  - Market data → snapshot. Best bid/ask must **exclude our own orders**.
  - Cancel/replace only when a quote actually changes.
  - IOC orders, a fill callback into `PnLTracker`, logging of top-of-book to parquet.
  - Reconnects and stale-data protection.
- [ ] Find out how the exchange timestamps orders within a second. The `nudge` order must land **inside** the close second.
- [ ] Check message and rate limits. The bot sends up to 6 fruit/ETF quote pairs, 2 option quote pairs, plus IOCs each second, but only re-sends quotes that changed.
- [ ] After a few hours live: run `live_check.py`, then set `CENTRE_MODE` in `config.py`.
- [ ] Once the rules are published:
  - Set inventory caps to fit margin and short-selling limits.
  - Add ETF create/redeem as a hedge (once the fee is known).
  - Decide whether `flatten` is needed, based on how the reset values positions.
- [ ] Re-estimate `LONG_RUN.levels` on live data. The live exchange may start at different prices.
