"""Run with the provided team kit on PYTHONPATH; no network or trading account."""
import copy
import json
import math
import os
import random
from pathlib import Path
import selectors
import subprocess
import sys
import tempfile
import time
import threading
import unittest
from types import SimpleNamespace
from unittest import mock

import numpy as np
import pandas as pd
from exchange import Exchange, Buy, Sell
from exchange_adapter import ExchangeAdapter, DataUnavailable
from strategy import Actions, Bot
import config as C

NOW = 1791447000  # UTC epoch second


def state(ts=NOW, day="day-1", positions=None, orders=None):
    products = []
    books = {}
    for symbol, mid in zip(C.PRODUCTS, [10, 8, 11, 9, 12, 50]):
        products.append({"id": symbol, "symbol": symbol, "kind": "etf" if symbol == "etf" else "fruit",
                         "isEtf": symbol == "etf", "tickSize": .01, "positionLimit": 500})
        books[symbol] = {"bids": [{"price": mid - .05, "qty": 100}],
                         "asks": [{"price": mid + .05, "qty": 100}], "lastTradePrice": mid}
    for exp in [5, 60]:
        wo = ts // (exp * 60) * (exp * 60)
        symbol = f"up{exp}"
        products.append({"id": symbol, "symbol": symbol, "kind": "option", "tickSize": .01,
                         "positionLimit": 500, "option": {"expiryMin": exp, "windowOpen": wo,
                         "windowClose": wo + exp * 60, "strike": 49.8, "priceSource": "etf_last_trade"}})
        books[symbol] = {"bids": [{"price": .4, "qty": 100}],
                         "asks": [{"price": .6, "qty": 100}], "lastTradePrice": .5}
    return {"serverTime": ts * 1000, "products": products, "books": books,
            "positions": [{"symbol": p, "qty": q} for p, q in (positions or {}).items()],
            "openOrders": orders or [], "pnl": 0,
            "account": {"day": day, "dayEnd": (ts + 8 * 3600) * 1000, "cash": 10000,
                        "equity": 10000, "marginUsed": 0, "marginAvailable": 10000, "busts": 0}}


def order(symbol="apples", price=9.95, qty=10, filled=0, side="buy", oid="o1"):
    return {"_id": oid, "symbol": symbol, "side": side, "price": price, "qty": qty,
            "filledQty": filled, "status": "open", "orderType": "limit"}


# The tests below were written for 10% live sizing; pin it so they keep checking the cap/margin logic exactly.
# (config.LIVE now defaults to 0.25 - tests that care about other scales pass their own settings.)
TEST_SCALE = {"inventory_scale": 0.10, "quote_size_scale": 0.10,
              "fruit_quote_units": {}, "fruit_inventory_cap": {}, "pair_scale": None}   # v11 overrides off here


class FakeAdapter(ExchangeAdapter):
    def __init__(self, settings=None):
        super().__init__(dict(TEST_SCALE, **dict({"async_orders": False}, **(settings or {}))))
        self.requests = []
        self.messages = []

    def log(self, message):
        self.messages.append(message)

    warn = log

    def batch(self, actions):
        self.requests.append(copy.deepcopy(actions))
        return [{"status": "ok", "orderId": str(i)} for i, _ in enumerate(actions)]

    def feed(self, raw):
        self._state = copy.deepcopy(raw)
        self._state_version += 1
        self._state_updated_at = time.time()

    def view(self):
        return self._capture()[0]


class LiveTests(unittest.TestCase):
    def ready(self, settings=None, raw=None):
        bot = FakeAdapter(settings)
        bot.feed(raw or state())
        view = bot.view()
        bot._reset_if_needed(view)
        return bot, view, bot.build_snapshot(view)

    def test_live_tick_sends_small_quotes(self):
        bot = FakeAdapter({"enable_options": False})
        bot.feed(state())
        bot.on_tick()
        orders = [a for a in bot.requests[-1] if a["type"] == "order"]
        self.assertTrue(orders)
        self.assertTrue(all(o["qty"] <= 2 and o["symbol"] in C.PRODUCTS for o in orders))
        self.assertTrue(all(not any(k.startswith("_") for k in o) for o in orders))
        self.assertFalse(bot.strategy.f["settle_nudge"])

    def test_exclude_own_quantity_keep_external_same_price(self):
        raw = state(orders=[order(qty=100, filled=25)])
        bot, view, snap = self.ready(raw=raw)
        self.assertEqual(snap.books["apples"][2], 25)
        raw["books"]["apples"]["bids"][0]["qty"] = 75
        raw["books"]["apples"]["bids"].append({"price": 9.9, "qty": 12})
        bot.feed(raw)
        self.assertEqual(bot.external_book(bot.view(), "apples")[:3], (9.9, 10.05, 12))

    def test_authoritative_option_strike_midwindow(self):
        bot, view, snap = self.ready({"enable_options": True}, state(ts=NOW + 60))
        bot.strategy.last_etf_trade = 80
        bot.strategy.on_second(snap)
        wo = snap.options[5][2]
        self.assertEqual(bot.strategy.strikes[(5, wo)], 49.8)
        self.assertEqual(snap.etf_trades, [])

    def test_mid_settled_option_is_traded_noise_free(self):
        # v9: an option that settles on the ETF MID is priced without print noise (no longer skipped)
        raw = state()
        raw["products"][-2]["option"]["priceSource"] = "etf_mid"
        bot, view, snap = self.ready({"enable_options": True}, raw)
        self.assertIn(5, snap.options)
        self.assertEqual(snap.option_src[5], "etf_mid")
        self.assertIn(60, snap.options)

    def test_daily_loss_stop_clears_next_day_not_on_bust(self):
        bot = FakeAdapter()
        raw = state(); raw["pnl"] = -(C.RISK["daily_loss_limit"] + 100)
        bot.feed(raw); bot.on_tick()
        self.assertTrue(bot.strategy.halted)
        raw = state(ts=NOW + 1); raw["account"]["busts"] = 1
        bot.feed(raw); bot.on_tick()
        self.assertTrue(bot.strategy.halted)
        bot.feed(state(ts=NOW + 2, day="day-2")); bot.on_tick()
        self.assertFalse(bot.strategy.halted)

    def test_reset_clock_not_utc_hour(self):
        raw = state(); raw["account"]["dayEnd"] = (NOW + 60) * 1000
        # v9 turns the late-day wind-down off by default (positions are closed at the mid); the mechanism still works:
        bot, view, snap = self.ready({"reset_flatten_start_seconds": 1800, "reset_flatten_ioc_seconds": 300}, raw=raw)
        self.assertTrue(snap.late and snap.very_late)

    def test_aggregate_ioc_and_quote_caps(self):
        bot, view, snap = self.ready(raw=state(positions={"apples": 29}))
        act = Actions(quotes={"apples": (9.95, 20, 10.05, 20)},
                      ioc=[("apples", "+", 20, 10.05, "hedge")])
        planned, _ = bot.plan_orders(view, snap, act)
        buys = sum(o["qty"] for o in planned if o["side"] == "buy")
        self.assertLessEqual(buys, 1)

    def test_joint_margin_budget_and_option_dollar_bound(self):
        raw = state(); raw["account"]["equity"] = 60
        bot, view, snap = self.ready({"quote_size_scale": 1, "inventory_scale": 1}, raw)
        act = Actions(quotes={p: (snap.books[p][0], 100, snap.books[p][1], 100) for p in C.PRODUCTS})
        planned, _ = bot.plan_orders(view, snap, act)
        self.assertLessEqual(bot._margin(view, planned), 48 + 1e-8)
        self.assertEqual(bot._margin(view, [Buy("up5", .4, 20), Sell("up5", .6, 20)]), 20)

    def test_loss_stop_orders_cannot_overshoot_flat(self):
        bot, view, snap = self.ready(raw=state(positions={"apples": 1}))
        bot.strategy.halted = True
        act = Actions(quotes={"apples": (9.95, 20, 10.05, 20)},
                      ioc=[("apples", "-", 20, 9.95, "flatten")])
        planned, _ = bot.plan_orders(view, snap, act)
        self.assertEqual(sum(o["qty"] for o in planned), 1)
        self.assertEqual(planned[0]["side"], "sell")

    def test_unchanged_quotes_preserved_partial_fills_replenished(self):
        raw = state(orders=[order(qty=2)])
        bot, view, snap = self.ready(raw=raw)
        act = Actions(quotes={"apples": (9.95, 2, 10.05, 0)})
        bot.execute_actions(view, snap, act, bot._state_version)
        self.assertFalse(bot.requests)
        raw["openOrders"][0]["filledQty"] = 1
        bot.feed(raw); view = bot.view(); snap = bot.build_snapshot(view)
        bot.execute_actions(view, snap, act, bot._state_version)
        self.assertEqual(bot.requests[-1][0]["type"], "cancelAll")
        self.assertEqual(bot.requests[-1][1]["qty"], 2)

    def test_quote_removed_when_no_longer_desired(self):
        bot, view, snap = self.ready(raw=state(orders=[order(symbol="up5", price=.4)]))
        bot.execute_actions(view, snap, Actions(), bot._state_version)
        self.assertEqual(bot.requests[-1], [{"type": "cancelAll", "symbol": "up5"}])

    def test_stale_and_missing_data_cancel(self):
        bot = FakeAdapter(); bot.feed(state()); bot._state_updated_at -= 10
        bot.on_tick()
        self.assertEqual(bot.requests[-1], [{"type": "cancelAll"}])
        bot = FakeAdapter(); raw = state(); raw["books"]["apples"]["asks"] = []
        bot.feed(raw); bot.on_tick()
        self.assertEqual(bot.requests[-1], [{"type": "cancelAll"}])

    def test_no_duplicate_order_before_new_state(self):
        bot = FakeAdapter(); bot.feed(state()); bot.on_tick()
        count = len(bot.requests)
        bot.on_tick(); bot.on_tick()
        self.assertEqual(len(bot.requests), count)

    def test_window_roll_checked_before_submit(self):
        bot, view, snap = self.ready({"enable_options": True}, state(ts=NOW + 60))
        wo = snap.options[5][2]
        act = Actions(option_orders=[(5, wo, "+", 1, .6, "opt_take_5")])
        bot._state["products"][-2]["option"]["windowOpen"] += 300
        with self.assertRaises(DataUnavailable):
            bot.execute_actions(view, snap, act, bot._state_version)

    def test_disabled_or_unknown_options_not_sent(self):
        bot, view, snap = self.ready({"enable_options": False})
        act = Actions(option_orders=[(5, pd.Timestamp(NOW, unit="s", tz="UTC"), "+", 50, .6, "x")])
        self.assertEqual(bot.plan_orders(view, snap, act)[0], [])

    def test_portfolio_above_budget_only_reduces(self):
        raw = state(positions={"apples": 10}); raw["account"]["equity"] = 50
        bot, view, snap = self.ready(raw=raw)
        act = Actions(quotes={"apples": (9.95, 20, 10.05, 20), "bananas": (7.95, 20, 8.05, 20)})
        planned, _ = bot.plan_orders(view, snap, act)
        self.assertTrue(planned)
        self.assertTrue(all(o["symbol"] == "apples" and o["side"] == "sell" for o in planned))

    def test_logging_rotates_and_handles_readonly_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            bot, view, snap = self.ready({"log_directory": tmp, "log_max_bytes": 20})
            bot._log_market(snap); bot._log_market(snap)
            self.assertTrue(Path(tmp, "live_tob.csv.previous").exists())
            bot.settings["log_directory"] = str(Path(tmp, "live_tob.csv"))
            bot._log_market(snap)  # warning, no crash
            self.assertTrue(any("logging unavailable" in m for m in bot.messages))

    def test_randomized_portfolio_caps_and_margin(self):
        rng = random.Random(44)
        for _ in range(150):
            positions = {p: rng.randint(-5 if p == "etf" else -15, 5 if p == "etf" else 15)
                         for p in C.PRODUCTS}
            raw = state(positions=positions)
            raw["account"]["equity"] = rng.uniform(100, 10000)
            bot, view, snap = self.ready(raw=raw)
            act = Actions(quotes={p: (snap.books[p][0], rng.randint(0, 100),
                                     snap.books[p][1], rng.randint(0, 100)) for p in C.PRODUCTS},
                          ioc=[(p, rng.choice(["+", "-"]), rng.randint(1, 80),
                                snap.books[p][0], "hedge") for p in C.PRODUCTS])
            planned, _ = bot.plan_orders(view, snap, act)
            baseline = bot._margin(view, [])
            self.assertLessEqual(bot._margin(view, planned), max(baseline, raw["account"]["equity"] * .8) + 1e-7)
            for p in C.PRODUCTS:
                buy = sum(o["qty"] for o in planned if o["symbol"] == p and o["side"] == "buy")
                sell = sum(o["qty"] for o in planned if o["symbol"] == p and o["side"] == "sell")
                cap = bot._cap(view, p, snap)
                self.assertLessEqual(max(abs(positions[p] + buy), abs(positions[p] - sell)), cap)

    def test_timeout_reconciles_instead_of_duplicate_submit(self):
        bot = FakeAdapter(); bot.feed(state())
        def failed_batch(actions):
            bot.requests.append(copy.deepcopy(actions))
            raise TimeoutError("unknown outcome")
        bot.batch = failed_batch
        bot.on_tick()
        count = len(bot.requests)
        self.assertIsNotNone(bot._pending_version)
        bot.on_tick()
        self.assertEqual(len(bot.requests), count)
        self.assertTrue(any("unknown outcome" in m for m in bot.messages))

    def test_rejections_logged_and_replanned_from_state(self):
        bot = FakeAdapter(); bot.feed(state())
        def rejected(actions):
            bot.requests.append(copy.deepcopy(actions))
            return [{"error": "insufficient margin"} for _ in actions]
        bot.batch = rejected
        bot.on_tick()
        self.assertTrue(any("insufficient margin" in m for m in bot.messages))
        count = len(bot.requests)
        bot.on_tick()
        self.assertEqual(len(bot.requests), count)
        bot.feed(state(ts=NOW + 1)); bot.on_tick()
        self.assertGreater(len(bot.requests), count)

    def test_sdk_pipe_transport_entrypoint(self):
        """Execute the real SDK backtest loop and upload entry point over exchange pipes."""
        if os.name != "posix":
            self.skipTest("exchange pipe transport requires POSIX")
        incoming_read, incoming_write = os.pipe()
        outgoing_read, outgoing_write = os.pipe()
        root = str(Path(__file__).resolve().parents[1])
        script = (f"import os,runpy;os.dup2({incoming_read},3);os.dup2({outgoing_write},4);"
                  f"runpy.run_path({str(Path(root, 'bot.py'))!r},run_name='__main__')")
        env = dict(os.environ, QFIN_BACKTEST="1")
        proc = subprocess.Popen([sys.executable, "-c", script], cwd=root, env=env,
                                pass_fds=(incoming_read, outgoing_write),
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        os.close(incoming_read); os.close(outgoing_write)
        try:
            with os.fdopen(incoming_write, "w") as src, os.fdopen(outgoing_read, "r") as dst:
                selector = selectors.DefaultSelector(); selector.register(dst, selectors.EVENT_READ)
                def recv():
                    if not selector.select(10):
                        raise AssertionError("SDK pipe response timed out")
                    line = dst.readline()
                    if not line:
                        raise AssertionError("SDK exited before completing a tick")
                    return json.loads(line)
                self.assertEqual(recv()["type"], "ready")
                src.write(json.dumps({"type": "tick", "state": state()}) + "\n"); src.flush()
                call = recv()
                self.assertEqual(call["path"], "/api/batch")
                self.assertTrue(call["body"]["actions"])
                src.write(json.dumps({"status": 200, "body": [{"status": "ok"} for _ in call["body"]["actions"]]}) + "\n"); src.flush()
                self.assertEqual(recv()["type"], "done")
                src.write('{"type":"end"}\n'); src.flush()
                selector.close()
            output, errors = proc.communicate(timeout=10)
            self.assertEqual(proc.returncode, 0, errors.decode())
            self.assertNotIn(b"Traceback", errors)
        finally:
            if proc.poll() is None:
                proc.kill(); proc.communicate()


class SettlePushTests(unittest.TestCase):
    """Options manipulation: print the ETF settle on our side of the strike in the close second."""

    def closing_state(self, pos, strike, seconds_left=1, etf_asks=None, etf_bids=None):
        ts = NOW - NOW % 300 + 300 - seconds_left          # seconds_left before a 5-minute close
        raw = state(ts=ts, positions={"up5": pos})
        for p in raw["products"]:
            if p["symbol"] == "up5":
                p["option"]["strike"] = strike
        if etf_asks is not None:
            raw["books"]["etf"]["asks"] = etf_asks
        if etf_bids is not None:
            raw["books"]["etf"]["bids"] = etf_bids
        return raw

    def test_plan_walks_book_and_prints_at_target(self):
        from strategy import plan_push
        asks = [(50.05, 1), (50.06, 3), (50.20, 5), (50.40, 10)]
        bids = [(49.95, 1), (49.90, 5)]
        orders, units, cost, stake, rng = plan_push([(50.15, 100)], bids, asks, 50.0, 40)
        self.assertEqual(orders, [("+", 4, 50.06), ("+", 1, 50.20)])   # clear 50.05/50.06, print 1 @ 50.20
        self.assertEqual((units, stake), (5, 100))

    def test_plan_picks_print_winning_most_contracts(self):
        from strategy import plan_push
        asks = [(50.05, 1), (50.10, 2)]; bids = [(49.95, 1), (49.90, 2)]
        # 5m long UP 100 @ strike 50.00 and 60m long DOWN 30 @ strike 49.98: can't win both -> win the 100
        orders, units, cost, stake, rng = plan_push([(50.00, 100), (49.98, -30)], bids, asks, 50.0, 40)
        self.assertEqual(stake, 100)
        self.assertEqual(orders[-1][0], "+")

    def test_live_push_ignores_mm_caps_and_late_rule(self):
        raw = self.closing_state(pos=80, strike=50.30,
                                 etf_asks=[{"price": 50.05, "qty": 1}, {"price": 50.10, "qty": 6},
                                           {"price": 50.35, "qty": 5}])
        raw["account"]["dayEnd"] = (raw["serverTime"] // 1000 + 60) * 1000   # late in the day
        raw["openOrders"] = [order(symbol="etf", price=50.20, qty=1, side="sell", oid="q1")]  # our resting ETF ask
        bot = FakeAdapter({"enable_options": True})
        bot.feed(raw); bot.on_tick()
        sent = [a for a in bot.requests[-1] if a.get("symbol") == "etf" and a.get("orderType") == "ioc"]
        # v9.2: the walk's limit is the last tick BELOW the strike (50.29) and it may take early_buffer more units than
        # it saw (7 + 5 = 12 > ETF MM cap of 5: push is exempt); the 1-unit print order may fill anywhere up to
        # LIVE.late_push_b_reach past the strike (any print on our side wins).
        self.assertEqual([(a["side"], a["qty"], a["price"]) for a in sent],
                         [("buy", 7 + C.SETTLE_PUSH["early_buffer"], 50.29),
                          ("buy", 1, round(50.30 + C.LIVE["late_push_b_reach"], 2))])
        etf_actions = [a for a in bot.requests[-1] if a.get("symbol") == "etf"]
        self.assertEqual(etf_actions[0]["type"], "cancelAll")           # own ETF quotes pulled first (no self-trade)

    def test_no_push_without_position_or_outside_fire_window(self):
        bot = FakeAdapter({"enable_options": True})
        bot.feed(self.closing_state(pos=0, strike=50.30)); bot.on_tick()
        self.assertFalse(any(a.get("symbol") == "etf" and a.get("orderType") == "ioc" for a in bot.requests[-1]))
        bot = FakeAdapter({"enable_options": True})
        bot.feed(self.closing_state(pos=50, strike=50.30, seconds_left=20)); bot.on_tick()
        self.assertFalse(any(a.get("symbol") == "etf" and a.get("orderType") == "ioc" for a in bot.requests[-1]))


def pair_snapshot(i, apples_mid, oranges_mid, positions=None, late=False):
    """A strategy-level snapshot (no exchange). Fruit books are 6c wide with 7 lots each side."""
    mids = dict(zip(C.PRODUCTS, [apples_mid, 8.0, oranges_mid, 9.0, 12.0, 50.0]))
    books = {p: (round(m - .03, 2), round(m + .03, 2), 7, 7) for p, m in mids.items()}
    return SimpleNamespace(ts=pd.Timestamp(NOW + i, unit="s", tz="UTC"), books=books, etf_trades=[], options={},
                           positions=dict(positions or {}), opt_positions={}, pnl=0.0, late=late, very_late=False)


def run_pair(bot, jump=0.20, warm=130, seconds=1, positions=None, late_from=None):
    """Warm the EMA at a flat 1.00 spread, then push oranges up by `jump`. Returns the Actions of each second."""
    out = []
    for i in range(warm):
        bot.on_second(pair_snapshot(i, 10.0, 11.0))
    for i in range(warm, warm + seconds):
        out.append(bot.on_second(pair_snapshot(i, 10.0, 11.0 + jump, positions, late=late_from is not None and i >= late_from)))
    return out


class PairTradeTests(unittest.TestCase):
    """Apples-oranges pair trade: strategy behaviour in both centre modes, and the live adapter's joint sizing."""

    PAIR_IOCS = lambda self, actions: [x for x in actions.ioc if x[4] in ("pair", "pair_stop")]

    # ---------------------------------------------------------------- strategy
    def test_aggressive_takes_both_legs_equal_size_in_mid_mode(self):
        bot = Bot(centre_mode="mid", features={"pair_aggressive": True})
        iocs = self.PAIR_IOCS(run_pair(bot)[0])
        self.assertEqual(len(iocs), 2)
        (p1, s1, q1, px1, _), (p2, s2, q2, px2, _) = iocs
        # oranges rich: BUY apples at the ask, SELL oranges at the bid, same units
        self.assertEqual((p1, s1, px1), ("apples", "+", 10.03))
        self.assertEqual((p2, s2, px2), ("oranges", "-", 11.17))
        self.assertEqual(q1, q2)
        self.assertEqual(q1, 7)                       # capped by the 7 lots displayed at the touch (aggr_clip is 10)
        self.assertEqual(bot.pair.d, 1)

    def test_pair_respects_mid_mode_flag(self):
        for flag, expect in ((True, 2), (False, 0)):
            bot = Bot(centre_mode="mid", features={"pair_aggressive": True, "pair_mid_mode": flag})
            self.assertEqual(len(self.PAIR_IOCS(run_pair(bot)[0])), expect)

    def test_aggressive_needs_deviation_to_beat_crossing_cost(self):
        # crossing both 6c spreads costs 6c; 0.8 x 8c = 6.4c expected reversion - 6c = 0.4c < min_net 1c -> no trade
        self.assertEqual(self.PAIR_IOCS(run_pair(Bot(centre_mode="mid", features={"pair_aggressive": True}),
                                                 jump=0.08)[0]), [])
        # 12c -> 9.6c - 6c = 3.6c -> trade
        self.assertEqual(len(self.PAIR_IOCS(run_pair(Bot(centre_mode="mid", features={"pair_aggressive": True}),
                                                    jump=0.12)[0])), 2)

    def test_aggressive_stops_at_pair_cap_and_keeps_legs_hedged(self):
        with mock.patch.dict(C.PAIR_TRADE, {"aggr_max_units": 15, "aggr_clip": 10, "aggr_cooldown_s": 0}):
            bot = Bot(centre_mode="mid", features={"pair_aggressive": True})
            pos = {}
            for i in range(130):
                bot.on_second(pair_snapshot(i, 10.0, 11.0))
            for i in range(130, 140):
                act = bot.on_second(pair_snapshot(i, 10.0, 11.2, pos))
                iocs = self.PAIR_IOCS(act)
                if iocs:
                    self.assertEqual(iocs[0][2], iocs[1][2])
                    for p, side, q, px, _ in iocs:
                        pos[p] = pos.get(p, 0) + (q if side == "+" else -q)
            self.assertEqual(pos, {"apples": 15, "oranges": -15})

    def test_passive_sets_opposite_targets_and_quotes_lean_in_mid_mode(self):
        control = Bot(centre_mode="mid", features={"pair_passive": False, "pair_lean": False})
        bot = Bot(centre_mode="mid", features={"pair_passive": True, "pair_lean": False})
        base = run_pair(control)[0].quotes
        act = run_pair(bot)[0].quotes
        self.assertEqual(bot.pair.d, 1)
        # target +50 apples / -50 oranges (50% tier of 100): apples ask pulled away, oranges bid pulled away
        self.assertGreater(act["apples"][2], base["apples"][2])
        self.assertLess(act["oranges"][0], base["oranges"][0])
        self.assertEqual(act["bananas"], base["bananas"])
        self.assertFalse(self.PAIR_IOCS(run_pair(Bot(centre_mode="mid", features={"pair_passive": True}))[0]))  # no IOCs

    def test_exit_on_reversion_time_stop_and_late(self):
        # reverted: spread back to the anchor (1.00)
        bot = Bot(centre_mode="mid", features={"pair_passive": True})
        run_pair(bot)
        self.assertEqual(bot.pair.d, 1)
        bot.on_second(pair_snapshot(131, 10.0, 11.0))
        self.assertEqual((bot.pair.d, bot.pair.stats["closes_reverted"]), (0, 1))
        # time stop
        with mock.patch.dict(C.PAIR_TRADE, {"hold_max_s": 20}):
            bot = Bot(centre_mode="mid", features={"pair_passive": True})
            run_pair(bot)
            for i in range(131, 160):
                bot.on_second(pair_snapshot(i, 10.0, 11.2))
            self.assertEqual(bot.pair.stats["closes_time"], 1)
        # late in the day: closes and refuses new trades (only when the wind-down is on; v9 default is off)
        bot = Bot(centre_mode="mid", features={"pair_passive": True, "flatten": True})
        run_pair(bot, seconds=2, late_from=131)
        self.assertEqual((bot.pair.d, bot.pair.stats["closes_late"]), (0, 1))
        bot = Bot(centre_mode="mid", features={"pair_passive": True, "flatten": True})
        run_pair(bot, seconds=2, late_from=130)
        self.assertEqual(bot.pair.stats["opens"], 0)

    def test_cooldown_blocks_reentry(self):
        bot = Bot(centre_mode="mid", features={"pair_passive": True})
        run_pair(bot)
        bot.on_second(pair_snapshot(131, 10.0, 11.0))           # reverted -> closed, cooldown 30 s
        bot.on_second(pair_snapshot(132, 10.0, 11.3))
        self.assertEqual(bot.pair.d, 0)
        for i in range(133, 165):
            bot.on_second(pair_snapshot(i, 10.0, 11.3))
        self.assertEqual(bot.pair.stats["opens"], 2)             # re-opened only after the cooldown

    def test_stop_loss_off_by_default_and_crosses_when_enabled(self):
        bot = Bot(centre_mode="mid", features={"pair_aggressive": True})
        run_pair(bot, jump=0.12)
        bot.on_second(pair_snapshot(131, 10.0, 11.45, {"apples": 7, "oranges": -7}))
        self.assertEqual(bot.pair.stats["closes_stop"], 0)       # stop_dev = 0 -> off
        with mock.patch.dict(C.PAIR_TRADE, {"stop_dev": 0.15}):
            bot = Bot(centre_mode="mid", features={"pair_aggressive": True})
            run_pair(bot, jump=0.12)
            act = bot.on_second(pair_snapshot(131, 10.0, 11.45, {"apples": 7, "oranges": -7}))
            stop = [x for x in act.ioc if x[4] == "pair_stop"]
            self.assertEqual([(x[0], x[1], x[2]) for x in stop], [("oranges", "+", 7), ("apples", "-", 7)])

    def test_kalman_mode_unchanged_when_pair_features_off(self):
        a = Bot(centre_mode="kalman", features={"pair_passive": False, "pair_aggressive": False})
        b = Bot(centre_mode="kalman", features={"pair_passive": False, "pair_aggressive": False})
        self.assertEqual(run_pair(a)[0].quotes, run_pair(b)[0].quotes)
        self.assertEqual(a.pair.stats["opens"], 0)

    # ---------------------------------------------------------------- live adapter: caps and margin
    def planned(self, bot, view, snap, ioc):
        planned, _ = bot.plan_orders(view, snap, Actions(ioc=ioc))
        return [o for o in planned if o["_tag"] in ("pair", "pair_stop")]

    ENTRY = [("apples", "+", 8, 10.05, "pair"), ("oranges", "-", 8, 10.95, "pair")]

    def test_adapter_pair_legs_share_the_tighter_cap(self):
        bot, view, snap = LiveTests().ready(raw=state(positions={"apples": 29}))   # apples cap is 30 live
        got = self.planned(bot, view, snap, self.ENTRY)
        self.assertEqual([(o["symbol"], o["side"], o["qty"], o["orderType"]) for o in got],
                         [("apples", "buy", 1, "ioc"), ("oranges", "sell", 1, "ioc")])

    def test_adapter_never_sends_half_a_pair(self):
        bot, view, snap = LiveTests().ready(raw=state(positions={"oranges": -30}))   # cannot sell any more oranges
        self.assertEqual(self.planned(bot, view, snap, self.ENTRY), [])
        # malformed input (one leg only) is dropped too
        bot, view, snap = LiveTests().ready()
        self.assertEqual(self.planned(bot, view, snap, self.ENTRY[:1]), [])

    def test_adapter_pair_joint_margin_budget(self):
        raw = state(); raw["account"]["equity"] = 100                 # budget 80
        bot, view, snap = LiveTests().ready({"inventory_scale": 1, "quote_size_scale": 1}, raw)
        got = self.planned(bot, view, snap, self.ENTRY)
        self.assertEqual([o["qty"] for o in got], [3, 3])             # 3 x 10.05 + 3 x 11.05 = 63.3; 4 would be 84.4 > 80
        self.assertLessEqual(bot._margin(view, got), 80 + 1e-8)

    def test_adapter_pair_entry_blocked_when_risk_off_but_exit_allowed(self):
        raw = state(positions={"apples": 5, "oranges": -5})
        bot, view, snap = LiveTests().ready(raw=raw)
        bot.strategy.halted = True                                    # daily loss stop: reduce only
        self.assertEqual(self.planned(bot, view, snap, self.ENTRY), [])
        exit_legs = [("apples", "-", 5, 9.95, "pair_stop"), ("oranges", "+", 5, 11.05, "pair_stop")]
        got = self.planned(bot, view, snap, exit_legs)
        self.assertEqual([(o["symbol"], o["side"], o["qty"]) for o in got], [("apples", "sell", 5), ("oranges", "buy", 5)])

    def test_adapter_pair_ioc_precedes_quotes_and_pulls_own_quotes(self):
        raw = state(orders=[order(symbol="apples", price=10.0, qty=2, oid="q1", side="sell")])
        bot, view, snap = LiveTests().ready(raw=raw)
        act = Actions(ioc=self.ENTRY, quotes={"apples": (9.96, 2, 10.04, 2)})
        bot.execute_actions(view, snap, act, bot._state_version)
        sent = bot.requests[-1]
        kinds = [(a["type"], a.get("symbol"), a.get("orderType")) for a in sent]
        self.assertEqual(kinds[0], ("cancelAll", "apples", None))     # our resting apples quote goes first: no self-trade
        iocs = [a for a in sent if a.get("orderType") == "ioc"]
        self.assertEqual([(a["symbol"], a["side"], a["qty"]) for a in iocs], [("apples", "buy", 8), ("oranges", "sell", 8)])
        self.assertTrue(all(not any(k.startswith("_") for k in a) for a in sent))

    # ---------------------------------------------------------------- live adapter: end to end
    def stretched_adapter(self, settings=None, features=None):
        """Adapter whose strategy has a warm EMA 25c below the current spread (spread = 11 - 10 = 1.00)."""
        with mock.patch.dict(C.FEATURES, features or {"pair_aggressive": True}):
            bot = FakeAdapter(dict({"enable_options": False}, **(settings or {})))
            bot.feed(state())
            bot._reset_if_needed(bot.view())
        bot.strategy.pair.samples = 1000
        bot.strategy.pair_ema.value = 0.75
        return bot

    def test_live_tick_sends_pair_in_mid_mode_scaled_to_live_caps(self):
        bot = self.stretched_adapter()
        self.assertEqual(bot.settings["centre_mode"], "mid")
        bot.on_tick()
        iocs = [a for a in bot.requests[-1] if a.get("orderType") == "ioc"]
        self.assertEqual([(a["symbol"], a["side"], a["qty"], a["price"]) for a in iocs],
                         [("apples", "buy", 1, 10.05), ("oranges", "sell", 1, 10.95)])   # clip 10 x inventory_scale 0.10

    def test_live_pair_switched_off_by_live_master_switch(self):
        bot = self.stretched_adapter({"pair_trade": False})
        bot.on_tick()
        self.assertFalse([a for a in bot.requests[-1] if a.get("orderType") == "ioc"])
        self.assertFalse(bot.strategy.f["pair_aggressive"] or bot.strategy.f["pair_passive"])

    def test_live_passive_pair_sends_no_iocs_only_quotes(self):
        bot = self.stretched_adapter(features={"pair_passive": True, "pair_aggressive": False})
        bot.on_tick()
        self.assertEqual(bot.strategy.pair.d, 1)
        self.assertFalse([a for a in bot.requests[-1] if a.get("orderType") == "ioc"])
        self.assertTrue([a for a in bot.requests[-1] if a.get("type") == "order"])


class BookReachTests(unittest.TestCase):
    """Option valuation with the REAL ETF book (FEATURES.book_reach) and the live settle bias."""

    def value_of_long_up(self, asks, bids, strike, bias=0.0, book_reach=True, left=20):
        feats = dict(C.FEATURES, settle_push=True, book_reach=book_reach, option_take=False, option_quote=True)
        bot = Bot(centre_mode="mid", features=feats)
        bot.om.bias = bias
        wo = pd.Timestamp(NOW, unit="s", tz="UTC")
        ts = wo + pd.Timedelta(seconds=300 - left)
        mids = {p: 10.0 for p in C.PRODUCTS}
        mids["etf"] = 50.0
        books = {p: (9.97, 10.03, 7, 7) for p in C.PRODUCTS}
        books["etf"] = (49.92, 50.08, 1, 1)
        bot.strikes[(5, wo)] = strike
        s = SimpleNamespace(ts=ts, books=books, options={5: (0.40, 0.60, wo)}, opt_positions={(5, wo): 0.0},
                            etf_levels=(bids, asks) if book_reach else None, live=True)
        act = type("A", (), {"option_quotes": {}, "option_orders": [], "ioc": []})()
        bot.options(s, act, mids, 12 * 3600, False)
        wo_, qb, nb, qa, na = act.option_quotes[5]
        return qb, qa

    def test_reach_is_limited_by_the_real_book(self):
        thin = [(50.08, 1), (50.10, 1)]                       # book tops out at 50.10
        deep = [(50.08, 1), (50.10, 1), (50.30, 30)]          # a 30-lot level at 50.30
        bids = [(49.92, 1), (49.90, 1)]
        # strike 50.25: reachable only with the deep book
        self.assertGreater(Bot.affordable_reach(deep, 50.0, 50, True), 0.25)
        self.assertLess(Bot.affordable_reach(thin, 50.0, 50, True), 0.15)
        q_thin = self.value_of_long_up(thin, bids, 50.15)
        q_deep = self.value_of_long_up(deep, bids, 50.15)
        self.assertLess(q_thin[0], q_deep[0])                 # we bid less for UP when we cannot push it

    def test_book_never_extends_reach_beyond_legacy(self):
        # A deep far-away level must NOT make a 27c-away strike look pushable (v5 mistake).
        deep = [(50.08, 1), (50.30, 60)]
        bids = [(49.92, 1)]
        far = self.value_of_long_up(deep, bids, 50.27)
        ref = self.value_of_long_up(deep, bids, 50.27, book_reach=False)   # legacy touch+0.10 assumption
        self.assertLessEqual(far[0], ref[0] + 1e-9)

    def test_short_up_cap(self):
        """Short-UP (long-DOWN) is capped at OPTIONS.max_short; long-UP keeps max_contracts."""
        self.assertEqual(C.OPTIONS["max_short"], 100)
        feats = dict(C.FEATURES, settle_push=True, book_reach=False, option_take=True, option_quote=True)
        bot = Bot(centre_mode="mid", features=feats)
        wo = pd.Timestamp(NOW, unit="s", tz="UTC")
        mids = {p: 10.0 for p in C.PRODUCTS}
        mids["etf"] = 50.0
        books = {p: (9.97, 10.03, 7, 7) for p in C.PRODUCTS}
        books["etf"] = (49.92, 50.08, 1, 1)
        bot.strikes[(5, wo)] = 49.0                      # ETF far above the strike: UP is worth ~1, so the model wants UP
        for pos in (-100, -150, 0, 400):
            s = SimpleNamespace(ts=wo + pd.Timedelta(seconds=120), books=books, options={5: (0.10, 0.12, wo)},
                                opt_positions={(5, wo): float(pos)}, etf_levels=None, live=True)
            act = type("A", (), {"option_quotes": {}, "option_orders": [], "ioc": []})()
            bot.options(s, act, mids, 12 * 3600, False)
            sells = [o for o in act.option_orders if o[2] == "-"]
            qa = act.option_quotes.get(5)
            if pos <= -100:
                self.assertFalse(sells)
                self.assertTrue(qa is None or qa[4] == 0)   # no resting ask size either (a take order skips quoting)
            if qa and pos == 0:
                self.assertLessEqual(qa[4], 100)         # room to short: at most max_short

    def test_no_up_selling_in_5m(self):
        feats = dict(C.FEATURES, settle_push=True, book_reach=False, option_take=True, option_quote=True)
        bot = Bot(centre_mode="mid", features=feats)
        wo = pd.Timestamp(NOW, unit="s", tz="UTC")
        mids = {p: 10.0 for p in C.PRODUCTS}
        mids["etf"] = 50.0
        books = {p: (9.97, 10.03, 7, 7) for p in C.PRODUCTS}
        books["etf"] = (49.92, 50.08, 1, 1)
        bot.strikes[(5, wo)] = 51.0                       # UP nearly worthless: the old bot would sell it
        s = SimpleNamespace(ts=wo + pd.Timedelta(seconds=120), books=books, options={5: (0.60, 0.62, wo)},
                            opt_positions={(5, wo): 200.0}, etf_levels=None, live=True)
        act = type("A", (), {"option_quotes": {}, "option_orders": [], "ioc": []})()
        bot.options(s, act, mids, 12 * 3600, False)
        sells = [o for o in act.option_orders if o[2] == "-"]
        self.assertTrue(all(o[5].startswith("opt_trim") for o in sells))   # v10.3: only profit-taking on the long
        self.assertLessEqual(sum(o[3] for o in sells), 200)                 # never past flat
        qa = act.option_quotes.get(5)
        self.assertTrue(qa is None or qa[4] == 0)

    def test_reach_capped_and_budgeted(self):
        huge = [(50.08, 1), (51.50, 500)]
        self.assertLessEqual(Bot.affordable_reach(huge, 50.0, 50, True), C.SETTLE_PUSH["reach_cap"])
        self.assertAlmostEqual(Bot.affordable_reach([(50.08, 1)], 50.0, 50, True), 0.08)
        self.assertAlmostEqual(Bot.affordable_reach([(49.90, 1)], 50.0, 50, False), 0.10)

    def test_bias_raises_up_value(self):
        asks, bids = [(50.08, 1)], [(49.92, 1)]
        flat = self.value_of_long_up(asks, bids, 50.05, bias=0.0, book_reach=False)
        biased = self.value_of_long_up(asks, bids, 50.05, bias=0.012, book_reach=False)
        self.assertGreaterEqual(biased[0], flat[0])

    def test_adapter_supplies_book_every_tick_and_sets_bias(self):
        ad = FakeAdapter()
        self.assertEqual(ad.strategy.om.bias, C.LIVE["settle_bias"])


class DeltaHedgeTests(unittest.TestCase):
    """FEATURES.delta_hedge: hold ETF against the option book's delta."""

    def snap(self, pos, left):
        wo = pd.Timestamp(NOW, unit="s", tz="UTC")
        books = {p: (9.97, 10.03, 7, 7) for p in C.PRODUCTS}
        books["etf"] = (49.95, 50.05, 5, 5)
        return wo, SimpleNamespace(ts=wo + pd.Timedelta(seconds=300 - left), books=books,
                                   options={5: (0.45, 0.55, wo)}, opt_positions={(5, wo): float(pos)})

    def bot(self):
        return Bot(centre_mode="mid", features=dict(C.FEATURES, delta_hedge=True))

    def test_long_up_is_hedged_short_etf_and_capped(self):
        b = self.bot()
        wo, s = self.snap(500, 120)
        b.strikes[(5, wo)] = 50.0
        mids = {"etf": 50.0}
        t = b.delta_hedge_target(s, mids, 12 * 3600)
        self.assertLess(t, 0)
        self.assertGreaterEqual(t, -C.DELTA_HEDGE["max_units"])
        wo, s = self.snap(-100, 120)
        b.strikes[(5, wo)] = 50.0
        self.assertGreater(b.delta_hedge_target(s, mids, 12 * 3600), 0)

    def test_last_seconds_ignored(self):
        b = self.bot()
        wo, s = self.snap(500, C.DELTA_HEDGE["skip_last_s"] - 1)
        b.strikes[(5, wo)] = 50.0
        self.assertEqual(b.delta_hedge_target(s, {"etf": 50.0}, 12 * 3600), 0)

    def test_adapter_hedge_cap_and_feature_wiring(self):
        ad = FakeAdapter()
        self.assertEqual(ad.strategy.hedge_max, C.LIVE["delta_hedge_units"])
        self.assertEqual(ad.strategy.f["delta_hedge"], C.FEATURES["delta_hedge"] and ad.settings["enable_options"])


if __name__ == "__main__":
    unittest.main()


class V8Tests(unittest.TestCase):
    """v8: tick time guards (no more 5 s kills) and the option model changes."""

    def test_busy_state_lock_skips_tick_quickly(self):
        bot = FakeAdapter(); bot.feed(state())
        bot._state_lock.acquire()               # simulate the SDK holding the lock during a slow batch
        try:
            t0 = time.monotonic()
            bot.on_tick()
            self.assertLess(time.monotonic() - t0, 1.5)
            self.assertEqual(bot.requests, [])
            self.assertTrue(any("lock busy" in m for m in bot.messages))
        finally:
            bot._state_lock.release()
        bot.on_tick()                           # lock free again: trades normally
        self.assertTrue(bot.requests)

    def test_inflight_batch_skips_tick_without_touching_state(self):
        bot = FakeAdapter(); bot.feed(state())
        fut = mock.Mock(); fut.done.return_value = False
        bot._inflight = fut
        with mock.patch("exchange_adapter.BACKTEST", False):
            bot.on_tick()
        self.assertEqual(bot.requests, [])
        self.assertTrue(any("still running" in m for m in bot.messages))

    def test_over_budget_tick_does_not_cancel_quotes(self):
        bot = FakeAdapter(); bot.feed(state())
        bot.settings["send_budget_s"] = -1.0    # every tick counts as over budget
        bot.on_tick()
        self.assertEqual(bot.requests, [])      # nothing sent, and no cancelAll either
        self.assertTrue(any("over budget" in str(m) for m in bot.messages))

    def test_sdk_surface_logged_once(self):
        bot = FakeAdapter(); bot.feed(state())
        bot.on_tick(); bot.feed(state(ts=NOW + 1)); bot.on_tick()
        self.assertEqual(sum("SDK methods" in m for m in bot.messages), 1)

    def test_60m_fat_tails_only(self):
        from models import OptionModel
        om = OptionModel(); om.nu = {60: 8}
        sod = 36000
        # far out of the money: the t-distribution gives a fatter tail on 60m; 5m unchanged
        p_norm = om.prob_up(sod, 1800, 54.0, 55.5, exp=5)
        p_t = om.prob_up(sod, 1800, 54.0, 55.5, exp=60)
        self.assertGreater(p_t, p_norm)
        self.assertAlmostEqual(om.prob_up(sod, 1800, 55.0, 55.0, exp=60), om.prob_up(sod, 1800, 55.0, 55.0, exp=5), 2)

    def test_5m_take_needs_10c(self):
        o = C.OPTIONS
        self.assertEqual(o["take_edge_by_exp"][5], 0.10)
        self.assertEqual(o["take_edge_by_exp"][60], 0.05)


class StrawFlowTests(unittest.TestCase):
    def test_target_from_count(self):
        bot = Bot(centre_mode="mid")
        s = SimpleNamespace(straw150_count=0)
        self.assertEqual(bot.straw_target(s, late=False), C.STRAW_FLOW["max_units"] * 0 + min(
            C.STRAW_FLOW["max_units"], round(C.STRAW_FLOW["intercept"] / C.STRAW_FLOW["full_at"] * C.STRAW_FLOW["max_units"])))
        s.straw150_count = 6                                 # heavy buying -> expect a fall -> short
        self.assertLess(bot.straw_target(s, late=False), 0)
        s.straw150_count = None                              # no tape -> no position
        self.assertEqual(bot.straw_target(s, late=False), 0.0)
        s.straw150_count = 0
        self.assertEqual(bot.straw_target(s, late=True), 0.0)

    def test_find_trades_in_various_shapes(self):
        from exchange_adapter import _find_trades_frame
        df = pd.DataFrame({"ts": pd.to_datetime([NOW], unit="s", utc=True), "product": ["strawberries"],
                           "price": [9.0], "size": [150], "aggressor": ["buy"]})
        self.assertIs(_find_trades_frame(df), df)
        self.assertIs(_find_trades_frame({"option_trades": df.rename(columns={"product": "x"}), "trades": df}), df)
        with tempfile.TemporaryDirectory() as d:
            df.to_parquet(os.path.join(d, "trades_2026-10-10.parquet"))
            self.assertEqual(len(_find_trades_frame(d)), 1)
        self.assertIsNone(_find_trades_frame(None))

    def test_tape_count_window_and_staleness(self):
        from exchange_adapter import TapeFetcher
        tf = TapeFetcher(FakeAdapter())
        self.assertIsNone(tf.count(NOW))
        tf.times = np.array([NOW - 8000, NOW - 3000, NOW - 10])
        tf.covers_from = NOW - 20000; tf.last_ok = time.time()
        self.assertEqual(tf.count(NOW), 2)
        tf.last_ok = time.time() - 10 * C.STRAW_FLOW["refresh_s"]
        self.assertIsNone(tf.count(NOW))

    def test_live_snapshot_carries_count_and_never_blocks(self):
        bot = FakeAdapter({"straw_flow": True}); bot.feed(state())
        bot.tape.times = np.array([NOW - 100]); bot.tape.covers_from = NOW - 20000; bot.tape.last_ok = time.time()
        view = bot.view(); bot._reset_if_needed(view)
        snap = bot.build_snapshot(view)
        self.assertEqual(snap.straw150_count, 1)


class AsyncOrderTests(unittest.TestCase):
    def test_on_tick_returns_fast_even_if_batch_is_slow(self):
        bot = FakeAdapter({"async_orders": True}); bot.feed(state())
        slow = threading.Event()
        def slow_batch(actions):
            slow.wait(3.0)
            bot.requests.append(copy.deepcopy(actions))
            return [{"status": "ok"} for _ in actions]
        bot.batch = slow_batch
        with mock.patch("exchange_adapter.BACKTEST", False):
            t0 = time.monotonic(); bot.on_tick(); dt = time.monotonic() - t0
            self.assertLess(dt, 1.0)                      # tick returned while the batch is still "on the wire"
            bot.feed(state(ts=NOW + 1)); t0 = time.monotonic(); bot.on_tick()
            self.assertLess(time.monotonic() - t0, 1.0)   # next tick skips instead of waiting
            slow.set(); bot._inflight.result(timeout=5)
        self.assertTrue(bot.requests)


class V9Tests(unittest.TestCase):
    """v9: late push inside the close second, call-latency guard, requote throttle, unwind, dynamic expiries."""

    def close_second_state(self, strike=50.10, pos=500, offset_ms=100):
        raw = state(positions={"up5": pos})
        for p in raw["products"]:
            if p["symbol"] == "up5":
                p["option"]["strike"] = strike
                close = p["option"]["windowClose"]
        raw["serverTime"] = close * 1000 + offset_ms                  # 0.1 s into the close second
        raw["account"]["dayEnd"] = (close + 8 * 3600) * 1000
        raw["books"]["etf"] = {"bids": [{"price": 49.95, "qty": 3}, {"price": 49.90, "qty": 20}],
                               "asks": [{"price": 50.05, "qty": 3}, {"price": 50.08, "qty": 4},
                                        {"price": 50.12, "qty": 10}, {"price": 50.20, "qty": 30}],
                               "lastTradePrice": 50.0}
        return raw, close

    def test_close_second_window_detected(self):
        raw, close = self.close_second_state()
        bot = FakeAdapter({"enable_options": True}); bot.feed(raw)
        view = bot.view(); bot._reset_if_needed(view)
        snap = bot.build_snapshot(view)
        self.assertEqual(len(snap.late_windows), 1)
        w = snap.late_windows[0]
        self.assertEqual((w["exp"], w["pos"], w["strike"]), (5, 500, 50.10))
        self.assertEqual(snap.push_windows, [])                      # seconds_left is 0: the old rule never fired here

    def test_late_push_batch_and_timing(self):
        raw, close = self.close_second_state()
        bot = FakeAdapter({"enable_options": True}); bot.feed(raw)
        sleeps = []
        with mock.patch("exchange_adapter.time.sleep", side_effect=lambda s: sleeps.append(s)):
            bot.on_tick()
        # v14.1: the push batch, then a SEPARATE blind open buy for the new 5m window
        self.assertEqual(len(bot.requests), 2)
        ob = C.OPTIONS["open_up_buy"][5]
        self.assertEqual(bot.requests[1], [{"type": "order", "symbol": "up5", "side": "buy", "price": ob["first_limit"],
                                            "qty": ob["first_qty"], "orderType": "ioc"}])
        b = bot.requests[0]
        self.assertTrue(all(a.get("symbol") != "up5" for a in b))         # never inside the (atomic) push batch
        self.assertEqual(b[0], {"type": "cancelAll", "symbol": "etf"})  # our own ETF quotes go first
        orders = [a for a in b if a["type"] == "order"]
        wall, walk, prt = orders[0], orders[1], orders[2]                 # v9.2 order: wall, walk (A), print (B) LAST
        self.assertEqual((wall["side"], wall["orderType"], wall["price"]), ("buy", "limit", 50.11))   # v10: one tick inside
        self.assertEqual(wall["qty"], C.LIVE["late_wall_units"])
        self.assertEqual((walk["side"], walk["orderType"], walk["price"]), ("buy", "ioc", 50.09))  # last tick below 50.10
        # v10: 3 + 4 units below the strike plus the buffer, but at least late_min_walk (it only fills wrong-side levels)
        self.assertEqual(walk["qty"], max(C.LIVE["late_min_walk"], 7 + C.LIVE["late_push_buffer"]))
        self.assertEqual((prt["side"], prt["qty"], prt["orderType"]), ("buy", 1, "ioc"))
        self.assertAlmostEqual(prt["price"], 50.10 + C.LIVE["late_push_b_reach"])   # generous: any print >= strike wins
        self.assertEqual(len(sleeps), 1)
        # arrive at close + late_push_at_s: tick is 0.1 s into the second, minus half a round trip (0.08 s default)
        self.assertAlmostEqual(sleeps[0], C.LIVE["late_push_at_s"] - 0.1 - 0.08, delta=0.15)   # timing: loose under load
        # same close second again: no second late push for that window
        raw2 = copy.deepcopy(raw); raw2["serverTime"] += 300
        bot.feed(raw2)
        with mock.patch("exchange_adapter.time.sleep"):
            bot.on_tick()
        self.assertEqual(len(bot.requests), 2)

    def test_no_blind_open_buy_when_gated_or_off(self):
        from collections import deque
        raw, close = self.close_second_state()
        bot = FakeAdapter({"enable_options": True}); bot.feed(raw)
        with mock.patch("exchange_adapter.time.sleep"), mock.patch.object(Bot, "up_gate", return_value=False):
            bot.on_tick()                                                # UP lost too often lately: gate closed
        self.assertEqual(len(bot.requests), 1)
        raw, close = self.close_second_state()
        bot = FakeAdapter({"enable_options": True, "open_first_buy": False}); bot.feed(raw)
        with mock.patch("exchange_adapter.time.sleep"):
            bot.on_tick()
        self.assertEqual(len(bot.requests), 1)

    def test_late_push_for_down_position_sells_and_walls_below_strike(self):
        raw, close = self.close_second_state(strike=49.93, pos=-300)
        bot = FakeAdapter({"enable_options": True}); bot.feed(raw)
        with mock.patch("exchange_adapter.time.sleep"):
            bot.on_tick()
        orders = [a for a in bot.requests[0] if a["type"] == "order"]
        self.assertTrue(all(o["side"] == "sell" for o in orders))
        prt = [o for o in orders if o["qty"] == 1 and o["orderType"] == "ioc"][0]
        self.assertLess(prt["price"], 49.93)
        wall = [o for o in orders if o["orderType"] == "limit"][0]
        self.assertLess(wall["price"], 49.93)

    def test_slow_call_starts_cooldown_and_skips_requotes(self):
        bot = FakeAdapter({"slow_call_s": 0.0, "enable_options": False}); bot.feed(state())
        bot.on_tick()                                              # first call is "slow" (> 0 s) -> cooldown
        self.assertTrue(bot._cooling_down())
        n = len(bot.requests)
        bot.feed(state(ts=NOW + 1)); bot.on_tick()
        self.assertEqual(len(bot.requests), n)                     # plain requote skipped during the cooldown
        self.assertTrue(any("pausing non-critical" in m for m in bot.messages))

    def test_pipe_mode_throttles_quote_only_refreshes(self):
        with mock.patch("exchange_adapter.BACKTEST", True):
            bot = FakeAdapter({"enable_options": False}); bot.feed(state())
            bot.on_tick()
            n = len(bot.requests)
            raw = state(ts=NOW + 1); raw["books"]["apples"]["bids"][0]["price"] = 9.97
            bot.feed(raw); bot.on_tick()
            self.assertEqual(len(bot.requests), n)                 # within requote_s: not sent
            self.assertEqual(bot._throttled, 1)

    def test_etf_unwind_ioc_away_from_close(self):
        bot = Bot(centre_mode="mid")
        snap = pair_snapshot(150, 10.0, 11.0, positions={"etf": 70})   # NOW+150: 150 s into a 5m window
        act = bot.on_second(snap)
        unw = [x for x in act.ioc if x[4] == "unwind"]
        self.assertEqual(len(unw), 1)
        self.assertEqual((unw[0][1], unw[0][2]), ("-", min(70, C.ETF_UNWIND["clip"])))   # v10: clip 20
        snap = pair_snapshot(290, 10.0, 11.0, positions={"etf": 70})   # 10 s before the close: leave it alone
        self.assertFalse([x for x in Bot(centre_mode="mid").on_second(snap).ioc if x[4] == "unwind"])

    def test_dynamic_expiries_pick_up_15m(self):
        raw = state()
        wo = NOW // 900 * 900
        raw["products"].append({"id": "up15", "symbol": "up15", "kind": "option", "tickSize": .01, "positionLimit": 500,
                                "option": {"expiryMin": 15, "windowOpen": wo, "windowClose": wo + 900,
                                           "strike": 49.8, "priceSource": "etf_mid"}})
        raw["books"]["up15"] = {"bids": [{"price": .4, "qty": 100}], "asks": [{"price": .6, "qty": 100}], "lastTradePrice": .5}
        bot, view, snap = LiveTests().ready({"enable_options": True}, raw)
        self.assertIn(15, snap.options)
        self.assertEqual(snap.option_src[15], "etf_mid")
        act = bot.strategy.on_second(snap)                          # values it without crashing (p_win etc. defaults)
        self.assertIsNotNone(act)

    def test_flatten_off_and_no_late_wind_down(self):
        self.assertFalse(C.FEATURES["flatten"])
        raw = state(); raw["account"]["dayEnd"] = (NOW + 60) * 1000
        bot, view, snap = LiveTests().ready(raw=raw)
        self.assertFalse(snap.late or snap.very_late)


class V9PushQuoteTests(unittest.TestCase):
    def test_no_own_etf_quotes_in_push_batch(self):
        # strategy level: a push second must not re-place our ETF quotes (they could print on the wrong side)
        bot = Bot(centre_mode="mid", features={"settle_push": True})
        snap = pair_snapshot(299, 10.0, 11.0)
        wo = pd.Timestamp(NOW, unit="s", tz="UTC")
        snap.live = True
        snap.push_windows = [dict(exp=5, wo=wo, strike=50.10, pos=500)]
        snap.etf_levels = ([(49.97, 5), (49.95, 20)], [(50.03, 3), (50.08, 4), (50.12, 10)])
        snap.last_etf_print = 50.0
        act = bot.on_second(snap)
        self.assertTrue([x for x in act.ioc if x[4] == "push"])
        b, nb, a, na = act.quotes["etf"]
        self.assertEqual((nb, na), (0, 0))


class V92Tests(unittest.TestCase):
    """v9.2: early/late option take edge, 2-hour reversion targets, short-day option caps."""

    def option_bot(self):
        feats = dict(C.FEATURES, settle_push=False, settle_value=False, book_reach=False, option_take=True,
                     option_quote=False)
        return Bot(centre_mode="mid", features=feats)

    def take_at(self, exp, left, edge_gap):
        """Offer UP at (model value - edge_gap) with `left` seconds to go; return the take orders."""
        bot = self.option_bot()
        wo = pd.Timestamp(NOW - NOW % (exp * 60), unit="s", tz="UTC")
        ts = wo + pd.Timedelta(seconds=exp * 60 - left)
        mids = {p: 10.0 for p in C.PRODUCTS}
        mids["etf"] = 50.0
        books = {p: (9.97, 10.03, 7, 7) for p in C.PRODUCTS}
        books["etf"] = (49.92, 50.08, 1, 1)
        bot.strikes[(exp, wo)] = 49.95
        sod = ts.hour * 3600 + ts.minute * 60 + ts.second
        drift = C.OPTIONS["drift_by_exp"].get(exp, C.OPTIONS["etf_drift"])
        value = bot.om.prob_up(sod, left, 50.0, 49.95, 50.0, drift, exp=exp)
        ask = round(value - edge_gap, 2)
        s = SimpleNamespace(ts=ts, books=books, options={exp: (round(ask - 0.02, 2), ask, wo)},
                            opt_positions={(exp, wo): 0.0}, etf_levels=None, live=True)
        act = type("A", (), {"option_quotes": {}, "option_orders": [], "ioc": []})()
        bot.options(s, act, mids, sod, False)
        return [o for o in act.option_orders if o[2] == "+"]

    def test_5m_early_needs_20c_late_needs_10c(self):
        self.assertEqual(C.OPTIONS["take_edge_early_by_exp"][5], 0.20)
        self.assertEqual(C.OPTIONS["early_seconds_by_exp"][5], 60)
        self.assertFalse(self.take_at(5, 200, 0.16))     # 16c edge, 200 s left: too early to spend the cap
        self.assertTrue(self.take_at(5, 200, 0.23))      # 23c edge: take even early
        self.assertTrue(self.take_at(5, 40, 0.16))       # last minute: the normal 10c rule

    def test_60m_early_needs_10c_late_needs_5c(self):
        self.assertFalse(self.take_at(60, 1800, 0.08))
        self.assertTrue(self.take_at(60, 1800, 0.12))
        self.assertTrue(self.take_at(60, 300, 0.08))

    def feed_minutes(self, bot, minutes, apples_path, start=0):
        acts = []
        for m in range(start, start + minutes):
            snap = pair_snapshot(60 * m, apples_path(m), 11.0)
            acts.append(bot.on_second(snap))
        return acts

    def test_reversion_targets_after_two_hours(self):
        feats = {"pair_passive": False, "pair_aggressive": False, "straw_flow": False, "option_take": False,
                 "option_quote": False, "settle_push": False, "reversion_2h": True}
        bot = Bot(centre_mode="mid", features=feats)
        # apples rise 50c over 2 hours, everything else flat
        self.feed_minutes(bot, 100, lambda m: 10.0 + 0.5 * m / 120)
        self.assertEqual(bot.rev_targets["apples"], 0.0)            # under 2 h of history: no position
        acts = self.feed_minutes(bot, 30, lambda m: 10.0 + 0.5 * min(m, 120) / 120, start=100)
        self.assertLess(bot.rev_targets["apples"], -50)              # expected give-back -0.3 x ~50c = -15c: (near) full short
        self.assertEqual(bot.rev_targets["oranges"], 0.0)
        self.assertAlmostEqual(bot.rev_pred["apples"], -0.3 * (bot.rev_hist["apples"][-1][1] - bot.rev_hist["apples"][0][1]))
        # the target leans the apples quotes towards selling: ask nearer the mid than the bid
        b, nb, a, na = acts[-1].quotes["apples"]
        mid = 10.5
        self.assertLess(a - mid, mid - b)

    def test_reversion_off_switch(self):
        bot = Bot(centre_mode="mid", features={"reversion_2h": False, "pair_passive": False, "straw_flow": False})
        self.feed_minutes(bot, 130, lambda m: 10.0 + 0.5 * min(m, 120) / 120)
        self.assertEqual(bot.rev_targets["apples"], 0.0)

    def test_short_day_from_config(self):
        raw = state()
        raw["config"] = {"dayLengthMin": 60, "backtestDayMin": 60}
        bot = FakeAdapter({"enable_options": True}); bot.feed(raw)
        view = bot.view(); bot._reset_if_needed(view)
        self.assertTrue(bot.short_day)
        self.assertEqual(bot.strategy.opt_cap_scale, C.SHORT_DAY["option_cap_scale"])
        snap = bot.build_snapshot(view)
        self.assertEqual(bot._cap(view, "up60", snap), int(500 * C.SHORT_DAY["option_cap_scale"][60]))
        self.assertEqual(bot._cap(view, "up5", snap), 500)
        self.assertTrue(any("short_day=True" in m for m in bot.messages))

    def test_long_day_unchanged(self):
        raw = state()
        raw["config"] = {"dayLengthMin": 1440}
        bot = FakeAdapter({"enable_options": True}); bot.feed(raw)
        view = bot.view(); bot._reset_if_needed(view)
        self.assertFalse(bot.short_day)
        self.assertEqual(bot.strategy.opt_cap_scale, {})
        snap = bot.build_snapshot(view)
        self.assertEqual(bot._cap(view, "up60", snap), 500)

    def test_short_day_measured_from_day_ends(self):
        # no dayLengthMin in the config: the second day end 60 minutes after the first marks a short day
        raw = state(day="d1")
        bot = FakeAdapter({"enable_options": True}); bot.feed(raw)
        bot._reset_if_needed(bot.view())
        self.assertFalse(bot.short_day)
        raw2 = state(ts=NOW + 3600, day="d2")
        raw2["account"]["dayEnd"] = raw["account"]["dayEnd"] + 3600 * 1000
        bot.feed(raw2)
        bot._reset_if_needed(bot.view())
        self.assertTrue(bot.short_day)
        self.assertEqual(bot.strategy.opt_cap_scale, C.SHORT_DAY["option_cap_scale"])

    def test_strategy_cap_scale_limits_takes(self):
        bot = self.option_bot()
        bot.opt_cap_scale = {60: 0.4}
        exp, left = 60, 300
        wo = pd.Timestamp(NOW - NOW % 3600, unit="s", tz="UTC")
        ts = wo + pd.Timedelta(seconds=3600 - left)
        mids = {p: 10.0 for p in C.PRODUCTS}; mids["etf"] = 50.0
        books = {p: (9.97, 10.03, 7, 7) for p in C.PRODUCTS}; books["etf"] = (49.92, 50.08, 1, 1)
        bot.strikes[(exp, wo)] = 49.0                 # UP nearly certain, offered cheap
        sod = ts.hour * 3600 + ts.minute * 60 + ts.second
        for pos, expect in ((150, 50), (200, 0)):
            s = SimpleNamespace(ts=ts, books=books, options={exp: (0.48, 0.50, wo)},
                                opt_positions={(exp, wo): float(pos)}, etf_levels=None, live=True)
            act = type("A", (), {"option_quotes": {}, "option_orders": [], "ioc": []})()
            bot.options(s, act, mids, sod, False)
            got = sum(o[3] for o in act.option_orders if o[2] == "+")
            self.assertEqual(got, expect)

    def test_log_line_shows_reversion_state(self):
        bot = FakeAdapter({"enable_options": True})
        self.assertIn("warming up", bot._rev_text())


def match_batch(asks, bids, wire):
    """Tiny matching engine: apply our batch in order to a book. Returns the prints [(price, qty)], one per order that
    traded, each at the order's AVERAGE fill price (how the exchange records a trade)."""
    asks = [list(x) for x in sorted(asks)]
    bids = [list(x) for x in sorted(bids, reverse=True)]
    prints = []
    for o in wire:
        if o.get("type") != "order":
            continue
        need, cost, got = o["qty"], 0.0, 0
        book = asks if o["side"] == "buy" else bids
        while need and book:
            px, q = book[0]
            if (o["side"] == "buy" and px > o["price"] + 1e-9) or (o["side"] == "sell" and px < o["price"] - 1e-9):
                break
            f = min(need, q); need -= f; got += f; cost += f * px; book[0][1] -= f
            if book[0][1] == 0:
                book.pop(0)
        if got:
            prints.append((round(cost / got, 4), got))
        if need and o["orderType"] == "limit":                     # rests on the book
            (bids if o["side"] == "buy" else asks).append([o["price"], need])
            bids.sort(key=lambda x: -x[0]); asks.sort(key=lambda x: x[0])
    return prints


class V92PushSafetyTests(unittest.TestCase):
    """v9.2 regression: our own late push must never leave the settle print on the wrong side because the book changed
    between our look and our arrival (Oct 10: 5 windows the early push had already won were lost this way)."""

    def late_wire(self, strike, pos, seen_asks, seen_bids):
        raw, close = V9Tests().close_second_state(strike=strike, pos=pos)
        raw["books"]["etf"] = {"bids": [{"price": p, "qty": q} for p, q in seen_bids],
                               "asks": [{"price": p, "qty": q} for p, q in seen_asks], "lastTradePrice": strike}
        bot = FakeAdapter({"enable_options": True}); bot.feed(raw)
        with mock.patch("exchange_adapter.time.sleep"):
            bot.on_tick()
        return bot.requests[0] if bot.requests else []

    def test_refilled_level_below_strike_cannot_take_our_last_print(self):
        # we SAW no ask below the strike (the early push took them); on arrival the house has refilled 50.06 x15, 50.08 x10
        wire = self.late_wire(50.10, 500, [(50.12, 10), (50.20, 30)], [(49.95, 3)])
        prints = match_batch([(50.06, 15), (50.08, 10), (50.12, 10), (50.20, 30)], [(49.95, 3)], wire)
        self.assertTrue(prints)
        self.assertGreaterEqual(prints[-1][0], 50.10)          # our LAST print is on our side

    def test_more_refill_than_seen(self):
        wire = self.late_wire(50.10, 500, [(50.05, 3), (50.08, 4), (50.12, 10)], [(49.95, 3)])
        prints = match_batch([(50.05, 3), (50.07, 12), (50.08, 20), (50.12, 10)], [(49.95, 3)], wire)
        self.assertGreaterEqual(prints[-1][0], 50.10)

    def test_down_push_mirror(self):
        wire = self.late_wire(49.93, -300, [(50.05, 3)], [(49.90, 10), (49.85, 20)])
        prints = match_batch([(50.05, 3)], [(49.97, 15), (49.95, 10), (49.90, 10), (49.85, 20)], wire)
        self.assertLess(prints[-1][0], 49.93)

    def test_old_v9_wire_would_have_lost(self):
        # what v9.1 sent in the first scenario: B (1 @ 50.15) then the wall bid @ 50.10, no walk
        old = [{"type": "order", "side": "buy", "qty": 1, "price": 50.15, "orderType": "ioc"},
               {"type": "order", "side": "buy", "qty": 10, "price": 50.10, "orderType": "limit"}]
        prints = match_batch([(50.06, 15), (50.08, 10), (50.12, 10)], [], old)
        self.assertLess(prints[-1][0], 50.10)                   # -> settle below the strike: the bug v9.2 fixes


# ======================================================================================================== v10 tests
class V10PushOrderTests(unittest.TestCase):
    """robust_push_orders: every range shape, and replays of the exact Oct 10 batches (book refilled before arrival)."""

    @staticmethod
    def fill(orders, asks, bids):
        """Execute orders in SEND order (walls first, like the adapter) against a book; IOCs walk within their limit,
        a wall trades whatever it crosses and rests. Returns the prints (avg fill price per order), in order."""
        rank = {"wall": 0, "push_a": 1, "push_b": 2}
        wire = sorted(orders, key=lambda o: rank.get(o[4], 1))
        asks = [list(x) for x in asks]; bids = [list(x) for x in bids]
        prints = []
        for side, qty, px, ioc, role in wire:
            book = asks if side == "+" else bids
            need, cost, done = qty, 0.0, 0
            for lvl in book:
                if need <= 0:
                    break
                if (side == "+" and lvl[0] > px + 1e-9) or (side == "-" and lvl[0] < px - 1e-9):
                    break
                f = min(need, lvl[1]); lvl[1] -= f; need -= f; cost += f * lvl[0]; done += f
            book[:] = [l for l in book if l[1] > 0]
            if done:
                prints.append(round(cost / done, 4))
        return prints

    def test_1530_refill_below_strike_now_wins(self):
        from strategy import robust_push_orders
        # 15:30 UTC: strike 55.57. On arrival the market maker had refilled 11 units at 55.56 (below the strike).
        arrival_asks = [(55.56, 11), (55.58, 3), (55.60, 10)]
        orders = robust_push_orders("+", 55.57, float("inf"), 60, 0.40, 10)
        self.assertGreaterEqual(self.fill(orders, arrival_asks, [(55.53, 5)])[-1], 55.57)
        v9 = [("+", 1, 55.60, True, "push_b"), ("+", 10, 55.57, False, "push_a")]      # v9.1: print, then a marketable wall
        self.assertLess(self.fill(v9, arrival_asks, [(55.53, 5)])[-1], 55.57)

    def test_1415_seller_then_refill_now_wins(self):
        from strategy import robust_push_orders
        arrival_asks = [(56.08, 20), (56.11, 5), (56.13, 6), (56.16, 21)]
        orders = robust_push_orders("+", 56.14, float("inf"), 60, 0.40, 10)
        self.assertGreaterEqual(self.fill(orders, arrival_asks, [(56.00, 5)])[-1], 56.14)

    def test_down_side_mirror_and_offgrid_strike(self):
        from strategy import robust_push_orders
        orders = robust_push_orders("-", float("-inf"), 55.402, 60, 0.40, 10)   # print < 55.402: 55.41+ must go
        self.assertEqual(orders[0][:3], ("-", 60, 55.41))
        self.assertEqual(orders[1][:3], ("-", 1, 55.00))                          # 55.40 - 0.40
        self.assertEqual(orders[2][:4], ("-", 10, 55.39, False))                  # wall one tick inside
        self.assertLess(self.fill(orders, [(55.45, 5)], [(55.43, 4), (55.41, 9), (55.40, 7), (55.38, 20)])[-1], 55.402)

    def test_tie_counts_up(self):
        from strategy import robust_push_orders
        orders = robust_push_orders("+", 55.40, float("inf"), 60, 0.40, 0)
        self.assertEqual(orders[0][2], 55.39)                                     # 55.40 itself is fine (a tie is UP)
        self.assertEqual(self.fill(orders, [(55.40, 3)], [(55.3, 1)])[-1], 55.40)

    def test_mixed_and_empty_range(self):
        from strategy import robust_push_orders
        o = robust_push_orders("+", 55.40, 55.43, 60, 0.40, 10)                 # 55.40 <= print < 55.43
        self.assertEqual(o[1][2], 55.42)
        self.assertEqual([x[2] for x in o if x[4] == "wall"], [55.40, 55.42])    # inside walls would cross -> boundary
        o = robust_push_orders("+", 55.40, 55.45, 60, 0.40, 10)                 # wider: walls one tick inside
        self.assertEqual([x[2] for x in o if x[4] == "wall"], [55.41, 55.43])
        self.assertEqual(robust_push_orders("+", 55.405, 55.41, 60), [])         # no tick in [55.405, 55.41)

    def test_unbounded_side_never_walks(self):
        from strategy import robust_push_orders
        # UP target printed by SELLING (market already above): no walk, sell 1 at >= the strike, bid wall at the strike
        o = robust_push_orders("-", 50.00, float("inf"), 60, 0.40, 10)
        self.assertEqual([x[:4] for x in o], [("-", 1, 50.00, True), ("+", 10, 50.01, False)])
        # DOWN target printed by BUYING (market already below): buy 1 below the strike, ask wall below the strike
        o = robust_push_orders("+", float("-inf"), 50.00, 60, 0.40, 10)
        self.assertEqual([x[:4] for x in o], [("+", 1, 49.99, True), ("-", 10, 49.98, False)])


class V10AdapterPushTests(unittest.TestCase):
    def late_wire(self, strike, pos, seen_asks, seen_bids, deep_key=False):
        raw, close = V9Tests().close_second_state(strike=strike, pos=pos)
        raw["books"]["etf"] = {"bids": [{"price": p, "qty": q} for p, q in seen_bids],
                               "asks": [{"price": p, "qty": q} for p, q in seen_asks], "lastTradePrice": strike}
        bot = FakeAdapter({"enable_options": True}); bot.feed(raw)
        if deep_key:
            bot._reset_if_needed(bot.view()); bot.strategy.f["deep_push"] = True
            view = bot.view(); bot._reset_if_needed(view)
            wo = pd.Timestamp(close - 300, unit="s", tz="UTC")
            bot.strategy.deep_keys.add((5, wo))
            bot.strategy.pushed[(5, wo)] = 40
        with mock.patch("exchange_adapter.time.sleep"):
            bot.on_tick()
        return bot, (bot.requests[0] if bot.requests else [])

    def test_down_window_already_in_the_money_no_crash(self):
        # v9.2 raised OverflowError here (ceil_tick(-inf)) and sent nothing
        bot, wire = self.late_wire(50.10, -300, [(50.00, 5), (50.05, 10)], [(49.95, 5)])
        self.assertFalse([m for m in bot.messages if "Error" in m])
        orders = [o for o in wire if o.get("type") == "order"]
        self.assertTrue(orders)
        self.assertEqual((orders[-1]["side"], orders[-1]["qty"]), ("buy", 1))    # B: buy 1 below the strike
        self.assertLess(orders[-1]["price"], 50.10)
        prints = match_batch([(50.00, 5), (50.05, 10)], [(49.95, 5)], wire)
        self.assertLess(prints[-1][0], 50.10)

    def test_late_walk_floor_clears_big_refill(self):
        # saw 7 wrong-side units; on arrival 45 are there -> the 60-unit floor still clears them
        bot, wire = self.late_wire(50.10, 500, [(50.05, 3), (50.08, 4), (50.12, 10)], [(49.95, 3)])
        walk = [o for o in wire if o.get("type") == "order" and o["orderType"] == "ioc" and o["qty"] > 1][0]
        self.assertEqual(walk["qty"], max(C.LIVE["late_min_walk"], 7 + C.LIVE["late_push_buffer"]))
        prints = match_batch([(50.04, 15), (50.06, 15), (50.08, 15), (50.12, 10)], [(49.95, 3)], wire)
        self.assertGreaterEqual(prints[-1][0], 50.10)

    def test_deep_stage2_full_budget_walk(self):
        # after a stage-1 deep push the strike is still beyond the visible ladder: walk the rest of the budget at the strike
        bot, wire = self.late_wire(50.30, 500, [(50.05, 30), (50.10, 30), (50.15, 30)], [(49.95, 3)], deep_key=True)
        orders = [o for o in wire if o.get("type") == "order"]
        walk = [o for o in orders if o["orderType"] == "ioc" and o["qty"] > 1]
        self.assertTrue(walk, orders)
        budget = C.SETTLE_PUSH["max_units"] + C.SETTLE_PUSH["late_extra_units"] - 40
        self.assertEqual((walk[0]["side"], walk[0]["price"]), ("buy", 50.29))
        self.assertLessEqual(walk[0]["qty"], budget - 1)
        self.assertTrue(any("DEEP" in m for m in bot.messages))

    def test_unreachable_without_stage1_sends_nothing(self):
        bot, wire = self.late_wire(50.30, 500, [(50.05, 30), (50.10, 30), (50.15, 30)], [(49.95, 3)])
        self.assertFalse([o for o in wire if o.get("type") == "order"])


class V10DeepStage1Tests(unittest.TestCase):
    def test_deep_stage1_walks_whole_ladder_when_unreachable(self):
        bot = Bot(centre_mode="mid", features={"settle_push": True, "deep_push": True})
        snap = pair_snapshot(299, 10.0, 11.0)
        wo = pd.Timestamp(NOW, unit="s", tz="UTC")
        snap.live = True
        snap.push_windows = [dict(exp=5, wo=wo, strike=50.20, pos=500)]
        snap.etf_levels = ([(49.97, 5)], [(50.03, 3), (50.06, 10), (50.09, 20)])   # ladder ends 11c short of the strike
        snap.last_etf_print = 50.0
        act = bot.on_second(snap)
        pushes = [x for x in act.ioc if x[4] == "push"]
        self.assertEqual(pushes, [("etf", "+", 33, 50.19, "push")])    # all 33 visible units, walk priced at the strike
        self.assertEqual(bot.pushed[(5, wo)], 33)
        self.assertIn((5, wo), bot.deep_keys)
        bot = Bot(centre_mode="mid", features={"settle_push": True, "deep_push": True})
        snap.push_windows = [dict(exp=5, wo=wo, strike=50.40, pos=500)]   # beyond deep_reach: nothing
        self.assertFalse([x for x in bot.on_second(snap).ioc if x[4] == "push"])

    def test_early_push_down_window_in_the_money_no_crash(self):
        bot = Bot(centre_mode="mid", features={"settle_push": True})
        snap = pair_snapshot(299, 10.0, 11.0)
        wo = pd.Timestamp(NOW, unit="s", tz="UTC")
        snap.live = True
        snap.push_windows = [dict(exp=5, wo=wo, strike=50.20, pos=-300)]
        snap.etf_levels = ([(49.97, 5)], [(50.03, 3), (50.06, 10)])
        snap.last_etf_print = 50.0
        pushes = [x for x in bot.on_second(snap).ioc if x[4] == "push"]
        self.assertTrue(pushes)
        self.assertEqual(pushes[-1][1:3], ("+", 1))                     # buy 1 below the strike
        self.assertLess(pushes[-1][3], 50.20)


class V10JumpTests(unittest.TestCase):
    @staticmethod
    def snap(i, straw_mid, wm_mid=12.0, pos=None):
        mids = dict(zip(C.PRODUCTS, [10.0, 8.0, 11.0, straw_mid, wm_mid, 50.0]))
        books = {p: (round(m - .02, 2), round(m + .02, 2), 7, 7) for p, m in mids.items()}
        return SimpleNamespace(ts=pd.Timestamp(NOW + i, unit="s", tz="UTC"), books=books, etf_trades=[], options={},
                               positions=dict(pos or {}), opt_positions={}, pnl=0.0, late=False, very_late=False)

    def test_three_up_jumps_fire_one_strawberry_buy(self):
        bot = Bot(centre_mode="mid")
        path = [9.00] * 5 + [9.08] + [9.08] * 20 + [9.16] + [9.16] * 20 + [9.24] + [9.24] * 5
        fired = []
        for i, m in enumerate(path):
            act = bot.on_second(self.snap(i, m))
            fired += [x for x in act.ioc if x[4] == "straw"]
        self.assertEqual(len(fired), 1)
        self.assertEqual(fired[0][:3], ("strawberries", "+", C.JUMPS["straw_units"]))
        self.assertEqual(bot.jump_stats["straw_fires"], 1)
        q = bot.on_second(self.snap(len(path), 9.24)).quotes["strawberries"]
        self.assertGreater(q[1], 0)                          # still bidding (target long)

    def test_down_jumps_and_slow_drift_do_not_fire(self):
        bot = Bot(centre_mode="mid")
        path = [9.30] * 3 + [9.22] * 10 + [9.14] * 10 + [9.06] * 10 + [9.10 + 0.01 * k for k in range(30)]
        fired = [x for i, m in enumerate(path) for x in bot.on_second(self.snap(i, m)).ioc if x[4] == "straw"]
        self.assertEqual(fired, [])

    def test_jumps_across_a_data_gap_ignored(self):
        bot = Bot(centre_mode="mid")
        for i, m in [(0, 9.0), (5, 9.10), (10, 9.20), (15, 9.30)]:     # 10c steps, but 5 s apart
            bot.on_second(self.snap(i, m))
        self.assertEqual(bot.jump_stats["straw_fires"], 0)

    def test_watermelon_jump_sets_opposite_target(self):
        bot = Bot(centre_mode="mid")
        bot.on_second(self.snap(0, 9.0, 12.00))
        bot.on_second(self.snap(1, 9.0, 12.10))                        # +10c jump
        self.assertEqual(bot.wm_jump[0], 1.0)
        act = bot.on_second(self.snap(2, 9.0, 12.10))
        b, nb, a, na = act.quotes["watermelon"]
        self.assertGreater(na, 0)                                      # leaning to sell watermelon


class V10FloatExactTests(unittest.TestCase):
    """The exchange compares settle >= strike in float64; average prices carry float noise."""

    def test_first_at_or_above_and_last_below(self):
        from strategy import first_at_or_above, last_below
        self.assertEqual(first_at_or_above(55.760000000000005), 55.77)   # 55.76 < 55.760000000000005: a print there loses
        self.assertEqual(last_below(55.760000000000005), 55.76)
        self.assertEqual(first_at_or_above(55.61999999999999), 55.62)
        self.assertEqual(last_below(55.61999999999999), 55.61)
        self.assertEqual(first_at_or_above(55.62), 55.62)
        self.assertEqual(last_below(55.62), 55.61)
        self.assertEqual(first_at_or_above(55.402), 55.41)
        self.assertEqual(last_below(55.402), 55.40)

    def test_noisy_strike_walk_and_print(self):
        from strategy import robust_push_orders
        o = robust_push_orders("+", 55.760000000000005, float("inf"), 60, 0.40, 10)
        self.assertEqual(o[0][:3], ("+", 60, 55.76))                     # the walk takes 55.76 too (it is below the strike)
        prints = V10PushOrderTests.fill(o, [(55.73, 5), (55.76, 9), (55.77, 4)], [(55.70, 3)])
        self.assertGreaterEqual(prints[-1], 55.760000000000005)

    def test_1650_float_tie_replay(self):
        from strategy import robust_push_orders
        # Oct 10 16:50: strike 55.62; v9.1's 10-unit wall printed last at 10 x 55.62 / 10 = 55.61999999999999 -> DOWN
        self.assertLess(10 * 55.62 / 10, 55.62)
        o = robust_push_orders("+", 55.62, float("inf"), 60, 0.40, 10)
        wire = sorted(o, key=lambda x: {"wall": 0, "push_a": 1, "push_b": 2}[x[4]])
        self.assertEqual(wire[-1][4], "push_b")                          # our last print is the exact 1-unit order
        prints = V10PushOrderTests.fill(o, [(55.56, 2), (55.60, 2), (55.61, 1), (55.62, 11), (55.65, 5)], [(55.54, 20)])
        self.assertGreaterEqual(prints[-1], 55.62)


class V101SpeedTests(unittest.TestCase):
    def test_speed_tracked_and_late_push_sleep_scaled(self):
        raw, close = V9Tests().close_second_state()
        bot = FakeAdapter({"enable_options": True}); bot.feed(raw)
        bot._speed = 24.0                                      # a 24x simulation
        sleeps = []
        with mock.patch("exchange_adapter.time.sleep", side_effect=lambda s: sleeps.append(s)):
            bot.on_tick()
        self.assertTrue(bot.requests)
        self.assertTrue(sleeps and sleeps[0] < 0.05)           # ~0.7 / 24 instead of ~0.7

    def test_live_speed_stays_one(self):
        bot = FakeAdapter({"enable_options": True})
        bot._speed_prev = (1000.0, time.monotonic() - 1.0)
        bot._state = {"serverTime": 1001000}
        bot._track_speed()
        self.assertAlmostEqual(bot._clock_speed(), 1.0, delta=0.05)


class V103TrimTests(unittest.TestCase):
    def run_at(self, pos, bid_over_value, left=200, open_buy=False):
        bot = V92Tests().option_bot(); bot.f["open_up_buy"] = open_buy
        exp = 5
        wo = pd.Timestamp(NOW - NOW % 300, unit="s", tz="UTC")
        ts = wo + pd.Timedelta(seconds=300 - left)
        mids = {p: 10.0 for p in C.PRODUCTS}; mids["etf"] = 50.0
        books = {p: (9.97, 10.03, 7, 7) for p in C.PRODUCTS}; books["etf"] = (49.92, 50.08, 1, 1)
        bot.strikes[(exp, wo)] = 49.95
        sod = ts.hour * 3600 + ts.minute * 60 + ts.second
        drift = C.OPTIONS["drift_by_exp"].get(exp, C.OPTIONS["etf_drift"])
        value = bot.om.prob_up(sod, left, 50.0, 49.95, 50.0, drift, exp=exp)
        bid = round(value + bid_over_value, 2)
        s = SimpleNamespace(ts=ts, books=books, options={exp: (bid, round(bid + 0.30, 2), wo)},
                            opt_positions={(exp, wo): float(pos)}, etf_levels=None, live=True)
        act = type("A", (), {"option_quotes": {}, "option_orders": [], "ioc": []})()
        bot.options(s, act, mids, sod, False)
        return [o for o in act.option_orders if o[5].startswith("opt_trim")]

    def test_trims_long_when_bid_rich(self):
        o = self.run_at(300, 0.08)
        self.assertEqual(len(o), 1); self.assertEqual(o[0][2], "-"); self.assertLessEqual(o[0][3], 300)

    def test_never_shorts_or_trims_late_or_cheap(self):
        self.assertFalse(self.run_at(0, 0.10))
        self.assertFalse(self.run_at(300, 0.08, left=40))
        self.assertFalse(self.run_at(300, 0.02))


class V14OpenUpBuyTests(unittest.TestCase):
    def run_at(self, left, ask, pos=0, hist=None, halted=False):
        bot = V92Tests().option_bot(); bot.f["open_up_buy"] = True; bot.halted = halted
        if hist is not None:
            from collections import deque
            bot.up_hist[5] = deque(hist, maxlen=48)
        exp = 5
        wo = pd.Timestamp(NOW - NOW % 300, unit="s", tz="UTC")
        ts = wo + pd.Timedelta(seconds=300 - left)
        mids = {p: 10.0 for p in C.PRODUCTS}; mids["etf"] = 50.0
        books = {p: (9.97, 10.03, 7, 7) for p in C.PRODUCTS}; books["etf"] = (49.92, 50.08, 1, 1)
        bot.strikes[(exp, wo)] = 50.00
        sod = ts.hour * 3600 + ts.minute * 60 + ts.second
        s = SimpleNamespace(ts=ts, books=books, options={exp: (round(ask - 0.05, 2), ask, wo)},
                            opt_positions={(exp, wo): float(pos)}, etf_levels=None, live=True)
        act = type("A", (), {"option_quotes": {}, "option_orders": [], "ioc": []})()
        bot.options(s, act, mids, sod, False)
        return [o for o in act.option_orders if o[5].startswith("opt_open")], bot

    def test_buys_at_open_when_cheap(self):
        o, _ = self.run_at(280, 0.40)
        ob = C.OPTIONS["open_up_buy"][5]
        self.assertEqual(len(o), 1); self.assertEqual(o[0][2], "+")
        self.assertEqual(o[0][4], round(0.40 + ob["sweep_over"], 2)); self.assertEqual(o[0][3], ob["sweep_max"])   # v14.1 sweep
        o, _ = self.run_at(280, round(ob["max_price"] - 0.02, 2)); self.assertEqual(o[0][4], ob["max_price"])   # never above the cap

    def test_respects_price_time_and_cap(self):
        self.assertFalse(self.run_at(280, round(C.OPTIONS["open_up_buy"][5]["max_price"] + 0.01, 2))[0])   # above the cap
        self.assertFalse(self.run_at(200, 0.40)[0])          # after the first 60 s
        self.assertFalse(self.run_at(280, 0.40, pos=500)[0]) # at the cap
        o, _ = self.run_at(280, 0.40, pos=480); self.assertEqual(o[0][3], 20)

    def test_open_first_order(self):
        bot = V92Tests().option_bot(); bot.f["open_up_buy"] = True
        ob = C.OPTIONS["open_up_buy"][5]
        self.assertEqual(bot.open_first_order(5), (ob["first_qty"], ob["first_limit"]))
        bot.halted = True; self.assertIsNone(bot.open_first_order(5)); bot.halted = False
        bot.f["open_up_buy"] = False; self.assertIsNone(bot.open_first_order(5))
        self.assertFalse(self.run_at(280, 0.40, pos=-50)[0]) # never while short
        self.assertFalse(self.run_at(280, 0.40, halted=True)[0])

    def test_gate(self):
        self.assertTrue(self.run_at(280, 0.40, hist=[1, 0, 0])[0])             # too little history: gate open
        self.assertFalse(self.run_at(280, 0.40, hist=[0] * 6 + [1] * 6 + [0] * 6)[0])   # last 12: 6/12... then 0s -> 33%
        self.assertTrue(self.run_at(280, 0.40, hist=[1] * 8 + [0] * 4)[0])     # 67% >= 60%
        self.assertFalse(self.run_at(280, 0.40, hist=[1] * 7 + [0] * 5)[0])    # 58% < 60%

    def test_no_trim_while_open_buy_on(self):
        self.assertFalse(V103TrimTests().run_at(300, 0.08, open_buy=True))

    def test_record_close_feeds_gate(self):
        from collections import deque
        bot = V92Tests().option_bot(); bot.f["open_up_buy"] = True
        ob = C.OPTIONS["open_up_buy"][5]
        for i in range(ob["gate_n"]):
            bot.record_close(5, 1000 + 300 * i, up=(i % 4 != 0))   # 9 of 12 UP = 75% >= 60%
        self.assertEqual(len(bot.up_hist[5]), ob["gate_n"]); self.assertTrue(bot.up_gate(5, ob))
        bot.record_close(5, 1000, up=True)                          # same window again: ignored (dedup)
        self.assertEqual(len(bot.up_hist[5]), ob["gate_n"])
        for i in range(ob["gate_n"]):
            bot.record_close(5, 9000 + 300 * i, up=False)           # 12 losses -> gate shuts
        self.assertFalse(bot.up_gate(5, ob))

    def test_track_closes_records_outcome(self):
        bot = V92Tests().option_bot()
        wo = pd.Timestamp(NOW - NOW % 300, unit="s", tz="UTC")
        bot.open_keys[(5, wo)] = 50.00; bot.last_etf_trade = 50.00          # tie = UP
        bot.track_closes(SimpleNamespace(ts=wo + pd.Timedelta(seconds=300)))
        self.assertEqual(list(bot.up_hist[5]), [1]); self.assertFalse(bot.open_keys)
        wo2 = wo + pd.Timedelta(seconds=300)                                # a DIFFERENT window (dedup is per-window)
        bot.open_keys[(5, wo2)] = 50.00; bot.last_etf_trade = 49.99
        bot.track_closes(SimpleNamespace(ts=wo2 + pd.Timedelta(seconds=301)))
        self.assertEqual(list(bot.up_hist[5]), [1, 0])


class V16RegimeTests(unittest.TestCase):
    def run_at(self, hist, ask=0.40, bid=0.35, pos=0, left=200):
        from collections import deque
        bot = V92Tests().option_bot()
        bot.up_hist[5] = deque(hist, maxlen=48)
        exp = 5
        wo = pd.Timestamp(NOW - NOW % 300, unit="s", tz="UTC")
        ts = wo + pd.Timedelta(seconds=300 - left)
        mids = {p: 10.0 for p in C.PRODUCTS}; mids["etf"] = 50.0
        books = {p: (9.97, 10.03, 7, 7) for p in C.PRODUCTS}; books["etf"] = (49.92, 50.08, 1, 1)
        bot.strikes[(exp, wo)] = 50.30                                   # strike above the ETF: UP is cheap/unlikely
        sod = ts.hour * 3600 + ts.minute * 60 + ts.second
        s = SimpleNamespace(ts=ts, books=books, options={exp: (bid, ask, wo)},
                            opt_positions={(exp, wo): float(pos)}, etf_levels=None, live=True)
        act = type("A", (), {"option_quotes": {}, "option_orders": [], "ioc": []})()
        bot.options(s, act, mids, sod, False)
        return act, bot

    def test_down_regime_never_buys(self):
        act, _ = self.run_at([0] * 12)
        self.assertFalse([o for o in act.option_orders if o[2] == "+"])
        q = act.option_quotes.get(5)
        self.assertTrue(q is None or q[2] == 0)                          # no resting bid

    def test_down_regime_can_short_capped(self):
        act, bot = self.run_at([0] * 12)
        self.assertTrue(bot.regime_sell_ok(5))
        sells = [o for o in act.option_orders if o[2] == "-"]
        q = act.option_quotes.get(5)
        ask_qty = q[4] if q else 0
        self.assertTrue(sells or ask_qty > 0)                            # some way to get short
        cap = C.OPTIONS["regime_sell"][5]["cap"]
        self.assertTrue(all(o[3] <= cap for o in sells))
        act, _ = self.run_at([0] * 12, pos=-cap)                         # at the cap: no more shorting
        self.assertFalse([o for o in act.option_orders if o[2] == "-"])

    def test_neutral_band_does_neither(self):
        _, bot = self.run_at([1, 0, 0] * 4 + [0])                        # ~31-42% UP region checks
        _, bot2 = self.run_at([1, 1, 0, 0] * 3)                          # 50% UP
        self.assertFalse(bot2.regime_sell_ok(5)); self.assertTrue(bot2.regime_buy_ok(5))
        _, bot3 = self.run_at([1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1])      # 5/12 = 42%: neutral
        self.assertFalse(bot3.regime_sell_ok(5)); self.assertFalse(bot3.regime_buy_ok(5))

    def test_up_regime_unchanged(self):
        _, bot = self.run_at([1] * 12)
        self.assertTrue(bot.regime_buy_ok(5)); self.assertFalse(bot.regime_sell_ok(5))

    def test_too_little_history_never_shorts(self):
        _, bot = self.run_at([0] * 5)
        self.assertFalse(bot.regime_sell_ok(5)); self.assertTrue(bot.regime_buy_ok(5))


class V104ShortSwapTests(unittest.TestCase):
    def go(self, pos, bid_over, left):
        tr = V103TrimTests()
        return tr.run_at.__func__  # placeholder

    def run_at(self, pos, bid_over_value, left, ask_gap=0.30):
        bot = V92Tests().option_bot(); bot.f["option_short_swap"] = True
        exp = 5
        wo = pd.Timestamp(NOW - NOW % 300, unit="s", tz="UTC")
        ts = wo + pd.Timedelta(seconds=300 - left)
        mids = {p: 10.0 for p in C.PRODUCTS}; mids["etf"] = 50.0
        books = {p: (9.97, 10.03, 7, 7) for p in C.PRODUCTS}; books["etf"] = (49.92, 50.08, 1, 1)
        bot.strikes[(exp, wo)] = 49.95
        sod = ts.hour * 3600 + ts.minute * 60 + ts.second
        drift = C.OPTIONS["drift_by_exp"].get(exp, C.OPTIONS["etf_drift"])
        value = bot.om.prob_up(sod, left, 50.0, 49.95, 50.0, drift, exp=exp)
        bid = min(0.98, round(value + bid_over_value, 2))
        s = SimpleNamespace(ts=ts, books=books, options={exp: (bid, min(0.99, round(bid + ask_gap, 2)), wo)},
                            opt_positions={(exp, wo): float(pos)}, etf_levels=None, live=True)
        act = type("A", (), {"option_quotes": {}, "option_orders": [], "ioc": []})()
        bot.options(s, act, mids, sod, False)
        return act.option_orders

    def test_shorts_when_rich_midwindow(self):
        o = [x for x in self.run_at(0, 0.40, 200) if x[5].startswith("opt_short")]
        self.assertTrue(o); self.assertEqual(o[0][2], "-"); self.assertLessEqual(o[0][3], 50)

    def test_no_new_short_late_and_cover_late(self):
        self.assertFalse([x for x in self.run_at(0, 0.40, 50) if x[5].startswith("opt_short")])
        cov = [x for x in self.run_at(-300, 0.0, 50) if x[5].startswith("opt_cover")]
        self.assertTrue(cov); self.assertEqual(cov[0][2], "+"); self.assertLessEqual(cov[0][3], 300)

    def test_short_cap(self):
        self.assertFalse([x for x in self.run_at(-500, 0.40, 200) if x[5].startswith("opt_short")])


class V11Tests(unittest.TestCase):
    def test_v11_config(self):
        self.assertFalse(C.FEATURES["option_short_swap"])
        self.assertEqual(C.LIVE["fruit_quote_units"]["apples"], 16); self.assertEqual(C.LIVE["fruit_quote_units"]["etf"], 8)
        self.assertNotIn("watermelon", C.LIVE["fruit_quote_units"])
        self.assertEqual(C.LIVE["fruit_inventory_cap"]["etf"], 30); self.assertFalse(C.FEATURES["momentum_pull"])

    def test_v11_fruit_quote_units_and_caps(self):
        bot, view, snap = LiveTests().ready({"fruit_quote_units": {"apples": 16}, "fruit_inventory_cap": {"apples": 120}})
        from unittest import mock
        from types import SimpleNamespace
        for eq, expect in ((20000, 120), (10000, 30)):
            with mock.patch.object(type(view), "account", new=property(lambda s, e=eq: SimpleNamespace(equity=e))):
                self.assertEqual(bot._cap(view, "apples", snap), min(view.position_limit("apples"), expect))
        self.assertEqual(bot._cap(view, "bananas", snap), min(view.position_limit("bananas"), 30))   # 300 x 0.10


    def test_v11_live_tick_quote_sizes(self):
        bot = FakeAdapter({"enable_options": False, "fruit_quote_units": dict(C.LIVE["fruit_quote_units"]),
                           "fruit_inventory_cap": dict(C.LIVE["fruit_inventory_cap"]), "inventory_scale": 0.25,
                           "quote_size_scale": 0.40})
        bot.feed(state())
        bot.on_tick()
        orders = [a for a in bot.requests[-1] if a["type"] == "order"]
        by = {}
        for o in orders:
            by[o["symbol"]] = max(by.get(o["symbol"], 0), o["qty"])
        for s, q in by.items():
            lim = C.LIVE["fruit_quote_units"].get(s) or max(1, int(C.QUOTE[s]["size"] * 0.40))
            self.assertLessEqual(q, lim, s)
        print("v11 quote sizes", by)


class V12QuoteTests(unittest.TestCase):
    def quote(self, exp, overrides):
        feats = dict(C.FEATURES, option_take=False, option_quote=True, option_short_swap=False)
        bot = Bot(centre_mode="mid", features=feats)
        wo = pd.Timestamp(NOW, unit="s", tz="UTC")
        ts = wo + pd.Timedelta(seconds=exp * 60 - 200)
        mids = {p: 10.0 for p in C.PRODUCTS}; mids["etf"] = 50.0
        books = {p: (9.97, 10.03, 7, 7) for p in C.PRODUCTS}; books["etf"] = (49.98, 50.02, 50, 50)
        bot.strikes[(exp, wo)] = 50.0
        s = SimpleNamespace(ts=ts, books=books, options={exp: (0.93, 0.95, wo)}, opt_positions={(exp, wo): 0.0},
                            etf_levels=None, live=True)
        act = type("A", (), {"option_quotes": {}, "option_orders": [], "ioc": []})()
        saved = {k: C.OPTIONS.get(k) for k in overrides}
        C.OPTIONS.update(overrides)
        try:
            bot.options(s, act, mids, 12 * 3600, False)
        finally:
            C.OPTIONS.update(saved)
        return act.option_quotes.get(exp)

    def test_v12_5m_bid_is_15c_under_value_and_size_50(self):
        q_new = self.quote(5, {})
        q_old = self.quote(5, {"quote_min_edge_by_exp": {}, "quote_size_by_exp": {}})
        self.assertIsNotNone(q_new); self.assertIsNotNone(q_old)
        self.assertAlmostEqual(q_old[1] - q_new[1], 0.12, delta=0.011)      # 15c vs 3c below value
        self.assertEqual(q_new[2], 50)
        self.assertEqual(q_old[2], C.OPTIONS["quote_size"])

    def test_v12_60m_unchanged(self):
        q = self.quote(60, {})
        q_old = self.quote(60, {"quote_min_edge_by_exp": {}, "quote_size_by_exp": {}})
        self.assertEqual(q, q_old)


class V12MomentumPullTests(unittest.TestCase):
    def quote_after(self, move, inv=0.0):
        bot = Bot(centre_mode="mid", features=dict(C.FEATURES, momentum_pull=True))
        t0 = pd.Timestamp(NOW, unit="s", tz="UTC")
        out = None
        for k in range(0, 62):
            m = 10.00 + move * k / 61
            books = {p: (round(m - 0.02, 2), round(m + 0.02, 2), 20, 20) for p in C.PRODUCTS}
            s = SimpleNamespace(ts=t0 + pd.Timedelta(seconds=k), books=books, positions={"apples": inv})
            out = bot.make_quote("apples", s, {"apples": m}, 0.0, 0.0, False)
        return out

    def test_pull_bid_after_rise_and_ask_after_fall(self):
        b, qb, a, qa = self.quote_after(+0.06); self.assertEqual(qb, 0); self.assertGreater(qa, 0)
        b, qb, a, qa = self.quote_after(-0.06); self.assertGreater(qb, 0); self.assertEqual(qa, 0)
        b, qb, a, qa = self.quote_after(+0.02); self.assertGreater(qb, 0); self.assertGreater(qa, 0)

    def test_pull_never_blocks_reducing_a_big_short(self):
        b, qb, a, qa = self.quote_after(+0.06, inv=-100); self.assertGreater(qb, 0)

    def test_watermelon_not_pulled(self):
        self.assertNotIn("watermelon", C.MOM_PULL["products"])
