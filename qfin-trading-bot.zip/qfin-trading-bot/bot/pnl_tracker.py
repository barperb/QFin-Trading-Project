"""
pnl_tracker.py - profit attribution by strategy (for tuning and the presentation).

Every fill is recorded with a tag (e.g. 'mm_apples', 'opt_take_5', 'opt_quote_60', 'nudge', 'hedge', 'flatten').
Each tag keeps its own cash and inventory, so its PnL = cash + inventory x current price.
Option windows are settled per tag when they expire.

Both backtest.py and the live adapter should call this for every fill.
"""
from collections import defaultdict


class PnLTracker:
    def __init__(self):
        self.cash = defaultdict(float)                         # tag -> cash
        self.inv = defaultdict(lambda: defaultdict(float))     # tag -> product -> units
        self.opt = defaultdict(lambda: defaultdict(float))     # tag -> (exp, window_open) -> contracts (+ = long up)
        self.volume = defaultdict(float)                       # tag -> units / contracts traded
        self.count = defaultdict(int)                          # misc counters (nudges, flips, ...)

    def fill(self, tag, product, side, qty, price):
        """side '+' = we bought, '-' = we sold."""
        s = 1 if side == "+" else -1
        self.cash[tag] -= s * qty * price
        self.inv[tag][product] += s * qty
        self.volume[tag] += qty

    def option_fill(self, tag, exp, window_open, side, qty, price):
        s = 1 if side == "+" else -1
        self.cash[tag] -= s * qty * price
        self.opt[tag][(exp, window_open)] += s * qty
        self.volume[tag] += qty

    def option_settle(self, exp, window_open, up):
        """Pay out 1 per long-up contract if UP, 1 per short-up contract if DOWN."""
        for tag in list(self.opt):
            q = self.opt[tag].pop((exp, window_open), 0.0)
            self.cash[tag] += q * (1.0 if up else 0.0)

    def by_tag(self, mids, opt_mids=None):
        """Mark-to-market PnL per tag. opt_mids: {(exp, window_open): option mid} for open option positions."""
        out = {}
        for tag in set(self.cash) | set(self.inv) | set(self.opt):
            v = self.cash[tag] + sum(q * mids[p] for p, q in self.inv[tag].items())
            if opt_mids:
                v += sum(q * opt_mids.get(k, 0.5) for k, q in self.opt[tag].items())
            out[tag] = v
        return out

    def total(self, mids, opt_mids=None):
        return sum(self.by_tag(mids, opt_mids).values())
