"""
bot.py - the QFin trading bot (exchange-agnostic core, v1).

HOW IT PLUGS IN
    The exchange adapter calls  bot.on_second(snapshot)  once per second and executes the returned Actions.
    Nothing here talks to the network, so the same code runs in backtest.py and live.

SNAPSHOT (built by the adapter every second)
    ts             pd.Timestamp (UTC) of the second that just ended
    books          {product: (best_bid, best_ask, bid_size, ask_size)} for the 5 fruits + 'etf'
                   IMPORTANT: best prices from EVERYONE ELSE in the book (market maker + other teams),
                   with our own resting orders removed - otherwise we'd "compete" against ourselves.
    etf_trades     [(price, size, aggressor), ...] ETF trades during this second, in order
    options        {expiry_min: (best_bid, best_ask, window_open)} for the current window's UP contract
                   (again excluding our own quotes)
    positions      {product: units}                         our fruit / ETF inventory
    opt_positions  {(expiry_min, window_open): contracts}    our UP-contract position (+ = long up)
    pnl            today's mark-to-market PnL in $ (for the loss limit)

ACTIONS (returned)
    quotes         {product: (bid_px, bid_qty, ask_px, ask_qty)}            resting fruit/ETF quotes
    option_quotes  {expiry_min: (window_open, bid_px, bid_qty, ask_px, ask_qty)}   resting option quotes
    option_orders  [(expiry_min, window_open, side, qty, limit_px, tag)]    immediate option orders
    ioc            [(product, side, qty, limit_px, tag)]                    immediate fruit/ETF orders
                   (tags "pair" / "pair_stop" come as TWO legs of equal qty that must be placed together)
                   side: '+' buy, '-' sell.  tag: strategy name for PnL attribution.

STRATEGIES (each can be switched off in config.FEATURES)
    1. Fruit/ETF market making centred on the Kalman fair value (or mid), competing for best price
    2. Signal leans: inventory skew, ETF<->basket lean, apples-oranges pair, long-run level, big-move rules
    3. ETF protection: hedge big ETF inventory with fruit; step aside when the size-30 ETF bot is about to fire
    4. Options: take mispricings, rest quotes around the model, value the settle-second trade
    5. Settle nudge: 1-lot ETF order in the close second to print the settle on our side of the strike
    6. Risk: inventory caps, daily loss limit, end-of-day flattening
    7. Pair trade (pair_trade.py, config.PAIR_TRADE): oranges-apples spread stretched vs its 2-minute EMA ->
       passive: opposite target inventories steer the normal quotes; aggressive: IOC both legs (tags "pair" /
       "pair_stop"). Runs in 'mid' mode too (FEATURES.pair_mid_mode). The legs always have equal units.
"""
from dataclasses import dataclass, field
from collections import deque
import math
import config as C
from models import FairValue, OptionModel, Ema
from pair_trade import PairTrade


@dataclass
class Actions:
    quotes: dict = field(default_factory=dict)
    option_quotes: dict = field(default_factory=dict)
    option_orders: list = field(default_factory=list)
    ioc: list = field(default_factory=list)


def floor_tick(x):
    return round(math.floor(x / C.TICK + 1e-9) * C.TICK, 2)


def ceil_tick(x):
    return round(math.ceil(x / C.TICK - 1e-9) * C.TICK, 2)


class Bot:
    def __init__(self, centre_mode=C.CENTRE_MODE, features=None, pair_scale=1.0):
        self.mode = centre_mode                              # 'kalman' or 'mid'
        self.f = dict(C.FEATURES, **(features or {}))        # feature switches
        self.fv = FairValue()
        self.om = OptionModel()
        self.om.nu = dict(C.OPTIONS.get("tail_nu", {}))      # v8: fat tails per expiry
        self.last_etf_trade = None                           # last ETF trade price seen (sets strikes)
        self.strikes = {}                                    # (exp, window_open) -> strike
        self.halted = False                                  # daily loss limit hit
        # signal state
        self.pair_ema = Ema(C.PAIR["span_s"])
        self.pair_dev = 0.0                                  # oranges-apples spread minus its EMA (set every second)
        # pair trade (config.PAIR_TRADE). pair_scale: live passes LIVE.inventory_scale so units per leg shrink with it
        self.pair = PairTrade(self.f["pair_passive"], self.f["pair_aggressive"], self.f["pair_stop_ioc"], pair_scale)
        self.anchor = {p: Ema(C.LONG_RUN["span_s"], C.LONG_RUN["levels"][p]) for p in C.FRUITS}
        self.mid_hist = {p: deque(maxlen=61) for p in C.FRUITS}   # last 60 s of mids, for big-move detection
        self.jump_lean = {p: (0.0, -10**9) for p in C.FRUITS}     # (lean $, second it was set)
        self.sec_counter = 0
        self.pushed = {}                                          # (exp, window_open) -> ETF units spent pushing
        # v9.2 2-hour reversion (REVERSION_2H): once-a-minute mid history per fruit -> target inventories
        r2 = C.REVERSION_2H
        self.rev_hist = {p: deque(maxlen=r2["lookback_s"] // r2["sample_s"] + 1) for p in C.FRUITS}
        self.rev_last = None                                      # epoch second of the last sample
        self.rev_targets = {p: 0.0 for p in C.FRUITS}
        self.rev_pred = {}                                        # expected 2h move per fruit ($), for the live log
        # v9.2 per-expiry option cap scale (short days: config.SHORT_DAY, set by the live adapter)
        self.opt_cap_scale = {}
        # v10 book-only jump signals (config JUMPS)
        self.jump_prev = {}                                       # product -> (epoch second, mid)
        self.straw_ups = deque()                                  # epoch seconds of strawberry up-jumps
        self.straw_fire_at = -10**9                               # epoch second of the last strawberry run signal
        self.wm_jump = (0.0, -10**9)                              # (direction, epoch second) of the last watermelon jump
        self.jump_stats = {"straw_fires": 0, "wm_fades": 0}
        self.deep_keys = set()
        self.mid_hist = {}                                             # v12: per-fruit (sec, mid) for the momentum pull
        self.up_hist = {}                                          # v14: exp -> deque of recent closes (1 = UP won)
        self.open_keys = {}                                        # v14: (exp, window_open) -> strike, for windows still open
        self.up_seen = set()                                       # v14.2: (exp, window_open epoch s) already counted
        self.open_stats = {"orders": 0, "gated": 0, "regime_blocked": 0}
        self.short_stats = {"shorts": 0, "covers": 0}                # v10.4 short-swap order counts (for the log)                                    # v10: windows that got a deep (stage 1) push

    @property
    def flow_signals(self):
        """Signals that only make sense if prices snap back (historical behaviour)."""
        return self.mode == "kalman"

    # =================================================================================================
    # main entry point
    # =================================================================================================
    def on_second(self, s) -> Actions:
        act = Actions()
        self.sec_counter += 1
        mids = {p: (b[0] + b[1]) / 2 for p, b in s.books.items()}
        fair = self.fv.update({p: mids[p] for p in C.FRUITS})
        if self.mode != "kalman":
            fair = dict(mids)
        if s.etf_trades:
            self.last_etf_trade = s.etf_trades[-1][0]
        self.track_closes(s)
        if s.pnl < -C.RISK["daily_loss_limit"]:
            self.halted = True

        hm = (s.ts.hour, s.ts.minute)
        # Live adapter supplies flags based on the exchange dayEnd, not wall-clock midnight.
        late = self.f["flatten"] and getattr(s, "late", hm >= C.RISK["flatten_start"])          # wind down before the reset
        very_late = self.f["flatten"] and getattr(s, "very_late", hm >= C.RISK["flatten_ioc"])       # get flat now
        sec_of_day = s.ts.hour * 3600 + s.ts.minute * 60 + s.ts.second

        # oranges - apples spread vs its EMA: one update per second, shared by pair_lean and the pair trade
        spread = mids["oranges"] - mids["apples"]
        self.pair_dev = spread - self.pair_ema.update(spread)

        leans, targets = self.signal_leans(s, mids, fair)
        # v10: book-only fruit jump signals (strawberry buy-run follow, watermelon fade); IOCs go into act.ioc
        if self.f.get("jump_signals"):
            self.jump_signals(s, mids, targets, act, late)
        # v8: strawberry 2-hour reversion after the size-150 buyer (works in 'mid' and 'kalman' mode)
        if self.f.get("straw_flow"):
            targets["strawberries"] = targets.get("strawberries", 0.0) + self.straw_target(s, late)
        # v9.2: every fruit gives back ~30% of its last-2-hour move (tape-free; 'mid' and 'kalman' mode)
        if self.f.get("reversion_2h"):
            for p, t in self.reversion_targets(s, mids, late).items():
                targets[p] = targets.get(p, 0.0) + t

        # ---- pair trade: extra target inventories for apples / oranges (+ IOCs for the aggressive version).
        # Uses only mids, so it also runs in 'mid' mode (where flow_signals is off) when FEATURES.pair_mid_mode is on.
        pair_ioc = []
        if (self.f["pair_passive"] or self.f["pair_aggressive"]) and (self.flow_signals or self.f["pair_mid_mode"]):
            pt, pair_ioc = self.pair.update(s.ts.timestamp(), spread, self.pair_ema.value, s.books, s.positions,
                                            late, self.halted)
            for p, t in pt.items():
                targets[p] = targets.get(p, 0.0) + t

        # ---- delta hedge: hold ETF against the option book's delta (FEATURES.delta_hedge)
        hedge_target = None
        if self.f.get("delta_hedge") and not self.halted:
            hedge_target = 0.0 if (late or very_late) else self.delta_hedge_target(s, mids, sec_of_day)
            targets["etf"] = targets.get("etf", 0.0) + hedge_target

        # ---- 1-3. fruit / ETF quotes, ETF protection
        for p in C.PRODUCTS:
            act.quotes[p] = self.make_quote(p, s, fair, leans.get(p, 0.0), targets.get(p, 0.0), late)
        act.ioc.extend(pair_ioc)
        if hedge_target is not None and not very_late:
            dh = C.DELTA_HEDGE
            diff = hedge_target - s.positions.get("etf", 0.0)
            if abs(diff) > dh["band"]:
                n = int(min(dh["clip"], abs(diff)))
                if diff > 0:
                    act.ioc.append(("etf", "+", n, s.books["etf"][1], "dhedge"))
                else:
                    act.ioc.append(("etf", "-", n, s.books["etf"][0], "dhedge"))
        self.etf_hedge(s, act, very_late)
        self.etf_unwind(s, act, sec_of_day)
        if very_late:
            self.flatten_ioc(s, act)

        # ---- 4. options
        self.options(s, act, mids, sec_of_day, late)

        # ---- 5. settle nudge (old 1-lot version) / settle push (options manipulation)
        if self.f.get("settle_push"):
            self.settle_push(s, act, mids)
        elif self.f["settle_nudge"]:
            self.settle_nudge(s, act, mids)
        return act

    # =================================================================================================
    # signals -> centre leans ($) and target inventories (units)
    # =================================================================================================
    def signal_leans(self, s, mids, fair):
        leans = {p: 0.0 for p in C.PRODUCTS}
        targets = {p: 0.0 for p in C.PRODUCTS}
        pos = s.positions

        # ETF <-> basket inventory lean: long ETF -> we are long the basket -> lean fruit quotes to sell fruit,
        # and long fruit -> lean ETF quotes to sell ETF. Holds in either mode (ETF fair = sum of fruits).
        if self.f["etf_basket_lean"]:
            etf_inv = pos.get("etf", 0.0)
            avg_fruit_inv = sum(pos.get(p, 0.0) for p in C.FRUITS) / len(C.FRUITS)
            for p in C.FRUITS:
                leans[p] -= C.ETF_LEAN["fruit_per_etf_unit"] * etf_inv
            leans["etf"] -= C.ETF_LEAN["etf_per_fruit_unit"] * avg_fruit_inv

        if not self.flow_signals:
            return leans, targets

        # apples-oranges pair: when oranges - apples is above its 2-min average, expect it to shrink
        if self.f["pair_lean"]:
            dev = self.pair_dev                    # updated once per second in on_second()
            leans["oranges"] -= C.PAIR["k"] * dev / 2
            leans["apples"] += C.PAIR["k"] * dev / 2

        # long-run level: hold a little inventory toward each fruit's ~24 h average (half-life ~3-7 h)
        if self.f["long_run"]:
            for p in C.FRUITS:
                a = self.anchor[p].update(mids[p])
                t = C.LONG_RUN["units_per_dollar"] * (a - fair[p])
                targets[p] = max(-C.LONG_RUN["max_target"], min(C.LONG_RUN["max_target"], t))

        # big moves: after a >30c move in 60 s, fade watermelon / follow strawberries for ~5 min
        if self.f["big_moves"]:
            for p in C.FRUITS:
                h = self.mid_hist[p]; h.append(mids[p])
                if p in C.BIG_MOVES["lean"] and len(h) == h.maxlen:
                    move = h[-1] - h[0]
                    if abs(move) > C.BIG_MOVES["threshold"]:
                        self.jump_lean[p] = (C.BIG_MOVES["lean"][p] * move, self.sec_counter)
                lean, t0 = self.jump_lean[p]
                age = self.sec_counter - t0
                if age < C.BIG_MOVES["decay_s"]:
                    leans[p] += lean * (1 - age / C.BIG_MOVES["decay_s"])
        return leans, targets

    # =================================================================================================
    # fruit / ETF quote
    # =================================================================================================
    def make_quote(self, p, s, fair, lean, target, late):
        prm = C.QUOTE[p]
        best_bid, best_ask = s.books[p][0], s.books[p][1]
        inv = s.positions.get(p, 0.0)

        # centre: fair value (or mid) + signal leans, skewed against inventory relative to the target
        skew = prm["skew"]
        if p in ("apples", "oranges") and self.pair.d and self.f["pair_passive"]:
            skew *= C.PAIR_TRADE["skew_mult"]    # open pair trade: pull the legs to their targets harder
        centre = fair[p] + lean - skew * (inv - target)

        # how far from the centre we insist on quoting (wider when the market is jumpy)
        edge = prm["min_edge"]
        if self.f["vol_widen"]:
            m = s.ts.minute
            if m >= 60 - C.VOL_WIDEN["minutes_from_hour"] or m < C.VOL_WIDEN["minutes_from_hour"]:
                edge += C.VOL_WIDEN["extra_top_of_hour"]
            if s.ts.hour in C.VOL_WIDEN["hours_utc"]:
                edge += C.VOL_WIDEN["extra_midnight"]
            edge += C.VOL_WIDEN["excess_spread_frac"] * max(0.0, (best_ask - best_bid) - C.NORMAL_SPREAD[p])

        bid = floor_tick(centre - edge)
        ask = ceil_tick(centre + edge)
        if self.f["compete_quotes"]:
            # be first in line (1 tick better than everyone else) but never past our edge limit
            bid = min(bid, round(best_bid + C.TICK, 2))
            ask = max(ask, round(best_ask - C.TICK, 2))
        bid = min(bid, round(best_ask - C.TICK, 2))       # never cross the book
        ask = max(ask, round(best_bid + C.TICK, 2))

        # sizes: respect inventory caps; late in the day / after the loss limit only reduce inventory
        cap = prm["max_inventory"] * (0.3 if late else 1.0)
        qb = prm["size"] if inv < cap else 0
        qa = prm["size"] if inv > -cap else 0
        if late or self.halted:
            qb = prm["size"] if inv < 0 else 0
            qa = prm["size"] if inv > 0 else 0

        # ETF bot guard: when the ETF is far from the basket, size-30 trades will push it back.
        # Don't stand in front of them: no ETF ask when ETF is cheap (they buy), no bid when rich (they sell).
        if p == "etf" and self.f["etf_bot_guard"]:
            basket_mid = sum((s.books[f][0] + s.books[f][1]) / 2 for f in C.FRUITS)
            gap = basket_mid - (best_bid + best_ask) / 2
            if gap > C.ETF_BOT_GUARD["gap"]:
                qa = 0
            elif gap < -C.ETF_BOT_GUARD["gap"]:
                qb = 0
        # v12: momentum pull. Our maker fills that follow the last 60 s move lose (buy after a 4c+ rise: -0.6 to -1.7c a unit
        # 60 s later); fills against it win (+1.4 to +2.2c). Live Oct 11-12, 680k units. So when the mid has risen more than
        # MOM_PULL.thr in 60 s, don't bid (keep the ask); when it has fallen, don't offer. Never blocks reducing a big position.
        if self.f.get("momentum_pull") and p in C.MOM_PULL["products"]:
            d = self.mom60(p, s)
            if d is not None:
                big = C.MOM_PULL["allow_reduce_units"]
                if d > C.MOM_PULL["thr"] and inv > -big:
                    qb = 0
                elif d < -C.MOM_PULL["thr"] and inv < big:
                    qa = 0
        return (bid, qb, ask, qa)

    def mom60(self, p, s):
        """mid now - mid ~60 s ago (from the books we have seen), or None while warming up."""
        hist = self.mid_hist.setdefault(p, deque(maxlen=400))
        bb, ba = s.books[p][0], s.books[p][1]
        if bb is None or ba is None:
            return None
        t = s.ts.value // 10**9 if hasattr(s.ts, "value") else int(s.ts)
        m = (bb + ba) / 2
        if not hist or hist[-1][0] != t:
            hist.append((t, m))
        else:
            hist[-1] = (t, m)
        target = t - C.MOM_PULL["lookback_s"]
        if hist[0][0] > target:
            return None
        old = None
        for tt, mm in reversed(hist):
            if tt <= target:
                old = mm
                break
        return None if old is None else m - old

    # =================================================================================================
    # ETF hedge and end-of-day flattening (immediate orders at the touch)
    # =================================================================================================
    def etf_hedge(self, s, act, very_late):
        """The ETF is literally the basket, so ETF inventory and fruit inventory offset each other.
        Net basket exposure (in basket units) = ETF inventory + average fruit inventory.
        If that gets too big, trade one unit of every fruit per basket unit to bring it back."""
        if not self.f["etf_hedge"] or very_late:
            return
        etf_inv = s.positions.get("etf", 0.0)
        avg_fruit = sum(s.positions.get(p, 0.0) for p in C.FRUITS) / len(C.FRUITS)
        net = etf_inv + avg_fruit
        if abs(etf_inv) <= C.ETF_HEDGE["trigger"] or abs(net) <= C.ETF_HEDGE["trigger"]:
            return
        n = min(C.ETF_HEDGE["clip"], abs(net) - C.ETF_HEDGE["trigger"])
        side = "-" if net > 0 else "+"
        for p in C.FRUITS:
            px = s.books[p][0] if side == "-" else s.books[p][1]
            act.ioc.append((p, side, n, px, "hedge"))

    def etf_unwind(self, s, act, sec_of_day):
        """v9: settle pushes leave ETF inventory (up to SETTLE_PUSH.max_units). The ETF quotes are tiny live (1 lot), so when
        |ETF inventory| is above ETF_UNWIND.threshold and no 5m close is near, take it down with small IOCs at the touch."""
        if not self.f.get("etf_unwind"):
            return
        u = C.ETF_UNWIND
        inv = s.positions.get("etf", 0.0)
        if abs(inv) <= u["threshold"]:
            return
        to_close = 300 - (sec_of_day % 300)
        if to_close <= u["quiet_s"] or to_close >= 300 - 3:
            return                                   # don't trade the ETF around a close (our own pushes live there)
        n = int(min(u["clip"], abs(inv) - u["threshold"] + 1))
        if inv > 0:
            act.ioc.append(("etf", "-", n, s.books["etf"][0], "unwind"))
        else:
            act.ioc.append(("etf", "+", n, s.books["etf"][1], "unwind"))

    def flatten_ioc(self, s, act):
        """In the last minutes before the reset, cross the spread to get flat."""
        for p in C.PRODUCTS:
            inv = s.positions.get(p, 0.0)
            if abs(inv) < 1e-9:
                continue
            n = min(C.RISK["flatten_clip"], abs(inv))
            if inv > 0:
                act.ioc.append((p, "-", n, s.books[p][0], "flatten"))
            else:
                act.ioc.append((p, "+", n, s.books[p][1], "flatten"))

    # =================================================================================================
    # options
    # =================================================================================================
    def track_closes(self, s):
        """v14: remember whether UP won each closed window (settle ~ last ETF trade at/after the close vs the strike)."""
        if not self.open_keys:
            return
        for key in list(self.open_keys):
            exp, wo = key
            if (s.ts - wo).total_seconds() >= exp * 60:
                k = self.open_keys.pop(key)
                if self.last_etf_trade is not None:
                    self.record_close(exp, int(wo.timestamp()), self.last_etf_trade >= k - 1e-9)

    def open_first_order(self, exp=5):
        """v14.1: (qty, limit) for the blind open buy sent right after a late push, or None."""
        ob = C.OPTIONS.get("open_up_buy", {}).get(exp) if self.f.get("open_up_buy") else None
        if not ob or self.halted or not ob.get("first_qty") or not self.up_gate(exp, ob):
            return None
        ocap = min(int(C.OPTIONS["max_contracts"] * self.opt_cap_scale.get(exp, 1.0)), ob["cap"])
        q = int(min(ob["first_qty"], ocap))
        lim = round(min(ob["first_limit"], ob["max_price"]), 2)
        return (q, lim) if q > 0 and lim > 0 else None

    def record_close(self, exp, wo_s, up):
        """v14.2: record a settled window's outcome from the exchange (state 'optionWindows'). Live there is no ETF trade
        tape (etf_trades is always empty), so track_closes never fires and the off-switch was never fed in v14/v14.1."""
        key = (int(exp), int(wo_s))
        if key in self.up_seen:
            return
        self.up_seen.add(key)
        if len(self.up_seen) > 2000:
            self.up_seen = set(sorted(self.up_seen)[-1000:])
        self.up_hist.setdefault(int(exp), deque(maxlen=48)).append(1 if up else 0)

    def regime_buy_ok(self, exp):
        """v15: only BUY UP (any path - open buy, model take, resting bid) while UP is still winning recent closes.
        up_hist is fed from the exchange's settled windows (record_close). Fewer than `min` closes seen -> allow,
        so a fresh day is not frozen. This is pure risk control: it never sells, it only stops loading UP into a
        DOWN regime (Oct 15: UP won 11/92 5m windows; every UP-buy path lost)."""
        rg = C.OPTIONS.get("regime_gate", {}).get(exp)
        if not rg:
            return True
        h = self.up_hist.get(exp)
        if not h or len(h) < rg["min"]:
            return True
        r = list(h)[-rg["n"]:]
        return sum(r) / len(r) >= rg["rate"]

    def regime_sell_ok(self, exp):
        """v16: the mirror of regime_buy_ok. In a confirmed DOWN regime (UP won <= rate of the last n closes), ALLOW
        selling UP (opening a short, capped), which the existing settle push then defends by pushing the ETF DOWN.
        A neutral band between the sell rate and the buy rate (0.5) means we do neither near a coin flip, so we don't
        flip sides on noise. Needs >= min closes first; off by default (no regime_sell config -> never shorts)."""
        rs = C.OPTIONS.get("regime_sell", {}).get(exp)
        if not rs:
            return False
        h = self.up_hist.get(exp)
        if not h or len(h) < rs["min"]:
            return False
        r = list(h)[-rs["n"]:]
        return sum(r) / len(r) <= rs["rate"]

    def up_gate(self, exp, ob):
        h = self.up_hist.get(exp)
        if not h or len(h) < ob["gate_min"]:
            return True
        r = list(h)[-ob["gate_n"]:]
        return sum(r) / len(r) >= ob["gate_rate"]

    def options(self, s, act, mids, sec_of_day, late):
        basket_mid = sum(mids[p] for p in C.FRUITS)
        etf_half = (s.books["etf"][1] - s.books["etf"][0]) / 2
        drift_base = C.OPTIONS["etf_drift"] if self.flow_signals else 0.0
        o = C.OPTIONS
        for exp, (obid, oask, wo) in s.options.items():
            key = (exp, wo)
            # strike = last ETF trade at/before the window open. If the bot starts mid-window this is approximate.
            if key not in self.strikes and not getattr(s, "live", False) and self.last_etf_trade is not None:
                self.strikes[key] = self.last_etf_trade
            if key not in self.strikes:
                continue
            left = int((wo - s.ts).total_seconds()) + exp * 60
            if left <= o["min_seconds_left"]:
                continue
            k = self.strikes[key]
            self.open_keys[key] = k
            pos = s.opt_positions.get(key, 0.0)
            mid_settle = getattr(s, "option_src", {}).get(exp) == "etf_mid"
            # v9: the ETF closes its gap to the basket (sum of fruit mids) in every mode, so price off a blend of the two.
            # Replay of our live option books Oct 7-10, 5m P&L: drift 0 -> 0.55 -> 0.8 -> 1.0 = $28.0k -> 38.2k -> 40.6k -> 42.1k.
            drift = (C.OPTIONS["drift_by_exp"].get(exp, C.OPTIONS["etf_drift"])
                     if self.f.get("option_drift_live", True) else drift_base)

            # value of a long-UP and a long-DOWN position (with settle control if enabled)
            if mid_settle:
                # v9: settles on the ETF MID (historically the 15m option): no print noise and no last-trade push
                v_long = v_short = self.om.prob_up(sec_of_day, left, mids["etf"], k, basket_mid, drift, exp=exp,
                                                   noise_free=True)
            elif self.f.get("settle_push"):
                # we will defend whichever side we hold with a settle push (see SETTLE_PUSH / settle_push())
                sp = C.SETTLE_PUSH
                reach_up = reach_dn = sp["reach"]
                half_up = half_dn = etf_half
                levels = getattr(s, "etf_levels", None)
                if self.f.get("book_reach") and levels and levels[0] and levels[1]:
                    # real book: the furthest print we could afford, measured from the mid (floor: the touch)
                    stake = max(abs(pos), o["clip"])
                    # The book may only VETO: never value a push further out than the old 'touch + reach' assumption
                    # (v5 let deep far-away levels raise the value and loaded 500 contracts on 27c-away strikes: -$980/17min).
                    legacy = etf_half + sp["reach"]
                    half_up, reach_up = 0.0, min(self.affordable_reach(levels[1], mids["etf"], stake, True), legacy)
                    half_dn, reach_dn = 0.0, min(self.affordable_reach(levels[0], mids["etf"], stake, False), legacy)
                v_long = self.om.prob_up_pushed(sec_of_day, left, mids["etf"], k, half_up, reach_up,
                                                sp["p_win"].get(exp, 0.6), True, basket_mid, drift, exp=exp)
                v_short = self.om.prob_up_pushed(sec_of_day, left, mids["etf"], k, half_dn, reach_dn,
                                                 sp["p_win"].get(exp, 0.6), False, basket_mid, drift, exp=exp)
            elif self.f["settle_value"]:
                pc = C.SETTLE["p_we_set_settle"].get(exp, 0.6)
                v_long = self.om.prob_up_controlled(sec_of_day, left, mids["etf"], k, etf_half, pc, True, basket_mid, drift, exp=exp)
                v_short = self.om.prob_up_controlled(sec_of_day, left, mids["etf"], k, etf_half, pc, False, basket_mid, drift, exp=exp)
            else:
                v_long = v_short = self.om.prob_up(sec_of_day, left, mids["etf"], k, basket_mid, drift, exp=exp)
            buy_val = v_long if pos >= 0 else v_short     # value of the contract we'd be adding/closing
            sell_val = v_short if pos <= 0 else v_long

            cap = int(o["max_contracts"] * self.opt_cap_scale.get(exp, 1.0))   # v9.2: short days scale caps (SHORT_DAY)
            cap_short = min(cap, o.get("max_short", cap))      # short-UP is capped lower than long-UP (see OPTIONS.max_short)
            no_new = self.halted or (late and exp == 60)   # don't open 60m positions into the reset
            can_buy = pos < cap and not (no_new and pos >= 0)
            can_sell = pos > -cap_short and not (no_new and pos <= 0)
            if not o.get("sell_up", {}).get(exp, True):
                can_sell = False                               # v6: hold UP to settle in this expiry (OPTIONS.sell_up)
            # v15 REGIME GATE: in a DOWN regime, stop BUYING UP on every path (open buy, model take, resting bid).
            # Reducing a long (trim/sell) and the settle push are untouched, so we flatten into the close and earn
            # only fruit/ETF while UP is losing. buy-back of a short is never needed (short_swap off).
            regime_ok = self.regime_buy_ok(exp)
            if not regime_ok:
                can_buy = False
                self.open_stats["regime_blocked"] = self.open_stats.get("regime_blocked", 0) + 1
            # v16 DOWN MODE: in a confirmed down regime, allow opening a capped SHORT UP (overrides sell_up=False).
            # The model's v_short already values the short assuming we defend it with a down push, and the settle push
            # defends any window we hold short. Never buys in the same regime (regime_ok is False there).
            if not regime_ok and self.regime_sell_ok(exp):
                rs = C.OPTIONS["regime_sell"][exp]
                cap_short = min(cap, rs["cap"])
                can_sell = pos > -cap_short and not (no_new and pos <= 0)
                self.open_stats["down_mode"] = self.open_stats.get("down_mode", 0) + 1

            # v14: OPEN UP BUY - first open_s seconds of the window, buy UP at the ask up to max_price, hold to the close
            ob = o.get("open_up_buy", {}).get(exp) if self.f.get("open_up_buy") else None
            open_on = False
            if ob and not no_new and pos >= 0 and left > exp * 60 - ob["open_s"]:
                if self.up_gate(exp, ob):
                    open_on = True
                    ocap = min(cap, ob["cap"])
                    if pos < ocap and 0 < oask <= ob["max_price"]:
                        # v14.1: sweep the house ladder (limit ask + sweep_over, never above max_price)
                        lim = round(min(ob["max_price"], oask + ob.get("sweep_over", 0.0)), 2)
                        q = int(min(ob.get("sweep_max", o["clip"]), ocap - pos))
                        act.option_orders.append((exp, wo, "+", q, lim, f"opt_open_{exp}"))
                        self.open_stats["orders"] += 1
                        continue
                else:
                    self.open_stats["gated"] += 1
            if ob and self.f.get("open_up_buy") and self.up_gate(exp, ob):
                open_on = True

            # take obvious mispricings (v8: threshold per expiry, OPTIONS.take_edge_by_exp)
            take_edge = o.get("take_edge_by_exp", {}).get(exp, o["take_edge"])
            # v9.2: pickier early in the window (the cap fills up; save it for the better prices that come later)
            early_s = o.get("early_seconds_by_exp", {}).get(exp)
            if early_s is not None and left > early_s:
                take_edge = o.get("take_edge_early_by_exp", {}).get(exp, take_edge)
            if self.f["option_take"]:
                if can_buy and buy_val - oask > take_edge:
                    act.option_orders.append((exp, wo, "+", min(o["clip"], cap - pos), oask, f"opt_take_{exp}"))
                    continue
                if can_sell and obid - sell_val > take_edge:
                    act.option_orders.append((exp, wo, "-", min(o["clip"], cap_short + pos), obid, f"opt_take_{exp}"))
                    continue
                # v10.3: take profit on a LONG position when the bid is clearly above our own value (never goes short).
                # Live replay Oct 8-11 (5m, edge 2c, more than 60 s left): +$4.7k / +$1.0k / +$0.3k / +$0.3k a day; going short
                # instead lost $15-54k over the same days (everyone pushes UP at the close).
                tl = o.get("trim_long", {}).get(exp)
                if tl and not open_on and pos > 0 and left > tl["min_left"] and obid - v_long > tl["edge"]:
                    act.option_orders.append((exp, wo, "-", int(min(o["clip"], pos)), obid, f"opt_trim_{exp}"))
                    continue
                # v10.4: swap to SHORT mid-window when UP is rich, and buy it all back before the close fight.
                # Replay Oct 8-11 (edge 15c, cap 500, cover 60 s): +$11.1k / +$2.2k / +$0.5k / -$2.7k vs holding.
                sw = o.get("short_swap", {}).get(exp) if self.f.get("option_short_swap") else None
                if sw:
                    if pos < 0 and left <= sw["cover_s"]:
                        act.option_orders.append((exp, wo, "+", int(min(o["clip"], -pos)), round(oask + 0.02, 2),
                                                  f"opt_cover_{exp}"))
                        self.short_stats["covers"] += 1
                        continue
                    if (left > sw["cover_s"] + 5 and pos <= 0 and pos > -sw["cap"] and not self.halted
                            and obid - v_short > sw["edge"]):
                        act.option_orders.append((exp, wo, "-", int(min(o["clip"], sw["cap"] + pos)), obid,
                                                  f"opt_short_{exp}"))
                        self.short_stats["shorts"] += 1
                        continue

            # rest quotes around the model (1 tick better than the best, never closer than quote_min_edge)
            if self.f["option_quote"]:
                skew = o["quote_skew"] * pos
                qme = o.get("quote_min_edge_by_exp", {}).get(exp, o["quote_min_edge"])   # v12: 5m bids rest 15c under value
                qb = floor_tick(min(buy_val - qme - skew, obid + C.TICK))
                qa = ceil_tick(max(sell_val + qme - skew, oask - C.TICK))
                qb = min(max(qb, 0.01), round(oask - C.TICK, 2))
                qa = max(min(qa, 0.99), round(obid + C.TICK, 2))
                qsz = o.get("quote_size_by_exp", {}).get(exp, o["quote_size"])           # v12: 5m resting size 20 -> 50
                nb = min(qsz, cap - pos) if can_buy else 0
                na = min(qsz, cap_short + pos) if can_sell else 0
                act.option_quotes[exp] = (wo, qb, max(nb, 0), qa, max(na, 0))

    def jump_signals(self, s, mids, targets, act, late):
        """v10: what the size-150 strawberry buyer leaves in the BOOK (the hosted runtime has no trade tape): its clips move
        the strawberry mid 7-10c in one second. Three such up-jumps within 120 s -> a buy run is under way -> follow it.
        Measured (buy at the ask the second after the 3rd jump, mark at the mid): +11.8c at 60 s / +13.9c at 300 s on 8
        historical days (9.4 signals/day, 60% had a size-150 buy that second) and +10.6c / +16.7c live Oct 7-10 (7/day).
        A single jump reverts (08_findings), and down-jumps / other fruits show no follow-through. Watermelon jumps of 7c+
        reverse (live: -6.5c at 60 s, -9.8c at 300 s), so after one we lean the watermelon target against it (passive)."""
        j = C.JUMPS
        now = int(s.ts.timestamp())
        for p in ("strawberries", "watermelon"):
            prev = self.jump_prev.get(p)
            self.jump_prev[p] = (now, mids[p])
            if prev is None or now - prev[0] != 1:
                continue                                   # only consecutive seconds (a gap is not a jump)
            dm = mids[p] - prev[1]
            if p == "strawberries" and dm >= j["straw_jump"] - 1e-9:
                self.straw_ups.append(now)
            if p == "watermelon" and abs(dm) >= j["wm_jump"] - 1e-9:
                self.wm_jump = (1.0 if dm > 0 else -1.0, now)
                self.jump_stats["wm_fades"] += 1
        while self.straw_ups and now - self.straw_ups[0] > j["straw_window_s"]:
            self.straw_ups.popleft()
        pos = s.positions.get("strawberries", 0.0)
        if (len(self.straw_ups) >= j["straw_k"] and now - self.straw_fire_at >= j["straw_cooldown_s"]
                and not self.halted and not late):
            self.straw_fire_at = now
            self.jump_stats["straw_fires"] += 1
            n = int(max(0, min(j["straw_units"], j["straw_max_pos"] - pos)))
            if n > 0:
                act.ioc.append(("strawberries", "+", n, round(s.books["strawberries"][1] + j["straw_tol"], 2), "straw"))
        age = now - self.straw_fire_at
        if age < j["straw_hold_s"] + j["straw_decay_s"]:
            w = 1.0 if age < j["straw_hold_s"] else 1.0 - (age - j["straw_hold_s"]) / j["straw_decay_s"]
            targets["strawberries"] = targets.get("strawberries", 0.0) + j["straw_units"] * w
        d, t0 = self.wm_jump
        age = now - t0
        if age < j["wm_hold_s"]:
            targets["watermelon"] = targets.get("watermelon", 0.0) - d * j["wm_units"] * (1.0 - age / j["wm_hold_s"])

    def reversion_targets(self, s, mids, late):
        """v9.2 (config REVERSION_2H): target inventory per fruit = clip(beta x (mid - mid 2 h ago) / full_at x cap).
        The mid history is sampled once a minute; no target until it covers the full 2 hours."""
        r2 = C.REVERSION_2H
        now = int(s.ts.timestamp())
        if self.rev_last is None or now - self.rev_last >= r2["sample_s"]:
            self.rev_last = now
            for p in C.FRUITS:
                h = self.rev_hist[p]
                h.append((now, mids[p]))
                if now - h[0][0] < r2["lookback_s"] - r2["sample_s"]:
                    self.rev_targets[p] = 0.0                 # not enough history yet
                    self.rev_pred.pop(p, None)
                    continue
                pred = r2["beta"] * (mids[p] - h[0][1])       # expected next-2h move, $
                cap = r2["max_units"].get(p, 0)
                self.rev_pred[p] = pred
                self.rev_targets[p] = float(max(-cap, min(cap, round(pred / r2["full_at"] * cap))))
        if late or self.halted:
            return {}
        return {p: t for p, t in self.rev_targets.items() if t}

    def straw_target(self, s, late):
        """Target strawberry inventory from the count of size-150 buys in the last 2 h (config STRAW_FLOW).
        s.straw150_count: int, or None when the tape isn't available (-> no position)."""
        cnt = getattr(s, "straw150_count", None)
        if cnt is None or late or self.halted:
            self.straw_pred = None
            return 0.0
        sf = C.STRAW_FLOW
        pred = sf["intercept"] + sf["per_buy"] * cnt          # expected 2h move, $
        self.straw_pred = pred
        t = pred / sf["full_at"] * sf["max_units"]
        return float(max(-sf["max_units"], min(sf["max_units"], round(t))))

    def delta_hedge_target(self, s, mids, sec_of_day):
        """ETF units to hold against the option book: -frac x sum(contracts x dP(up)/dETF), capped.
        A window's delta is ignored in its last DELTA_HEDGE.skip_last_s seconds (the settle push decides it there)."""
        dh = C.DELTA_HEDGE
        cap = getattr(self, "hedge_max", dh["max_units"])
        total, h = 0.0, 0.01
        for exp, (_, _, wo) in s.options.items():
            key = (exp, wo)
            pos = s.opt_positions.get(key, 0.0)
            if abs(pos) < 1e-9 or key not in self.strikes:
                continue
            left = int((wo - s.ts).total_seconds()) + exp * 60
            if left <= dh["skip_last_s"]:
                continue
            k = self.strikes[key]
            d = (self.om.prob_up(sec_of_day, left, mids["etf"] + h, k)
                 - self.om.prob_up(sec_of_day, left, mids["etf"] - h, k)) / (2 * h)
            total += pos * d
        return max(-cap, min(cap, round(-dh["frac"] * total)))

    @staticmethod
    def affordable_reach(levels, mid, stake, up):
        """Furthest print (distance from the ETF mid, $) we could make by walking `levels` (best first) within the push
        budget: at most SETTLE_PUSH.max_units units and an est. cost (x2 for the unwind) <= cost_frac x stake.
        Always at least the touch. Used to value option positions with the REAL book (config SETTLE_PUSH.reach_cap)."""
        sp = C.SETTLE_PUSH
        units, cost, best = 0, 0.0, abs(levels[0][0] - mid)
        for price, qty in levels:
            take = min(qty, sp["max_units"] - units)
            if take <= 0:
                break
            d = abs(price - mid)
            units += take
            cost += d * take
            if 2 * cost > sp["cost_frac"] * stake and price != levels[0][0]:
                break
            best = d
        return min(best, sp["reach_cap"])

    # =================================================================================================
    # settle nudge: in the second before a close, send a 1-lot ETF order that prints on our side of the strike
    # =================================================================================================
    def settle_nudge(self, s, act, mids):
        """At the top of the hour the 5m and 60m windows close in the same second and may want opposite prints.
        Collect what each closing position wants, weight by contracts, and send ONE order for the net side."""
        bid, ask = s.books["etf"][0], s.books["etf"][1]
        want = 0.0                                                     # + = want a print at the ask, - = at the bid
        for (exp, wo), pos in s.opt_positions.items():
            if abs(pos) < 1e-9 or (exp, wo) not in self.strikes:
                continue
            if int((wo - s.ts).total_seconds()) + exp * 60 != 1:      # only the second before the close
                continue
            k = self.strikes[(exp, wo)]
            if abs(mids["etf"] - k) > C.SETTLE["max_gap"]:             # can't change the result cheaply
                continue
            if pos > 0 and ask >= k:                                   # long UP: a print at the ask is >= strike
                want += pos
            elif pos < 0 and bid < k:                                  # long DOWN: a print at the bid is < strike
                want += pos                                            # (pos negative)
        if want > 0:
            act.ioc.append(("etf", "+", C.SETTLE["size"], ask, "nudge"))
        elif want < 0:
            act.ioc.append(("etf", "-", C.SETTLE["size"], bid, "nudge"))

    # =================================================================================================
    # SETTLE PUSH (options manipulation, allowed by the organisers)
    # =================================================================================================
    def settle_push(self, s, act, mids):
        """In the close second, trade ETF so the settle print lands on our side of the strike.

        Which windows are closing:
          live     -> the adapter supplies s.push_windows = [dict(exp, wo, strike, pos), ...] for windows with
                      seconds_left <= SETTLE_PUSH.fire_seconds, plus s.etf_levels (external book levels) and
                      s.last_etf_print (latest ETF trade price).
          backtest -> windows we hold whose close is in the next second; ETF levels come from the synthetic
                      ladder in config (historical book shape).
        """
        sp = C.SETTLE_PUSH
        live = getattr(s, "live", False)
        if live:
            wins = [(w["exp"], w["wo"], w["strike"], w["pos"]) for w in getattr(s, "push_windows", [])]
        else:
            wins = [(exp, wo, self.strikes[(exp, wo)], pos) for (exp, wo), pos in s.opt_positions.items()
                    if abs(pos) > 1e-9 and (exp, wo) in self.strikes
                    and int((wo - s.ts).total_seconds()) + exp * 60 == 1]
        wins = [w for w in wins if abs(w[3]) > 1e-9]
        if not wins:
            return
        bids, asks = getattr(s, "etf_levels", None) or synthetic_ladder(s.books["etf"][0], s.books["etf"][1])
        budget = sp["max_units"] - max(self.pushed.get((w[0], w[1]), 0) for w in wins)
        if budget <= 0:
            return
        plan = plan_push([(w[2], w[3]) for w in wins], bids, asks, mids["etf"], budget)
        if plan is None:
            # v10 deep push: the strike is beyond the visible ladder. Walk it anyway (stage 1) so the market maker
            # re-quotes closer; the close-second push (adapter, stage 2) finishes from the new book.
            if not (live and self.f.get("deep_push")) or any((w[0], w[1]) in self.pushed for w in wins):
                return
            st = deep_stage1([(w[2], w[3]) for w in wins], bids, asks, mids["etf"], budget, sp.get("deep_reach", 0.25))
            if st is None:
                return
            side, lo, hi, units, cost, stake = st
            if 2 * cost > sp["cost_frac"] * stake:
                return
            walk_px = last_below(lo) if side == "+" else ceil_tick(hi)
            act.ioc.append(("etf", side, units, walk_px, "push"))
            for w in wins:
                self.pushed[(w[0], w[1])] = self.pushed.get((w[0], w[1]), 0) + units
                self.deep_keys.add((w[0], w[1]))
            self.jump_stats["deep_pushes"] = self.jump_stats.get("deep_pushes", 0) + 1
            if "etf" in act.quotes:
                b, _, a, _ = act.quotes["etf"]
                act.quotes["etf"] = (b, 0, a, 0)
            return
        orders, units, cost, stake, (lo, hi) = plan
        # live re-fire: if we already pushed this window and the latest print is on our side, do nothing
        last = getattr(s, "last_etf_print", None)
        if live and any((w[0], w[1]) in self.pushed for w in wins) and last is not None and lo <= last < hi:
            return
        # est. total cost = displacement paid now + the same again when the ETF bought/sold is unwound
        if 2 * cost > sp["cost_frac"] * stake:
            return
        # v9.2: A (the walk) is limited to the last tick on the WRONG side of [lo, hi), so it clears wrong-side levels that
        # appeared after we looked (live: + SETTLE_PUSH.early_buffer units) without ever buying on our side; B (1 unit) may
        # fill anywhere inside the range. v9 used the last level it saw as A's limit and B's exact level, so a refilled
        # level below the strike could take B's print to the wrong side (or B missed and A's print was the last).
        # v10: robust_push_orders builds the same A / B as v9.2 for every range shape (v9.2 raised OverflowError when the
        # range was unbounded on the side it walked, e.g. a DOWN window already in the money).
        side = orders[-1][0]
        seen = orders[0][1] if len(orders) == 2 else 0
        a_qty = min(seen + (sp.get("early_buffer", 0) if live else 0), budget - 1)
        for sd, qty, px, _ioc, _role in robust_push_orders(side, lo, hi, a_qty, C.LIVE.get("late_push_b_reach", 0.40)):
            act.ioc.append(("etf", sd, qty, px, "push"))
        for w in wins:
            self.pushed[(w[0], w[1])] = self.pushed.get((w[0], w[1]), 0) + units
        # v9: don't re-place our own ETF quotes in the push batch. v8 cancelled them, pushed, then put them straight back
        # (e.g. an ask at mid+4c BELOW a strike we just pushed above): any buyer lifting that ask before the close printed
        # the settle on the wrong side - our own quote could lose our own window.
        if "etf" in act.quotes:
            b, _, a, _ = act.quotes["etf"]
            act.quotes["etf"] = (b, 0, a, 0)


def first_at_or_above(x):
    """v10: smallest 1c grid price p with p >= x EXACTLY in float64 (the exchange compares settle >= strike in float64;
    strikes are average fill prices and can sit a hair above a grid price, e.g. 56.095000000000006)."""
    p = ceil_tick(x)
    return p if p >= x else round(p + C.TICK, 2)


def last_below(x):
    """Highest 1c grid price strictly below x (float64-exact, see first_at_or_above)."""
    return round(first_at_or_above(x) - C.TICK, 2)


def robust_push_orders(side, lo, hi, walk_qty, reach=0.40, wall_units=0):
    """v10: settle-push orders whose LAST print lands in [lo, hi) whatever the book looks like when they ARRIVE.

    side = trade direction ('+' buy up the asks, '-' sell down the bids); [lo, hi) = target range (lo = -inf or
    hi = +inf when unbounded). Returns [(side, qty, price, ioc, role)] with role 'push_a' (walk), 'push_b' (1-unit
    print) or 'wall' (resting), in SIZING priority order (A, B, walls); the adapter sends walls first on the wire.
      '+': A buy  IOC walk_qty @ last tick < lo  (only when lo is finite: it can only take wrong-side asks)
           B buy  1 IOC @ last tick < hi, or first tick >= lo + reach when hi is unbounded
      '-': A sell IOC walk_qty @ first tick >= hi (only when hi is finite)
           B sell 1 IOC @ first tick >= lo, or last tick < hi - reach when lo is unbounded
      walls: bid @ first tick >= lo (a later seller still prints >= lo) when lo is finite, ask @ last tick < hi when hi
           is finite (only if the range holds more than one tick, so the two walls never trade with each other).
    After A, the best level on B's side is inside the range, so B prints there; B's limit only caps what one unit may
    cost. If A could not clear every wrong-side level, B may print on the wrong side - which is where the settle was
    anyway. Returns [] if no tick lies in [lo, hi)."""
    first_ok = first_at_or_above(lo) if math.isfinite(lo) else -math.inf   # lowest tick >= lo (float-exact)
    top = last_below(hi) if math.isfinite(hi) else math.inf          # highest tick < hi
    if first_ok > top + 1e-9:
        return []
    out = []
    if side == "+":
        if walk_qty > 0 and math.isfinite(lo):
            out.append(("+", int(walk_qty), round(first_ok - C.TICK, 2), True, "push_a"))
        lim = top if math.isfinite(top) else floor_tick(first_ok + reach)
        out.append(("+", 1, round(lim, 2), True, "push_b"))
    else:
        if walk_qty > 0 and math.isfinite(hi):
            out.append(("-", int(walk_qty), ceil_tick(hi), True, "push_a"))
        lim = first_ok if math.isfinite(first_ok) else ceil_tick(top - reach)
        out.append(("-", 1, round(lim, 2), True, "push_b"))
    if wall_units > 0:
        # one tick inside the range: a later multi-unit print AT the wall can carry float noise (55.61999999999999 for
        # 55.62) and must not land on the boundary
        wb = round(first_ok + C.TICK, 2) if math.isfinite(lo) else None
        wa = round(top - C.TICK, 2) if math.isfinite(hi) else None
        if wb is not None and wa is not None and wb > wa - 1e-9:
            # narrow mixed range: inside walls would cross each other -> boundary walls, if they don't cross either
            wb, wa = (first_ok, top) if first_ok < top - 1e-9 else (None, None)
        if wb is not None and (not math.isfinite(hi) or wb < hi):
            out.append(("+", int(wall_units), wb, False, "wall"))
        if wa is not None and (not math.isfinite(lo) or wa >= lo):
            out.append(("-", int(wall_units), wa, False, "wall"))
    return out


def deep_stage1(wins, bids, asks, mid, budget, max_gap):
    """v10 deep push, stage 1 (the second before the close): when the strike is beyond the visible ETF ladder, walk the
    whole ladder toward it so the market maker re-quotes closer; the close-second push finishes the job.
    Only when every window we hold wants the same side. Returns (side, lo, hi, units, cost, stake) or None."""
    ups = [k for k, p in wins if p > 0]
    dns = [k for k, p in wins if p < 0]
    stake = sum(abs(p) for _, p in wins)
    if ups and not dns:
        lo, hi, side = max(ups), math.inf, "+"
        if not asks or lo - asks[0][0] > max_gap:
            return None
        lv = [(p, q) for p, q in asks if p < lo]
    elif dns and not ups:
        lo, hi, side = -math.inf, min(dns), "-"
        if not bids or bids[0][0] - hi > max_gap:
            return None
        lv = [(p, q) for p, q in bids if p >= hi]
    else:
        return None
    units, cost = 0, 0.0
    for p, q in lv:
        take = min(q, budget - units)
        if take <= 0:
            break
        units += take
        cost += abs(p - mid) * take
    if units <= 0:
        return None
    return side, lo, hi, units, cost, stake


def synthetic_ladder(best_bid, best_ask):
    """Backtest stand-in for the ETF book: config ladder offsets from the touch -> (bids desc, asks asc)."""
    lad = C.SETTLE_PUSH["ladder"]
    asks = [(round(best_ask + off, 2), q) for off, q in lad]
    bids = [(round(best_bid - off, 2), q) for off, q in lad]
    return bids, asks


def _walk(levels, ok, beyond):
    """Walk book levels (best first) until a level price satisfies ok(price).
    beyond(price) -> True if the price has gone past the target range (no level can work any more).
    Returns (units consumed before the target, target price, [(price, qty) consumed]) or None."""
    consumed, fills = 0, []
    for price, qty in levels:
        if ok(price):
            return consumed, price, fills
        if beyond(price):
            return None
        consumed += qty
        fills.append((price, qty))
    return None


def plan_push(wins, bids, asks, mid, max_units):
    """Choose the cheapest ETF orders that make the settle print land where we win the most contracts.

    wins: [(strike, position)]  position > 0 = long UP (needs print >= strike), < 0 = long DOWN (print < strike).
    bids: [(price, qty)] best first (descending);  asks: [(price, qty)] best first (ascending).
    Returns (orders, units, est_cost_$, contracts_won, (lo, hi)) or None.
      orders: [(side, qty, limit_px)] - send in this order. The LAST order is 1 unit at the target level, so its
              print (= its average fill price) is exactly that level price.
    """
    from itertools import product
    best = None
    for mask in product([True, False], repeat=len(wins)):
        lo, hi, stake = -math.inf, math.inf, 0.0
        for (k, pos), use in zip(wins, mask):
            if not use:
                continue
            stake += abs(pos)
            if pos > 0:
                lo = max(lo, k)
            else:
                hi = min(hi, k)
        if stake == 0 or lo >= hi:
            continue
        ok = lambda p: lo <= p < hi
        for side, levels, beyond in (("+", asks, lambda p: p >= hi), ("-", bids, lambda p: p < lo)):
            r = _walk(levels, ok, beyond)
            if r is None:
                continue
            consumed, target, fills = r
            if consumed + 1 > max_units:
                continue
            orders = []
            if consumed:
                orders.append((side, consumed, fills[-1][0]))   # A: clear every level on the wrong side
            orders.append((side, 1, target))                     # B: 1 unit printed at the target level
            cost = sum(abs(p - mid) * q for p, q in fills) + abs(target - mid)
            cand = (stake, -cost, orders, consumed + 1, cost, (lo, hi))
            if best is None or cand[:2] > best[:2]:
                best = cand
    if best is None:
        return None
    stake, _, orders, units, cost, rng = best
    return orders, units, cost, stake, rng
