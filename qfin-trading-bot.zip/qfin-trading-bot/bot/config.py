"""
config.py - every tunable parameter for the bot, in one place.

All prices are in dollars ($0.01 = 1 cent). Inventory is in units (fruit/ETF) or contracts (options).
Numbers marked [data] were estimated from the Jan-Jun 2026 historical data (see the findings docs).
Numbers marked [guess] are sensible starting points that should be tuned with backtest.py / on the live exchange.
"""

FRUITS = ["apples", "bananas", "oranges", "strawberries", "watermelon"]
PRODUCTS = FRUITS + ["etf"]
OPTION_EXPIRIES = [5, 60]          # minutes (the 15-minute option was dropped)
TICK = 0.01                        # price grid

# =====================================================================================================
# MODE SWITCH - decided by live_check.py after a few hours of live data
#   "kalman": prices snap back like the historical data -> centre quotes on the Kalman fair value and
#             switch on the flow-dependent signals (pair lean, long-run level, big-move rules, option drift)
#   "mid":    flow looks random -> centre on the mid and switch those signals off
# =====================================================================================================
CENTRE_MODE = "kalman"

# =====================================================================================================
# FEATURE FLAGS - every feature can be switched off individually (backtest.py --disable name1,name2)
# =====================================================================================================
FEATURES = dict(
    compete_quotes=True,     # beat the best price in the book by 1 tick, but never past our fair +- min edge
    vol_widen=False,         # widen quotes at the top of the hour / midnight / wide book. OFF: cost ~$730/day in the
                             #   backtest; switch on if live fills get picked off more than the replay suggests
    etf_basket_lean=True,    # lean fruit quotes against ETF inventory (and ETF quotes against fruit inventory)
    etf_hedge=False,         # if net basket exposure gets too big, hedge it with fruit (IOC). OFF: the ETF inventory
                             #   cap (50) already bounds the risk and crossing 5 fruit spreads cost ~$800/day in the
                             #   backtest. Switch ON if you raise the ETF inventory cap.
    etf_bot_guard=True,      # don't sell ETF into the size-30 buyers (or buy into sellers) when the basket gap is big
    pair_lean=True,          # [kalman mode] apples-oranges spread mean reversion
    pair_passive=True,       # PAIR TRADE (passive) [ON by default: +$290/day (kalman) / +$2,100/day (mid) at 25% share]: when the oranges-apples spread is stretched, set opposite TARGET
                             #   inventories (long the cheap leg, short the rich leg, same units) and let the normal
                             #   market-making quotes fill them. Works in 'kalman' AND 'mid' mode (see pair_mid_mode).
                             #   See PAIR_TRADE below.
    pair_aggressive=False,   # PAIR TRADE (aggressive) [OFF by default: pays both spreads, and beat passive only in kalman mode]: take BOTH legs with IOC orders when the stretch beats the cost
                             #   of crossing both spreads. Also sets the target inventories so the quotes keep the
                             #   position instead of unwinding it. Works in both modes.
    pair_mid_mode=True,      # allow the pair trade when centre_mode == "mid" (flow signals off). The pair signal only
                             #   uses mids, so it does not need the Kalman filter, but the reversion was measured on
                             #   historical flow - check it live first (live_check.py now prints the spread reversion).
    pair_stop_ioc=True,      # a stop-loss exit crosses the spread (IOC) to cut the pair; other exits unwind passively
    long_run=True,           # [kalman mode] hold a small inventory toward each fruit's long-run level
    big_moves=False,         # [kalman mode] fade watermelon jumps, follow strawberry jumps. OFF: no effect in the
                             #   backtest (the Kalman filter already captures it)
    option_take=True,        # cross the option spread when model edge > threshold
    option_quote=True,       # rest option quotes around the model price (earn from retail flow)
    settle_value=True,       # price in our ability to set the settle with a 1-lot ETF trade
    settle_nudge=False,      # superseded by settle_push (kept for reference: the old 1-lot version)
    delta_hedge=False,       # hedge the option book's ETF delta with ETF (see DELTA_HEDGE). Tested before switching on.
    book_reach=True,         # LIVE only: value the push with the REAL ETF book (how far up the asks / down the bids we can
                             #   afford to walk) instead of 'touch + SETTLE_PUSH.reach'. If the strike is beyond the top of the
                             #   book the option is valued as unpushable and we stop holding it.   Needs s.etf_levels.
    settle_push=True,        # OPTION MANIPULATION (allowed by the organisers): in the close second, trade ETF so the
                             #   settle print lands on our side of the strike - walking the book if needed - and value
                             #   options assuming we can do this (see SETTLE_PUSH)
    straw_flow=True,         # v8: strawberry 2-hour reversion after the size-150 buyer (see STRAW_FLOW). Needs the trade tape:
                             #   live it comes from self.download_data() (background thread); if that isn't available the
                             #   feature stays idle (target 0) - it never blocks a tick.
    option_drift_live=True,  # v9: price options off ETF + drift x (basket - ETF) in mid mode too (OPTIONS.drift_by_exp)
    etf_unwind=True,         # v9: trim ETF inventory left by settle pushes (IOC at the touch, away from the closes)
    jump_signals=True,       # v10: strawberry buy-run follow + watermelon jump fade from the BOOK (see JUMPS)
    momentum_pull=False,     # v13: OFF (fruit fell from ~$169/h on v11 to ~$100/h on v12.1). v12: no bid after a 4c+ 60 s rise, no offer after a 4c+ fall (MOM_PULL)
    open_up_buy=True,        # v14: buy 5m UP from the house in the first 60 s of each window (<= 55c, up to 500) and hold to
                             #   the close (our settle push defends it). Gated on the last 12 closes: UP must have won >= 55%. See OPTIONS.open_up_buy.
    option_short_swap=False, # v11: OFF. Live Oct 11 07:38-12:58: short book +$77 on 9.5k contracts, and shorting at the open displaced
                             #   the cheap long (shorted windows avg -$30 UP / +$111 DOWN vs +$231 / -$100 unshorted; ~-$1k per 5 h). v10.4: mid-window shorts of rich 5m UP, always covered before the close (OPTIONS.short_swap)
    deep_push=False,         # v10.1: OFF. Live Oct 11 00:45 it walked 105 units to 55.04 (strike 55.09); the house re-quoted
                             #   17 units at 55.03 within 0.7 s, margin left no room for the close-second walk, and the window
                             #   was lost anyway. The market maker re-quotes at its own fair value, so stage 1 doesn't move it.
    reversion_2h=True,       # v9.2: every fruit gives back ~30% of its last-2-hour move over the next 2 hours (the strawberry
                             #   buyer's 2-hour give-back, generalised; tape-free, works in 'mid' mode). See REVERSION_2H.
    flatten=False,           # v9: OFF. The team kit's market rules: positions are valued at the mid all the time and every
                             #   position is closed at the end of the day, so crossing spreads to get flat only costs money.
                             #   (was ON: reduce inventory before the daily reset (passive, then IOC at the very end).
                             #   Costs ~$750/day in the backtest; switch off if the reset marks positions at mid
)

# =====================================================================================================
# FRUIT / ETF QUOTING
#   centre   = fair value (or mid) - skew x (inventory - target inventory) + signal leans
#   our bid  = min(best bid + 1 tick, centre - min_edge)   (best bid = best price from ANYONE else in the book)
#   our ask  = max(best ask - 1 tick, centre + min_edge)
#   -> we are first in line whenever that still leaves us at least min_edge from our fair value.
# =====================================================================================================
QUOTE = {
    #               lots  min edge  skew/unit  max |inv|                                   [data]+[guess]
    "apples":       dict(size=20, min_edge=0.015, skew=0.0003, max_inventory=300),
    "bananas":      dict(size=20, min_edge=0.010, skew=0.0003, max_inventory=300),
    "oranges":      dict(size=20, min_edge=0.015, skew=0.0003, max_inventory=300),
    "strawberries": dict(size=20, min_edge=0.010, skew=0.0003, max_inventory=300),
    "watermelon":   dict(size=10, min_edge=0.025, skew=0.0005, max_inventory=150),   # most informed flow
    "etf":          dict(size=5,  min_edge=0.04,  skew=0.002,  max_inventory=50),    # 15c spread, ~1 lot deep
}
# Normal (calm) spread of the market maker, used to detect "the book is wider than usual -> be careful"  [data]
NORMAL_SPREAD = {"apples": 0.06, "bananas": 0.06, "oranges": 0.06, "strawberries": 0.06,
                 "watermelon": 0.06, "etf": 0.14}

VOL_WIDEN = dict(
    minutes_from_hour=5,     # within 5 min of the top of the hour volatility is ~1.5-2.6x  [data]
    extra_top_of_hour=0.005,
    hours_utc=[23, 0],       # around midnight UTC volatility is ~1.7x  [data]
    extra_midnight=0.005,
    excess_spread_frac=0.5,  # add half of (book spread - normal spread) to our min edge
)

# =====================================================================================================
# SIGNALS (kalman mode only)
# =====================================================================================================
ETF_LEAN = dict(
    fruit_per_etf_unit=0.0003,   # each unit of ETF inventory shifts every fruit centre by this ($) [guess]
    etf_per_fruit_unit=0.0004,   # each unit of average fruit inventory shifts the ETF centre        [guess]
)
ETF_HEDGE = dict(
    trigger=40,                  # |ETF inventory| above this -> hedge with fruit via IOC            [guess]
    clip=10,                     # ETF units hedged per second (10 units of each fruit)
)
ETF_BOT_GUARD = dict(
    gap=0.08,                    # size-30 ETF trades start when |basket mid - ETF mid| > ~8.5c     [data]
)
PAIR = dict(
    span_s=120,                  # EMA of the oranges-apples spread
    k=0.4,                       # 60s corr of spread deviation with future spread move ~ -0.43     [data]
)
# =====================================================================================================
# PAIR TRADE: oranges - apples spread (features pair_passive / pair_aggressive)
#   spread    = oranges mid - apples mid           (long-run average ~$1.04, level correlation 0.91)      [data]
#   dev       = spread - EMA(spread, PAIR.span_s)  (sd ~5c, beyond +-5c about 28% of the time)            [data]
#   dev +5-8c -> spread falls ~5c in 60 s, ~5.5c in 5 min;  dev > 8c -> ~7.5c in 60 s, ~8c in 5 min     [data]
#   (symmetric for negative dev; reversion holds out to 15 min)
#
#   dev > 0 : oranges rich  -> SHORT oranges, LONG apples          dev < 0 : the opposite
#   Both legs are always the same number of units (1:1, OLS slope 1.04), so the pair stays hedged.
#   "pair position" = (apples inventory - oranges inventory) / 2 for a long-apples/short-oranges pair, in units
#   PER LEG, measured from actual inventory (so market-making fills in the two fruits count towards the cap).
#
#   Life cycle (one pair "trade" at a time):
#     OPEN   when |dev| >= enter_dev (passive) or the aggressive test passes. The EMA at that moment is frozen as the
#            "anchor" (the live EMA chases a stretched spread, which would fake a reversion).
#     SCALE  target grows with the deviation (tiers); it is never cut back while the trade is open.
#     CLOSE  (1) reverted: spread is within exit_dev of the anchor      (2) time stop: hold_max_s since open
#            (3) stop-loss: spread has moved stop_dev AGAINST us since the open   (4) late in the day (RISK.flatten_start)
#            After a close the target is 0, so the market-making quotes unwind the legs passively; the stop-loss
#            additionally crosses the spread (feature pair_stop_ioc). RISK.flatten_ioc flattens everything at day end.
#     COOLDOWN no new trade for cooldown_s after a close (avoids re-entering a spread that just stopped us out).
# =====================================================================================================
PAIR_TRADE = dict(
    # ---- sizing (units PER LEG) ----
    max_units=100,               # PAIR POSITION CAP per leg (also bounded by each leg's QUOTE.max_inventory and, live,
                                 #   by LIVE.inventory_scale and the exchange position limit)                [guess]
    # ---- passive version: target inventory by stretch ----
    tiers=[(0.05, 0.5),          # |dev| >= 5c -> target = 50% of max_units   (5-8c  bucket: ~5c reversion)   [data]
           (0.08, 1.0)],         # |dev| >= 8c -> target = 100% of max_units  (>8c bucket: ~7.5c reversion)   [data]
    skew_mult=1.0,               # while a pair trade is open, apples/oranges inventory skew (QUOTE.*.skew) is
                                 #   multiplied by this: bigger = quotes lean harder towards the target inventory  [guess]
    # ---- exits ----
    exit_dev=0.0,                # close when the spread is back within this of the frozen anchor (0 = fully back;
                                 #   backtest: 0 beat 0.5c / 1.5c / 3c by $30-150/day)                          [tuned]
    hold_max_s=600,              # time stop, seconds (0 = off). Reversion is documented out to 15 min        [data]
    stop_dev=0.0,                # stop-loss: spread moved this far against us since the open (0 = OFF, default).
                                 #   A 15c stop cost $120/day (passive) / $30-70/day (aggressive) in the backtest:
                                 #   stretched spreads keep reverting, and the pair cap already bounds the loss
                                 #   (100 units x 15c = $15 per trade). Set 0.15 to enable.                    [tuned]
    warmup_s=120,                # no new trade until the EMA has seen this many seconds (one span)           [guess]
    cooldown_s=30,               # seconds after a close before a new trade may open                          [guess]
    # ---- aggressive version: IOC both legs ----
    aggr_rev_frac=0.8,           # expected reversion = this x |dev| (5c of 6.5c, 7.5c of ~9c)                 [data]
    aggr_min_net=0.01,           # take only if expected reversion - cost of crossing both spreads >= this    [guess]
                                 #   cost = (apples spread + oranges spread) / 2, read from the books (~6c)
    aggr_clip=10,                # max units per leg per IOC (also capped by the displayed size at the touch
                                 #   of BOTH legs, so both legs fill completely at the touch)                 [guess]
    aggr_cooldown_s=3,           # seconds between aggressive IOCs                                            [guess]
    aggr_max_units=100,          # aggressive position cap per leg (<= max_units)                             [guess]
)

# =====================================================================================================
# STRAWBERRY FLOW (v8). An informed bot buys strawberries in clips of exactly 150 (92% of size-150 strawberry prints are buys,
# ~20-30/day). It pushes the price up for ~2 minutes, then over the next ~2 HOURS the price gives it back:
#     next-2h strawberry move (c) = 11 - 6.6 x (number of size-150 buys in the last 2 h)     [data: 31 hist days + Oct 6-10]
# Out of sample (fit on 16 hist days): hist->live correlation 0.42; a +-75 unit target rebalanced every 30-60 min made
# ~$80-100/day, positive on 14-15 of 15 held-out days and 3-4 of 5 live days. Small but steady; scales with max_units.
# The count only needs minute-old data, so the 1-minute-delayed download_data() tape is good enough.
# =====================================================================================================
# =====================================================================================================
# JUMPS (v10, FEATURES.jump_signals): book-only signals that work in the hosted (pipe-mode) runtime, where the bot sees the
# order book once a second but no trade sizes (download_data() is a no-op there).
#   strawberries: 3 up-jumps of >= 7c in the mid within 120 s = the size-150 buyer is RUNNING -> buy, hold, unwind.
#                 (A single jump reverts - 08_findings - but a run of three continues.)
#                 hist (8 days): 9.4/day, +11.8c @60s, +13.9c @300s; live Oct 7-10: 7/day, +10.6c / +16.7c (after the ask)
#   watermelon:   a >= 7c one-second jump reverses (live: -6.5c @60s, -9.8c @300s) -> lean the target against it
# =====================================================================================================
JUMPS = dict(
    straw_jump=0.07, straw_k=3, straw_window_s=120, straw_cooldown_s=60,
    straw_units=60,              # units bought per signal (IOC at the ask + straw_tol)                         [guess]
    straw_max_pos=150,           # never take the strawberry position above this through the signal              [guess]
    straw_tol=0.01,
    straw_hold_s=240, straw_decay_s=120,   # target +straw_units for 4 min, then fades to 0 over 2 min           [data]
    wm_jump=0.07, wm_units=30, wm_hold_s=300,                                                                # [data]
)

STRAW_FLOW = dict(
    intercept=0.11,              # $ expected 2h move with no recent buying                                 [data]
    per_buy=-0.066,              # $ per size-150 buy in the lookback                                       [data]
    full_at=0.20,                # expected move ($) that earns the full target                             [guess]
    max_units=60,                # target inventory cap (live fruit cap is 75 at inventory_scale 0.25)      [guess]
    lookback_s=7200,             # count window                                                             [data]
    clip_size=150,               # the buyer's fingerprint
    refresh_s=600,               # live: refetch the tape this often (background thread; the 2h count barely moves) [guess]
    min_history_s=3600,          # live: don't trade the signal until the tape covers at least this much of the window
)

# =====================================================================================================
# v9.2 2-HOUR REVERSION (all fruits, tape-free)
# The strawberry size-150 buyer pushes the price up for ~2 minutes and the market gives it back over ~2 HOURS. The same
# give-back holds for every fruit and needs no trade tape, only the mid 2 hours ago:
#     next-2h move = beta x (mid now - mid 2 h ago),   beta ~ -0.27 ... -0.35 (all 5 fruits, hist 15 days + live Oct 6-10)
# Sim (minute grid, target updated every 15-30 min, 1.5c/unit cost): cap 75 units/fruit, full size at a 15c expected move
# -> +$311-468/day live, positive on 15/15 historical and 5/5 live days. The target steers the normal quotes (passive).
# History lives in the strategy, which restarts each day, so there is no signal in a day's first 2 hours (and none at
# all in short days).
# =====================================================================================================
REVERSION_2H = dict(
    beta=-0.30,                  # expected next-2h move per $ of last-2h move                              [data]
    lookback_s=7200,             # compare with the mid this long ago                                       [data]
    sample_s=60,                 # mid history sampled once a minute
    full_at=0.15,                # expected move ($) that earns the full target                             [data: sim]
    max_units={"apples": 60, "bananas": 60, "oranges": 60, "strawberries": 60, "watermelon": 30},
                                 # target cap (live caps: fruit 75, watermelon 37 at inventory_scale 0.25)  [guess]
)

LONG_RUN = dict(
    levels={"apples": 10.70, "bananas": 8.57, "oranges": 11.75, "strawberries": 9.54,
            "watermelon": 12.74},  # Jan-Jun 2026 averages [data]; live: re-estimate (data may start elsewhere)
    span_s=24 * 3600,              # anchor = EMA of the mid over ~24 h, started at `levels`
    units_per_dollar=100,          # target inventory = 100 x (anchor - fair), e.g. 67c gap -> 67 units [guess]
    max_target=100,
)
BIG_MOVES = dict(
    threshold=0.30,              # a >30c move within 60 s
    lean={"watermelon": -0.20,   # fade: next 5 min moves -7c on a ~33c jump                       [data]
          "strawberries": 0.15}, # follow: next 5 min +6c                                          [data]
    decay_s=300,                 # lean fades out over 5 minutes
)

# =====================================================================================================
# OPTIONS
# =====================================================================================================
OPTIONS = dict(
    take_edge=0.05,              # cross when |model - touch| > 5c (default; take_edge_by_exp overrides)  [data]
    take_edge_by_exp={5: 0.10, 60: 0.05, 15: 0.05},   # v8: 5m needs 10c. Replay of our live Oct 8-10 option books (cap 500, 50/s at the
                                 #   touch, real outcomes): 5c -> 10c raised 5m P&L on all 3 days (+$1.8k/+$1.1k/+$0.4k).
                                 #   The 5m window is cap-bound (~470 of 500 contracts/window live), so being pickier buys
                                 #   the same contracts at better prices. 15c+ started losing on Oct 10.          [data]
    take_edge_early_by_exp={5: 0.20, 60: 0.10, 15: 0.10},   # v9.2: be pickier EARLY in a window (more than early_seconds_by_exp left).
                                 #   Each window is cap-bound (500 contracts): live, v9.1 bought ~465 of its ~480 contracts per
                                 #   5m window in the first minute, then had no room for the better prices that come later.
                                 #   Live option-book replay (cap 500, 50/s at the touch, real outcomes), 5m P&L Oct 7/8/9/10:
                                 #     10c flat (v9.1)          -$0.4k  $17.8k  $12.5k  $10.6k   = $40.6k
                                 #     20c early, 10c last 60 s  $5.7k  $23.6k  $15.1k  $10.8k   = $55.1k  (better every day)
                                 #     25c early                 $8.0k  $25.4k  $16.8k  $10.3k   = $60.4k  (Oct 10 worse)
                                 #   Oct 10 to 16:00 UTC (incl. 24 v9 windows): 10c $11.6k, 20c $12.3k, 25c $11.7k -> the best
                                 #   early edge has been drifting down, so 20c. 60m: 10c early / 5c in the last 10 min:
                                 #   $2.0k -> $3.0k over Oct 7-10, better on all 4 days.                         [data]
    early_seconds_by_exp={5: 60, 60: 600, 15: 180},   # v9.2: 'early' = more than this many seconds before the close
    tail_nu={5: None, 60: 8, 15: None},    # v8: Student-t tails (degrees of freedom) for the ETF move; None = normal. 60m moves have fat
                                 #   tails (best fit nu 6-10, 06_findings.md). Replay: +$360/+$560/+$170 on Oct 8/9/10 (60m),
                                 #   historical take sim +2c/contract. 5m stays normal (no gain).                   [data]
    regime_gate={5: dict(n=12, rate=0.50, min=8), 60: dict(n=6, rate=0.50, min=4)},
    regime_sell={5: dict(n=12, rate=0.25, min=8, cap=500)},
                                 #   v16 DOWN MODE: when UP has won <= 25% of the last 12 5m closes, allow shorting UP up to 500
                                 #   (same as the long cap), defended by the settle push. 25-50% is a neutral band.
                                 #   Cap sweep, Oct 6-12 books, model short-takes, real outcomes (5m): rate 0.25 -> +$9 / +75 /
                                 #   +129 / +257 at cap 200/350/500/800; rate 0.35 -> negative at every cap (-$0.2k to -1.5k);
                                 #   open sell sweep negative at every cap. Oct 15 (deep down regime): gate on ~57 windows, DOWN
                                 #   won ~86% of them. 60m short: negative at every cap (50-500) -> no 60m DOWN mode.
                                 #   v15: STOP BUYING UP on every path (open buy, model take, resting bid) when UP has won
                                 #   < rate of the last n settled closes (needs >= min closes first, else open). Reducing a
                                 #   long and the settle push are untouched. Oct 15 live: UP won 11/92 5m windows; the open
                                 #   buy off-switch held (-7c), but model takes -37c, resting bids -47c, 60m -50c a contract
                                 #   kept loading UP into the down trend because the model assumes we can push the settle up.
                                 #   The regime gate flattens options into a down regime so we earn only fruit/ETF there.
    open_up_buy={5: dict(open_s=60, max_price=0.70, cap=500, gate_n=12, gate_rate=0.60, gate_min=6,
                         sweep_over=0.05, sweep_max=350, first_qty=350, first_limit=0.20)},
                                 #   v14.1: max_price 55c -> 70c and gate 55% -> 60%. Same replay (Oct 6-12, per 288 windows):
                                 #     55c / gate 55% (v14): avg +$7.2k/day, worst day -$4.5k
                                 #     70c / gate 60%:       avg +$9.6k/day, worst day -$2.3k   (75-95c: no further gain)
                                 #   60m open buy tested too: negative at every cap (-$0.1-0.2k/day) -> not added.
                                 #   v14.1 SPEED. The exchange matches option orders in a batch at ~x.06 s each second, and the house
                                 #   offers a ladder (~50 at the ask, 100 at +2c, 200 at +5c) that it reprices up every second.
                                 #   Live 14:05-14:20 UTC Oct 13: The Fruity Boys / qfingroup3 sweep the whole ladder in the FIRST
                                 #   batch (1.06 s) at 6-14c; v14 got in at 2.07 s and took 50 a second, so it paid ~16-20c.
                                 #   sweep_over/sweep_max: each open buy takes the ladder (limit ask + 5c, <= max_price, <= 350).
                                 #   first_qty/first_limit: right after our late push (sent at close + ~0.8 s, when the NEW 5m
                                 #   window already trades) also send a blind IOC for the new window: buy up to 350 at <= 20c,
                                 #   so we are in the 1.06 s batch with them. Fills only what the house offers at <= 20c.
                                 #   v14: OPEN UP BUY. Live Oct 12/13 the house SOLD 5m UP in the first minute at 48c/37c avg and UP
                                 #   won 81%/82% (+33c/+45c a contract); The Fruity Boys buy ~500 at the open every window and hold.
                                 #   Replay of our live 5m books Oct 6-12 (50/s at the touch, +1c per 50 bought, real outcomes),
                                 #   500 cap, 55c, 60 s, gate 12 closes >= 55% UP: -$0.1k/-4.5k/+4.0k/+3.5k/+3.7k/+20.0k/+5.7k (Oct 12
                                 #   file = 77 windows only). Without the gate Oct 6-7 (UP 45-49%) lost $4.4-6.0k a day.
                                 #   gate_min: until this many closes have been seen the gate is open.
    max_contracts=500,           # absolute position cap per window (50 -> 300 -> 500: live we sat at the 300 cap on both
                                 #   windows, and 500 beat 300 in every push-fail stress test, see README).
                                 #   Live: scaled by LIVE.option_inventory_scale and the exchange position limit
    short_swap={5: dict(edge=0.15, cap=500, cover_s=60)},   # v10.4: short the 5m UP when bid - value(short) > 15c,
                                 #   up to 500, and buy it ALL back once 60 s or less are left (never short into the close).
    trim_long={5: dict(edge=0.02, min_left=60)},   # v10.3: sell some of a long UP position back when bid - value > 2c
                                 #   with more than 60 s left (frees cap for cheaper buys later). Never opens a short.
    sell_up={5: False, 60: False, 15: True},   # v9: 60m too - our resting 60m asks were lifted at -37c/contract on Oct 10
                                 #   (-$4.0k on 10.7k contracts) while 60m UP buys made +$5.2k; we hold UP and push the close.  # v6: never SELL UP in 5m windows (no resting asks, no sell takes): hold to settle.
                                 #   Live fills, 5m: our resting asks lifted -$7.7k (Oct 8) / -$4.2k (Oct 9); our sell takes
                                 #   $0 / -$4.5k; every way of buying UP made money (+$13.0k / +$10.7k).           [data]
    max_short=100,               # max SHORT-UP (long-DOWN) contracts per window. Live Oct 8-9 fills: 17 windows with a short
                                 #   of 300+ won 1 and lost ~$3.4k (UP won 17/17); shorts under 300 were net positive. Longs keep
                                 #   max_contracts (long 300+: +$2.2k)                                          [data]
    clip=50,                     # contracts per take order
    quote_size=20,               # resting quote size per side                                      [guess]
    quote_min_edge=0.03,         # rest quotes at least 3c from model                               [guess]
    quote_min_edge_by_exp={5: 0.15},   # v12: 5m resting bid at least 15c under the long value (was 3c). Replay of live books
                                 #   + public option tape Oct 8-12 vs v11 (10 contracts, 3c): +$1.6k/+1.8k/+2.2k/+3.1k/+0.6k (part day),
                                 #   positive every day. Takes (take_edge) are unchanged.
    quote_size_by_exp={5: 50},   # v12: 5m resting size 20 -> 50 (x LIVE.option_quote_scale 0.5 = 25 contracts live)
    quote_skew=0.001,            # shift quotes 0.1c per contract of position
    min_seconds_left=2,          # stop trading in the last 2 s (settle mechanics)
    etf_drift=0.55,              # ETF closes ~55% of its gap to the basket (kalman mode)           [data]
    drift_by_exp={5: 0.8, 60: 0.3, 15: 0.5},   # v9: used in EVERY mode (FEATURES.option_drift_live). Live replay Oct 7-10, 5m P&L:
                                 #   drift 0 / 0.55 / 0.8 / 1.0 -> $28.0k / 38.2k / 40.6k / 42.1k (better on all 4 days);
                                 #   60m mixed, so smaller. The basket predicts the settle better than the ETF mid for
                                 #   anything 30 s+ out (hit rate .656 vs .639 at 4 min): pushes knock the ETF off its basket. [data]
    settle_bias=0.0,             # $ added to (ETF mid - strike) in the model. 0 for the historical backtests; LIVE overrides it
                                 #   (live Oct 8-9: settle - mid(close-3s) averaged +1.2c; adding it cut Brier .1189 -> .1134
                                 #   and raised model-vs-quote edge P&L about 25%)                              [data]
)
SETTLE = dict(
    max_gap=0.075,               # only nudge when the ETF mid is within ~half an ETF spread of strike
    size=1,                      # 1-lot: a "small change", as agreed with the organisers
    p_we_set_settle={5: 0.72, 60: 0.53},   # P(no-one else trades ETF in the close second)          [data]
)

# =====================================================================================================
# RISK
# =====================================================================================================
# =====================================================================================================
# SETTLE PUSH - options manipulation
#   An up/down option settles on the LAST ETF TRADE at/before the close second, and a trade's recorded price is the
#   AVERAGE fill price of the order. So in the close second we can print almost any price within reach of the ETF book:
#     want UP   -> need a print >= strike: buy up the ask side (order A walks every level below the strike,
#                  order B buys 1 unit at the first level >= strike, so B's print = that level price)
#     want DOWN -> need a print <  strike: same, selling down the bid side
#   A tie (print == strike) resolves UP.
#   When 5m and 60m close in the same second (top of the hour) the bot picks the print range that wins the most
#   contracts across both windows.
# =====================================================================================================
SETTLE_PUSH = dict(
    reach=0.10,                  # $ beyond the ETF touch we assume we can print, used to VALUE options.
                                 #   0.10 backtested best (0.20: -$2.4k/day, 0.30: -$3.5k/day vs 0.10)
    max_units=200,               # v9: 120 -> 200. Live, windows with the ETF 7-15c below the strike were won only 41% of the
                                 #   time (pushes fell short); ~20-80 ETF units walk 8-11c. The adapter still clips to margin.
                                 #   (was: max ETF units spent pushing one window (sum over re-fires). Raised 40 -> 120 for a
                                 #   push WAR (another team printing against us); backtest P&L identical    [guess]
    reach_cap=0.60,              # never value a push further than this many $ from the mid (live book depth is thin/uncertain)
    cost_frac=0.5,               # push only if est. cost (incl. unwinding) <= 50% of contracts at stake
    p_win={5: 0.72, 60: 0.53, 15: 0.6},   # P(nobody else trades ETF after us in the close second) - historical,
                                 #   will FALL if other teams fight the close too                           [data]
    late_extra_units=100,        # v10: 50 -> 100 extra ETF units for the late push on top of max_units (the walk is sized for
                                 #   the book on ARRIVAL, which the market maker has usually refilled since the tick)
    deep_reach=0.25,             # v10 deep push: strike beyond the visible ladder but within 25c of the touch -> walk the
                                 #   whole ladder in the second before the close (stage 1); the close-second push finishes
    early_buffer=5,              # v9.2 live: the early push's walk order may take this many units more than it saw on the
                                 #   wrong side (its limit is the last wrong-side tick, so it never buys on our side)
    fire_seconds=1.5,            # v9: 3.0 -> 1.5: early push only on the last tick before the close; the decisive push is now
                                 #   the LATE push inside the close second (exchange_adapter._late_push, LIVE.late_push*)            # live: first push at 3 s left (was 1.5), then re-fire on every tick where the latest
                                 #   ETF print is on the wrong side, until the close                          [guess]
    # Synthetic ETF book beyond the touch for the BACKTEST only ($ beyond touch, units). Shape from historical
    # fills: ~8 units within 2c of the touch, then a gap to ~10c, ~23c and ~30c levels.                    [data]
    ladder=[(0.00, 1), (0.01, 2), (0.02, 2), (0.03, 3), (0.10, 4), (0.23, 8), (0.30, 30)],
    unwind_mult=1.0,             # backtest: charge the price displacement again for unwinding the ETF bought
)

DELTA_HEDGE = dict(
    # The option book gains when the ETF rises (long UP) or falls (short UP). Hold ETF against that:
    #   target ETF = -frac x (sum over windows of contracts x dP(up)/d ETF), capped at +-max_units.
    frac=0.5,                    # fraction of the delta to hedge (1.0 = fully)
    max_units=80,                # backtest cap; LIVE.delta_hedge_units caps it live (margin: ~$55/unit)
    band=4,                      # only trade when |target - ETF inventory| > band
    clip=10,                     # ETF units per IOC per second
    skip_last_s=30,              # ignore a window's delta in its last 30 s (the push decides it; delta explodes)
)

ETF_UNWIND = dict(
    threshold=40,                # |ETF inventory| above this -> trim with IOCs                                     [guess]
    clip=20,                     # v10: 10 -> 20 units per IOC (pushes can now leave 100-300 units)
    quiet_s=20,                  # no trimming in the last 20 s before a 5m close (or the first 3 s after one)
)

# v9.2 SHORT DAYS. The final test runs every team's bot for 20 days of 60 minutes (exchange config: backtestDays 20,
# backtestDayMin 60), scored by mean - sd of DAILY P&L, so one 60m window (up to 500 contracts, a single coin flip) is
# a whole day's bet there. When the day is at most max_day_minutes long (config dayLengthMin, or the measured gap
# between day ends) the bot scales option caps by option_cap_scale. Live days are 1440 minutes: no change live.
SHORT_DAY = dict(
    max_day_minutes=180,
    option_cap_scale={60: 0.4, 15: 0.6},   # 5m stays at full size (hourly Sharpe of the 5m book ~1 on the live replay)
)

RISK = dict(
    daily_loss_limit=3000.0,     # v9: 1500 -> 3000 (one 5m window is ~$250 at stake; a short losing streak shouldn't
                                 #   switch the bot off for the rest of the day)     # beyond this loss: only reduce risk                               [guess]
    flatten_start=(23, 30),      # UTC: shrink inventory caps, quote only the reducing side, no new 60m options
    flatten_ioc=(23, 55),        # UTC: cross the spread to get flat before the reset
    flatten_clip=20,             # units per product per second when flattening by IOC
)

# Live deployment defaults. Raise these only after observing account fills/margin.
LIVE = dict(
    centre_mode="mid",              # historical mean reversion is not assumed live
    enable_options=True,            # options ON (needed for the settle push)
    settle_push=True,               # options manipulation in the close second (see SETTLE_PUSH)
    option_inventory_scale=1.0,     # option caps use OPTIONS.max_contracts x this (not inventory_scale)
    option_quote_scale=0.5,         # resting option quote size = OPTIONS.quote_size x this
    delta_hedge_units=60,           # live ETF cap for the delta hedge (60 x ~$55 = ~$3.3k margin)
    settle_bias=0.012,              # see OPTIONS.settle_bias (live-calibrated, Oct 8-9)
    straw_flow=False,               # v8.1: OFF. v8's first download_data() pulled every day's files during trading and
                                    #   the bot crash-looped (on_tick > 5 s). Re-enable only after async_orders proves stable.
    pair_trade=True,                # master switch for the pair trade LIVE (still needs FEATURES.pair_passive /
                                    #   pair_aggressive on). Pair units scale with inventory_scale (100 -> 10 per leg).
    quote_size_scale=0.40,          # v10.2: 0.25 -> 0.40 (fruit 5 -> 8 units a side). Our maker fills keep +0.7-0.9c a unit
                                    #   60 s later (Oct 9-10, 290k units/day); inventory caps (inventory_scale) unchanged.
             # 20 -> 5, 10 -> 2; ETF 5 -> 1 (was 0.10; fruit/ETF caps were only ~3-12 units live)
    fruit_quote_units=dict(apples=16, bananas=16, oranges=12, strawberries=16, etf=8),   # v13: ETF 2 -> 8 units a side (Spud/T4 make 9-11c a unit making the ETF on ~1k units/h; our ETF maker fills mark out +1.4..3.5c)   # v11: units per fruit quote (overrides
                                    #   quote_size_scale; watermelon/ETF unchanged). 86% of public fruit taker units come in prints
                                    #   >8 units; our 8-unit quotes only take the first 8 (Oct 10 replay of the tape).
    fruit_inventory_cap=dict(apples=120, bananas=120, oranges=120, strawberries=120, etf=30),   # v13: ETF quote cap 12 -> 30 (below ETF_UNWIND.threshold 40)   # v11: was 75 (300 x 0.25)
    fruit_big_cap_equity=15000,     # ...but only while equity >= this (a day starts at $10k; worst-case fruit margin at 120 units
                                    #   would leave too little for the 60+ unit ETF settle pushes). Below it: 75 as before.
    pair_scale=0.60,                # v11: apples/oranges pair 25 -> 60 units a leg. Live spread dev beyond 5c reverts 2.3-4.9c in
                                    #   5 min (Oct 9-11 tape); Spudtrading and LHF run this pair at ~100.
    inventory_scale=0.25,           # 300 -> 75, 150 -> 37, ETF 50 -> 12 (was 0.10). The adapter still clips to margin_fraction
    margin_fraction=0.80,           # leave 20% of equity as a buffer
    stale_seconds=3.0,
    late_push=True,                 # v9: push the settle late INSIDE the close second (the settle is the last ETF trade in it)
    late_push_at_s=0.80,            # v10.1: 0.70 -> 0.80. Other teams now trade after our late push more often (Oct 10: 11 of 93
                                    #   windows, 2 flipped; Oct 11 first hour: 3 of 8, 1 flipped). Our fills land ~0.05 s after
                                    #   we send, so 0.80 still leaves ~0.15 s inside the close second.            # v9: send at close + 0.70 s (our orders land ~0.08-0.4 s after we send)
    late_push_buffer=30,            # v9.2: 10 -> 30. Extra units on the 'walk' order A for wrong-side levels that appear after we
                                    #   looked (the house refills what the early push took: Oct 10, 20+ new units in 0.7 s). A's
                                    #   limit is now the last tick on the wrong side, so the buffer can only buy wrong-side levels.
    late_push_b_reach=0.40,         # v9.2: order B (1 unit) may print up to 40c past the strike: any print on our side wins,
                                    #   and if B found nothing to buy, A's wrong-side print would be the last one
    late_push_tolerance=0.03,       # v9: the 1-unit print order may fill up to 3c past the planned level (v9.2: at least b_reach)
    late_wall_units=40,             # v10.2: 10 -> 40. A seller arriving after our close-second push hits this bid one tick
                                    #   above the strike instead of printing the settle below it (Oct 10: 11 of 93 windows had a
                                    #   trade after our push). Sized after the walk and the print, so margin never starves them.
                # v9: resting ETF order on our side of the strike after the push (house flow after us)
    late_min_walk=60,               # v10: the late walk (A) is at least this many units whenever the wrong side is bounded. Its
                                    #   limit is the last wrong-side tick, so it only fills levels that are really there on
                                    #   arrival (house refills, a late seller); margin clips it, never below what we saw.
    slow_call_s=3.5,                # v9.1: 2.0 -> 3.5. Live, calls routinely take 2-2.7 s without stalling, and the 2 s rule kept
                                    #   the bot in a 120 s pause (no fruit requotes). The kill is at 5 s; 3.5 s is the warning sign.
    cooldown_s=15.0,                #     ... for this long, doubling (max cooldown_max_s) if it happens again within 5 min
    cooldown_max_s=60.0,
    requote_s=2.0,                  # v9 (pipe mode): resting-quote-only refreshes at most every 2 s; IOCs go immediately
    async_orders=True,              # v8.1: plan + send orders on a background thread; on_tick never waits for the exchange
    lock_timeout_s=0.5,             # v8: max wait for the SDK state lock (v7 waited forever -> 5 s kills, 109 restarts)
    send_budget_s=3.0,              # v8: if this tick has already used this long, don't send orders this second
    min_option_seconds=5.0,
    reset_flatten_start_seconds=0,  # v9: positions are closed at the mid at day end (market rules) -> no late-day wind-down
    reset_flatten_ioc_seconds=0,
    log_every_ticks=30,
    # Optional CSV logs on a writable filesystem. Server log download is not documented.
    log_directory=None,
    log_max_bytes=5_000_000,         # one bounded CSV file, rotated once
)

# v12 MOMENTUM PULL (FEATURES.momentum_pull). Live Oct 11 13:17 - Oct 12 06:30, our fruit maker fills (680k units), 60 s markout
# by the side-signed 60 s mid move before the fill: <-4c +1.4..+2.2c | -4..0c +0.4..+1.0c | 0..+4c -0.5..+0.7c | >+4c -0.6..-1.7c
# (watermelon positive in every bucket -> excluded). Skipping the >+4c fills saves ~$1.2k (Oct 12) to ~$2.7k (Oct 11) a day.
MOM_PULL = dict(
    products=("apples", "bananas", "oranges", "strawberries"),
    thr=0.04,                    # $ move in lookback_s that pulls the with-the-move side
    lookback_s=60,
    allow_reduce_units=90,       # keep quoting the pulled side if inventory on the other side is beyond 90 units (live caps 75-120)
)

