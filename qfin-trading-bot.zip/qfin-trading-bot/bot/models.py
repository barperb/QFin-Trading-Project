"""
models.py - pricing models used by the bot.

  FairValue      Kalman-filter estimate of each fruit's hidden fair value (step 4 findings)
  OptionModel    probability that an up-down option finishes UP (step 3 findings), with and without
                 the settle-second trade under our control
  Ema            tiny exponential-moving-average helper used for signals
"""
import json, math, os
import numpy as np
from scipy.special import ndtr, stdtr   # normal CDF and Student-t CDF, vectorised and fast
from config import FRUITS

# =====================================================================================================
# Fruit fair value: joint Kalman filter
#   hidden fair F (random walk, correlated across fruits)
#   mid moves toward fair:  mid(t+1) - mid(t) = theta * (F(t) - mid(t)) + noise
# Parameters fitted by maximum likelihood on 1-7 Jan 2026, validated on 28 other days.
# =====================================================================================================
THETA = np.array([0.03793, 0.03732, 0.0388, 0.03535, 0.01844])         # pull toward fair, per second
Q_VAR = np.array([2.471e-05, 2.857e-05, 2.984e-05, 5.282e-05, 1.339e-04])  # fair variance per second
R_VAR = np.array([1.212e-04, 1.193e-04, 1.184e-04, 1.240e-04, 2.787e-04])  # noise in 1-s mid moves
CORR = np.array([[1.0, -0.077, 0.654, -0.106, -0.266],                 # correlation of fair moves
                 [-0.077, 1.0, -0.148, 0.217, -0.173],                 # (apples-oranges 0.65)
                 [0.654, -0.148, 1.0, -0.185, -0.291],
                 [-0.106, 0.217, -0.185, 1.0, -0.083],
                 [-0.266, -0.173, -0.291, -0.083, 1.0]])


class FairValue:
    """Call update(mids) once per second; returns {fruit: fair, 'etf': sum of fruit fairs}."""

    def __init__(self):
        sd = np.sqrt(Q_VAR)
        self.Q = np.outer(sd, sd) * CORR
        self.H = np.diag(THETA)
        self.R = np.diag(R_VAR)
        self.I = np.eye(5)
        self.F = None                    # current fair estimates
        self.P = np.eye(5) * 1e-4        # their uncertainty (~1c to start)
        self.prev = None                 # last second's mids

    def update(self, mids: dict) -> dict:
        m = np.array([mids[p] for p in FRUITS], float)
        if self.F is None:               # first call: start fair at the mid
            self.F, self.prev = m.copy(), m
        else:
            # surprise = how the mid actually moved minus how much it should have moved toward our fair
            v = (m - self.prev) - THETA * (self.F - self.prev)
            S = self.H @ self.P @ self.H.T + self.R
            K = self.P @ self.H.T @ np.linalg.inv(S)          # how much to trust the surprise
            self.F = self.F + K @ v
            self.P = (self.I - K @ self.H) @ self.P + self.Q  # update, then let fair drift for 1 s
            self.prev = m
        out = dict(zip(FRUITS, self.F))
        out["etf"] = float(self.F.sum())                    # ETF fair = sum of fruit fairs
        return out


# =====================================================================================================
# Option model
#   The option settles on the LAST ETF TRADE at/before the close second, not the mid. That trade is usually
#   at the bid or the ask, so settle = mid(T) + noise, noise sd ~11c (empirical quantiles in option_params.json).
#   ETF mid at expiry ~ Normal(mid now + drift, var), var = sigma^2 x (intraday variance weights summed over
#   the remaining seconds) -> captures the top-of-hour / midnight volatility pattern.
# =====================================================================================================
class OptionModel:
    def __init__(self, path=os.path.join(os.path.dirname(os.path.abspath(__file__)), "option_params.json")):
        with open(path, encoding="utf-8") as source:
            p = json.load(source)
        self.sig2 = p["sigma_per_sqrt_s"] ** 2
        mm, hm = p["minute_var_mult"], p["hour_var_mult"]
        w = np.array([mm[(s // 60) % 60] * hm[s // 3600] for s in range(86400)])
        w /= w.mean()
        self.cum = np.concatenate([[0.0], np.cumsum(np.tile(w, 2))])   # cumulative variance weight (2 days)
        self.noise = np.array(p["settle_noise_quantiles"])
        self.nu = {}        # v8: {expiry_min: Student-t degrees of freedom} (config OPTIONS.tail_nu); missing/None = normal
        self.bias = 0.0     # $ added to (ETF mid - strike): live settles print ~1.2c above the mid (see OPTIONS.settle_bias)

    def _cdf(self, a, exp=None):
        """P(Z <= a) for the standardised ETF move: normal, or a unit-variance Student-t for expiries in self.nu."""
        nu = self.nu.get(exp) if exp is not None else None
        if not nu:
            return ndtr(a)
        return stdtr(nu, np.asarray(a) * math.sqrt(nu / (nu - 2.0)))

    def _sd(self, sec_of_day, seconds_left):
        var = self.sig2 * (self.cum[sec_of_day + seconds_left] - self.cum[sec_of_day])
        return math.sqrt(max(var, 1e-10))

    def prob_up(self, sec_of_day, seconds_left, etf_mid, strike, basket_mid=None, drift=0.0, exp=None, noise_free=False):
        """P(settle >= strike) when nobody controls the settle. noise_free: settle on the ETF mid (no print noise)."""
        x = etf_mid - strike + (0.0 if noise_free else self.bias)
        if basket_mid is not None:
            x += drift * (basket_mid - etf_mid) * min(1.0, seconds_left / 60)
        if noise_free:
            return float(self._cdf(np.array([x]) / self._sd(sec_of_day, seconds_left), exp)[0])
        return float(self._cdf((x + self.noise) / self._sd(sec_of_day, seconds_left), exp).mean())

    def prob_up_controlled(self, sec_of_day, seconds_left, etf_mid, strike, etf_half_spread, p_control,
                           want_up, basket_mid=None, drift=0.0, exp=None):
        """P(settle >= strike) if we hold a position and send a 1-lot ETF order in the close second.
        With probability p_control nobody else trades that second and the settle is OUR trade price:
        the ETF ask (if we want UP) or bid (if we want DOWN) ~ mid(T) +- half spread.
        Otherwise the settle is someone else's last trade (the normal noise)."""
        x = etf_mid - strike + self.bias
        if basket_mid is not None:
            x += drift * (basket_mid - etf_mid) * min(1.0, seconds_left / 60)
        sd = self._sd(sec_of_day, seconds_left)
        p_free = float(self._cdf((x + self.noise) / sd, exp).mean())
        shift = etf_half_spread if want_up else -etf_half_spread
        p_ours = float(self._cdf((x + shift) / sd, exp))
        return p_control * p_ours + (1 - p_control) * p_free


    def prob_up_pushed(self, sec_of_day, seconds_left, etf_mid, strike, etf_half_spread, reach, p_win,
                       want_up, basket_mid=None, drift=0.0, exp=None):
        """P(settle >= strike) for a position we will DEFEND with a settle push.
        With probability p_win our print is the last ETF trade of the close second, and we can print anywhere up to
        `reach` beyond the touch: we win UP if mid(T) + half spread + reach >= strike (want_up), and DOWN if
        mid(T) - half spread - reach < strike. Otherwise someone else's trade sets the settle (normal noise)."""
        x = etf_mid - strike + self.bias
        if basket_mid is not None:
            x += drift * (basket_mid - etf_mid) * min(1.0, seconds_left / 60)
        sd = self._sd(sec_of_day, seconds_left)
        p_free = float(self._cdf((x + self.noise) / sd, exp).mean())
        shift = (etf_half_spread + reach) if want_up else -(etf_half_spread + reach)
        p_ours = float(self._cdf((x + shift) / sd, exp))
        return p_win * p_ours + (1 - p_win) * p_free


class Ema:
    """Exponential moving average with a span in seconds (alpha = 2 / (span + 1))."""

    def __init__(self, span_s, start=None):
        self.a = 2.0 / (span_s + 1.0)
        self.value = start

    def update(self, x):
        self.value = x if self.value is None else self.value + self.a * (x - self.value)
        return self.value
