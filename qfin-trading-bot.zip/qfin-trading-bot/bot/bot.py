"""QFin upload entry point. exchange.py is supplied by the exchange."""
from strategy import Bot  # preserves historical backtest.py's `from bot import Bot`
from exchange_adapter import ExchangeAdapter

if __name__ == "__main__":
    ExchangeAdapter().run()
