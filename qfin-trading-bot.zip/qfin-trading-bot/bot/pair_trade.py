"""
pair_trade.py - apples/oranges pair trade (oranges mid - apples mid mean-reverts to its 2-minute EMA).

See config.PAIR_TRADE for the statistics behind it and the life cycle. This module is pure logic (no network):
Bot.on_second() calls PairTrade.update() once per second with the current spread, its EMA and the books, and gets back

    targets   {"apples": units, "oranges": units}   extra TARGET INVENTORY for the market-making quotes
                                                     (passive version: the normal quotes lean towards it and fill it)
    ioc       [(product, side, qty, limit_px, tag)]  immediate orders (aggressive version, and the stop-loss exit)

Direction d = sign(deviation): d = +1 -> spread rich -> SHORT oranges / LONG apples (targets: apples +q, oranges -q).
Both legs always carry the same number of units, so the pair is hedged 1:1 (the spread is oranges - apples, slope ~1).

IOC tags: "pair" (aggressive entry, both legs) and "pair_stop" (stop-loss exit, both legs). The live adapter sizes the two
legs of one tag TOGETHER (same quantity on both, clipped by caps and margin) so a partial plan never leaves one leg open.
"""
import math
import config as C

LEGS = ("apples", "oranges")


class PairTrade:
    def __init__(self, passive, aggressive, stop_ioc, scale=1.0):
        self.passive, self.aggressive, self.stop_ioc = passive, aggressive, stop_ioc
        self.scale = scale                 # live: LIVE.inventory_scale (units per leg shrink with it); backtest: 1
        self.samples = 0                   # seconds of EMA history (warm-up)
        self.d = 0                         # 0 = no open trade, +1 / -1 = direction of the open trade
        self.anchor = 0.0                  # EMA frozen when the trade opened
        self.entry_spread = 0.0
        self.open_ts = 0.0
        self.peak_away = 0.0               # largest stretch (in our direction) beyond the anchor since the open
        self.cooldown_until = -math.inf
        self.last_aggr_ts = -math.inf
        self.stats = dict(opens=0, closes_reverted=0, closes_time=0, closes_stop=0, closes_late=0,
                          aggr_orders=0, aggr_units=0, stop_orders=0)

    # ---------------------------------------------------------------------------------------------
    @property
    def max_units(self):
        return C.PAIR_TRADE["max_units"] * self.scale

    @staticmethod
    def pair_pos(positions, d):
        """Pair position per leg in direction d: + when we are long apples / short oranges (d = +1) or the reverse."""
        return d * (positions.get("apples", 0.0) - positions.get("oranges", 0.0)) / 2.0

    def tier_fraction(self, away):
        """Fraction of max_units for a stretch of `away` (dollars): the highest tier reached, 0 below the first."""
        frac = 0.0
        for threshold, f in C.PAIR_TRADE["tiers"]:
            if away >= threshold - 1e-12:
                frac = f
        return frac

    # ---------------------------------------------------------------------------------------------
    def update(self, ts, spread, ema, books, positions, late, halted):
        """ts: epoch seconds. books: {product: (bid, ask, bid_size, ask_size)}. Returns (targets, ioc)."""
        P = C.PAIR_TRADE
        self.samples += 1
        dev = spread - ema
        ioc = []

        # ---- manage an open trade: exits first
        if self.d:
            away = self.d * (spread - self.anchor)          # > 0: spread still stretched in our direction
            self.peak_away = max(self.peak_away, away)
            adverse = self.d * (spread - self.entry_spread)  # > 0: spread moved further against us
            reason = None
            if late:
                reason = "late"
            elif P["stop_dev"] and adverse >= P["stop_dev"]:
                reason = "stop"
            elif away <= P["exit_dev"]:
                reason = "reverted"
            elif P["hold_max_s"] and ts - self.open_ts >= P["hold_max_s"]:
                reason = "time"
            if reason:
                if reason == "stop" and self.stop_ioc:
                    ioc += self._stop_exit(books, positions)
                self._close(ts, reason)

        # ---- open a new trade
        d_new = 0
        if not self.d and not late and not halted and ts >= self.cooldown_until and self.samples > P["warmup_s"]:
            d = 1 if dev > 0 else -1
            if self.passive and abs(dev) >= P["tiers"][0][0] - 1e-12:
                d_new = d
            elif self.aggressive and self._aggr_edge(dev, books) >= P["aggr_min_net"]:
                d_new = d
            if d_new:
                self.d, self.anchor, self.entry_spread, self.open_ts = d_new, ema, spread, ts
                self.peak_away = d_new * (spread - ema)
                self.stats["opens"] += 1

        # ---- aggressive entry / scale-in: IOC both legs, same units
        pending = 0
        if self.aggressive and self.d and not late and not halted:
            pending = self._aggr_entry(ts, dev, books, positions, ioc)

        # ---- target inventory
        if not self.d:
            return {}, ioc
        q = 0.0
        if self.passive:
            q = self.max_units * self.tier_fraction(self.peak_away)
        if self.aggressive:
            q = max(q, max(0.0, self.pair_pos(positions, self.d)) + pending)
        q = min(q, self.max_units)
        return {"apples": self.d * q, "oranges": -self.d * q}, ioc

    # ---------------------------------------------------------------------------------------------
    @staticmethod
    def crossing_cost(books):
        """Cost of crossing both spreads, in spread units: half of each leg's quoted spread (~3c + ~3c)."""
        return sum((books[p][1] - books[p][0]) / 2.0 for p in LEGS)

    def _aggr_edge(self, dev, books):
        """Expected reversion minus the cost of crossing both spreads (dollars per unit of pair)."""
        return C.PAIR_TRADE["aggr_rev_frac"] * abs(dev) - self.crossing_cost(books)

    def _aggr_entry(self, ts, dev, books, positions, ioc):
        P = C.PAIR_TRADE
        d = self.d
        if (1 if dev > 0 else -1) != d or self._aggr_edge(dev, books) < P["aggr_min_net"]:
            return 0
        if ts - self.last_aggr_ts < P["aggr_cooldown_s"]:
            return 0
        held = max(0.0, self.pair_pos(positions, d))
        room = min(P["aggr_max_units"] * self.scale, self.max_units) - held
        buy, sell = ("apples", "oranges") if d > 0 else ("oranges", "apples")   # buy the cheap leg, sell the rich one
        # leg inventory room (per-leg market-making cap, scaled live) and displayed size at the touch of BOTH legs
        buy_room = C.QUOTE[buy]["max_inventory"] * self.scale - positions.get(buy, 0.0)
        sell_room = C.QUOTE[sell]["max_inventory"] * self.scale + positions.get(sell, 0.0)
        depth = min(books[buy][3], books[sell][2])        # ask size of the leg we buy, bid size of the leg we sell
        clip = max(1, int(round(P["aggr_clip"] * self.scale)))
        n = int(min(clip, room, buy_room, sell_room, depth))
        if n < 1:
            return 0
        ioc.append((buy, "+", n, books[buy][1], "pair"))
        ioc.append((sell, "-", n, books[sell][0], "pair"))
        self.last_aggr_ts = ts
        self.stats["aggr_orders"] += 1
        self.stats["aggr_units"] += n
        return n

    def _stop_exit(self, books, positions):
        """Stop-loss: cross both spreads to cut the pair we hold (equal units on both legs)."""
        held = self.pair_pos(positions, self.d)
        if held < 1:
            return []
        buy, sell = ("oranges", "apples") if self.d > 0 else ("apples", "oranges")   # reverse the entry legs
        n = int(min(held, books[buy][3], books[sell][2], max(1, round(C.PAIR_TRADE["aggr_clip"] * self.scale * 2))))
        if n < 1:
            return []
        self.stats["stop_orders"] += 1
        return [(buy, "+", n, books[buy][1], "pair_stop"), (sell, "-", n, books[sell][0], "pair_stop")]

    def _close(self, ts, reason):
        self.stats["closes_" + reason] += 1
        self.d = 0
        self.cooldown_until = ts + C.PAIR_TRADE["cooldown_s"]
