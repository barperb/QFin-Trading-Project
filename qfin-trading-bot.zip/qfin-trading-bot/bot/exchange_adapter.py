"""SDK-backed live bridge for the QFin Fruit Exchange.

Use the provided SDK for authentication, websocket reconnects, and exchange backtests.
Take one consistent state copy per tick. No external internet access is needed.
The SDK has no documented passive-fill callback; account P&L is authoritative.
"""
import copy
import csv
import json
import math
import os
import time
from concurrent.futures import ThreadPoolExecutor, wait as futures_wait
from collections import defaultdict, deque
from types import SimpleNamespace

import pandas as pd
from exchange import Exchange, Buy, Sell, CancelAll, BACKTEST
from strategy import Bot, plan_push, floor_tick, ceil_tick, robust_push_orders, deep_stage1
from models import FairValue
import config as C


class DataUnavailable(RuntimeError):
    pass


class SkipTick(RuntimeError):
    """v8: skip sending this second without cancelling resting quotes (slow exchange / busy state lock)."""
    pass


def _find_trades_frame(obj, depth=0):
    """v8: dig the fruit trades table out of whatever download_data() returns (its format isn't documented):
    a DataFrame, a dict of tables/paths, a list, or a path to a file/folder of parquet files."""
    import glob as _glob
    if depth > 4 or obj is None:
        return None
    if isinstance(obj, pd.DataFrame):
        cols = set(obj.columns)
        return obj if {"product", "size", "aggressor"} <= cols else None
    if isinstance(obj, dict):
        keys = sorted(obj, key=lambda k: (("option" in str(k)), not ("trade" in str(k))))
        for k in keys:
            if "option" in str(k):
                continue
            got = _find_trades_frame(obj[k], depth + 1)
            if got is not None:
                return got
        return None
    if isinstance(obj, (list, tuple)):
        for x in obj:
            got = _find_trades_frame(x, depth + 1)
            if got is not None:
                return got
        return None
    if isinstance(obj, (str, os.PathLike)):
        p = os.fspath(obj)
        if os.path.isdir(p):
            files = [f for f in _glob.glob(os.path.join(p, "**", "*trades*.parquet"), recursive=True)
                     if "option" not in os.path.basename(f)]
            files.sort(key=os.path.getmtime)
            return _find_trades_frame(files[-1], depth + 1) if files else None
        if os.path.isfile(p) and p.endswith(".parquet") and "option" not in os.path.basename(p):
            return _find_trades_frame(pd.read_parquet(p), depth + 1)
    return None


class TapeFetcher:
    """v8: background thread that refreshes the trade tape with the SDK's download_data() (the Data page says today's files
    are rewritten every minute) and keeps the timestamps of strawberry size-150 BUYS. Never runs inside on_tick."""

    def __init__(self, adapter):
        self.adapter = adapter
        self.times = None            # numpy array of epoch seconds, or None if no tape yet
        self.covers_from = None      # earliest second the tape covers
        self.last_ok = None
        self.error = None
        self._started = False

    def start(self):
        if self._started or BACKTEST:
            return
        self._started = True
        import threading
        threading.Thread(target=self._loop, daemon=True, name="tape").start()

    def _call(self):
        fn = getattr(self.adapter, "download_data", None)
        if fn is None:
            raise RuntimeError("SDK has no download_data()")
        # SDK (seen in the live log): download_data(dest='data', *, overwrite_today=True) -> list[str]; finished days are
        # skipped once downloaded, so only the first call pulls every day.
        paths = fn("qfin_tape", overwrite_today=True)
        today = time.strftime("%Y-%m-%d", time.gmtime())
        mine = [p for p in (paths or []) if "option" not in os.path.basename(os.path.dirname(os.fspath(p)))
                and os.path.basename(os.path.dirname(os.fspath(p))) == "trades" and today in os.fspath(p)]
        return mine or paths

    def _loop(self):
        logged = False
        while True:
            try:
                res = self._call()
                if not logged:
                    logged = True
                    desc = type(res).__name__
                    if isinstance(res, dict):
                        desc += f" keys={list(res)[:12]}"
                    elif isinstance(res, (str, os.PathLike)):
                        desc += f" {os.fspath(res)}"
                    self.adapter.log(f"download_data() returned {desc}")
                df = _find_trades_frame(res)
                if df is None:
                    df = _find_trades_frame(os.getcwd())          # maybe it wrote files to the working folder
                if df is None:
                    raise RuntimeError("no trades table found in download_data() result")
                ts = pd.to_datetime(df["ts"], utc=True)
                sel = ((df["product"] == "strawberries") & (df["size"] == C.STRAW_FLOW["clip_size"])
                       & (df["aggressor"] == "buy"))
                secs = ts.astype("int64").values // 10**9
                self.times = secs[sel.values]
                self.covers_from = int(secs.min()) if len(secs) else None
                self.last_ok = time.time()
                self.error = None
            except Exception as exc:
                if str(exc) != self.error:
                    self.adapter.warn(f"straw_flow tape unavailable: {type(exc).__name__}: {exc}")
                self.error = str(exc)
            time.sleep(C.STRAW_FLOW["refresh_s"])

    def count(self, now_s):
        """Size-150 strawberry buys in the last lookback window, or None if the tape is missing/stale/too short."""
        sf = C.STRAW_FLOW
        if self.times is None or self.last_ok is None or time.time() - self.last_ok > 3 * sf["refresh_s"]:
            return None
        if self.covers_from is None or now_s - self.covers_from < sf["min_history_s"]:
            return None
        return int(((self.times > now_s - sf["lookback_s"]) & (self.times <= now_s)).sum())


class ExchangeAdapter(Exchange):
    def __init__(self, settings=None):
        super().__init__()
        self.settings = dict(C.LIVE, **(settings or {}))
        if not 0 < self.settings["margin_fraction"] <= 1:
            raise ValueError("margin_fraction must be in (0, 1]")
        for key in ("quote_size_scale", "inventory_scale"):
            if not 0 < self.settings[key] <= 1:
                raise ValueError(f"{key} must be in (0, 1]")
        self.strategy = self._new_strategy()
        self._late_done = set()          # v9: windows already late-pushed
        self._push_log = []              # v9: late-push records (for the periodic log line)
        self.tape = TapeFetcher(self)
        self.day = None
        self.busts = None
        self.last_version = None
        self.last_second = None
        self.ticks = 0
        self.status = None
        self.last_results = []
        self.last_actions = []
        self._pending_version = None
        self._pending_at = None
        self._last_cancel_at = -math.inf
        self._has_gap = False
        self._last_log_warning = None

    def _new_strategy(self):
        enabled = self.settings["enable_options"]
        pair = self.settings["pair_trade"]
        bot = Bot(centre_mode=self.settings["centre_mode"], pair_scale=self.settings.get("pair_scale") or self.settings["inventory_scale"], features={
            # Apples/oranges pair trade (see config.PAIR_TRADE). Units per leg scale with inventory_scale; the pair IOCs
            # are sized as ONE unit in plan_orders (same quantity on both legs, inside caps and margin).
            "pair_passive": pair and C.FEATURES["pair_passive"],
            "pair_aggressive": pair and C.FEATURES["pair_aggressive"],
            "option_take": enabled and C.FEATURES["option_take"],
            "option_quote": enabled and C.FEATURES["option_quote"],
            # Last-second print assumptions are not verified against the live server.
            "settle_value": False,
            "settle_nudge": False,
            # Options manipulation (allowed by the organisers): print the ETF settle on our side in the close second.
            "settle_push": enabled and self.settings["settle_push"] and C.FEATURES["settle_push"],
            # Value the push with the real ETF book (live only; the backtest has no depth).
            "book_reach": enabled and C.FEATURES["book_reach"],
            "delta_hedge": enabled and C.FEATURES["delta_hedge"],
            "straw_flow": self.settings.get("straw_flow", True) and C.FEATURES["straw_flow"],
        })
        bot.hedge_max = self.settings["delta_hedge_units"]
        bot.om.bias = self.settings["settle_bias"]
        # v9.2: short days (the final test's 60-minute days) scale the option caps (config.SHORT_DAY)
        bot.opt_cap_scale = dict(C.SHORT_DAY["option_cap_scale"]) if getattr(self, "short_day", False) else {}
        return bot

    def _rev_text(self):
        """v9.2: compact 2-hour-reversion state for the log: target units (expected 2h move in cents) per fruit."""
        st = self.strategy
        if not st.f.get("reversion_2h"):
            return "off"
        if not st.rev_pred:
            h = max((len(v) for v in st.rev_hist.values()), default=0)
            need = st.rev_hist["apples"].maxlen - 1
            return f"warming up ({max(0, h - 1)} of {need} minutes of history)"
        return ", ".join(f"{p[:5]} {int(st.rev_targets.get(p, 0)):+d} ({100 * v:+.0f}c)" for p, v in st.rev_pred.items())

    def _opt_scale(self, symbol):
        """v9.2: option cap multiplier for this symbol ('up60' -> expiry 60) on short days, else 1."""
        if not getattr(self, "short_day", False):
            return 1.0
        digits = "".join(ch for ch in symbol if ch.isdigit())
        return C.SHORT_DAY["option_cap_scale"].get(int(digits), 1.0) if digits else 1.0

    def _day_length(self, view):
        """v9.2: the trading day's length in minutes: config dayLengthMin, or the gap between two day ends we saw."""
        lengths = []
        try:
            dlm = (view._state.get("config") or {}).get("dayLengthMin")
            if isinstance(dlm, (int, float)) and dlm > 0:
                lengths.append(float(dlm))
        except Exception:
            pass
        de = view.account.day_end
        prev = getattr(self, "_prev_day_end", None)
        if prev and de and de > prev + 30:
            lengths.append((de - prev) / 60.0)
        if de:
            self._prev_day_end = de
        return min(lengths) if lengths else None

    def _log_sdk_surface(self):
        """v8, once at start: log what the SDK offers (method names, state keys). Research aid: we are looking for a
        real-time trade feed with sizes (the strawberry size-150 signal needs one; see 06_findings.md)."""
        try:
            names = sorted(n for n in dir(Exchange) if not n.startswith("__"))
            self.log("SDK methods: " + ", ".join(names)[:1500])
            with_lock = self._lock(0.2)
            try:
                keys = sorted(self._state.keys()) if isinstance(getattr(self, "_state", None), dict) else []
                book = (self._state.get("books") or {}) if keys else {}
                sample = sorted(next(iter(book.values())).keys()) if book else []
            finally:
                if with_lock:
                    self._state_lock.release()
            self.log(f"SDK state keys: {keys}; book keys: {sample}")
            dd = getattr(Exchange, "download_data", None)
            if dd is not None:
                import inspect
                try:
                    sig = str(inspect.signature(dd))
                except (TypeError, ValueError):
                    sig = "?"
                self.log(f"download_data{sig}: {(inspect.getdoc(dd) or '')[:400]}")
        except Exception as exc:                 # never let diagnostics break trading
            self.warn(f"sdk surface log failed: {type(exc).__name__}: {exc}")

    def _post(self, path, *, method="POST", json=None):
        # Prevent a stalled order request consuming the entire five-second tick budget.
        if BACKTEST:
            return super()._post(path, method=method, json=json)
        return self._http.request(method, f"{self._base_url}{path}", json=json,
                                  timeout=(0.75, 1.25))

    def _lock(self, timeout):
        """v8: acquire the SDK state lock with a time limit. v7 used `with self._state_lock`, which blocks forever: when an
        order batch is slow (Oct 10: 'batch failed (7139ms): exchange unavailable') the SDK can hold this lock, on_tick passed
        the platform's 5 s limit and the bot was killed and restarted (109 restarts on the Bots page). Returns True if held."""
        try:
            return self._state_lock.acquire(timeout=timeout)
        except TypeError:                       # a lock type without timeout support: fall back to blocking
            self._state_lock.acquire()
            return True

    def _submit_orders(self, view, snapshot, actions, version):
        """v8.1: run execute_actions (plan + state recheck + batch) on the single background worker thread."""
        if not hasattr(self, "_pool"):
            self._pool = ThreadPoolExecutor(max_workers=1)
            self._inflight = None
        if self._inflight is not None and not self._inflight.done():
            return                                    # still sending last second's orders: skip this second
        # wait for post-order state before planning again (same rule as the synchronous path)
        self._pending_version = version
        self._pending_at = time.monotonic()
        tick_t0 = self._tick_t0

        def job():
            try:
                self._tick_t0 = tick_t0
                self.execute_actions(view, snapshot, actions, version, in_worker=True)
            except SkipTick as exc:
                self._pending_version = None
                self._set_status(str(exc))
            except Exception as exc:
                self._pending_version = None
                self._has_gap = True
                self._set_status(f"{type(exc).__name__}: {exc}")
                try:
                    self.batch([CancelAll()])         # we are already off the tick clock here
                except Exception as exc2:
                    self.warn(f"quote cancellation failed: {type(exc2).__name__}: {exc2}")
        self._inflight = self._pool.submit(job)

    def _batch_busy(self):
        """True while the previous order batch is still running in the background thread."""
        return (not BACKTEST) and getattr(self, "_inflight", None) is not None and not self._inflight.done()

    def _capture(self):
        if not self._lock(self.settings.get("lock_timeout_s", 0.5)):
            return None
        try:
            raw = copy.deepcopy(self._state)
            version = self._state_version
            updated_at = self._state_updated_at
        finally:
            self._state_lock.release()
        # A read-only SDK view ensures account, books and orders share the same state.
        view = object.__new__(Exchange)
        view._state = raw
        view._state_updated_at = updated_at
        return view, version, updated_at

    def _set_status(self, message):
        if message != self.status:
            self.warn(message)
            self.status = message

    # ------------------------------------------------------------------------------------------------
    # v9: call-latency guard. Hosted bots run in the SDK's pipe mode (BACKTEST=True): every API call goes through the
    # platform runner synchronously, and when the exchange stalls a call takes 5-7 s ('batch failed (7139ms): exchange
    # unavailable') and the platform kills the bot for on_tick > 5 s. Threads can't help (the pipe isn't thread-safe), so:
    # at most one call per tick, fewer calls overall, and a cooldown after any slow or failed call.
    # ------------------------------------------------------------------------------------------------
    def _timed_batch(self, actions):
        t0 = time.monotonic()
        ok = True
        try:
            res = self.batch(actions)
            if res == [] and actions:            # the SDK returns [] when the request failed
                ok = False
            return res
        except Exception:
            ok = False
            raise
        finally:
            dt = time.monotonic() - t0
            st = self.__dict__.setdefault("_lat", {"n": 0, "slow": 0, "max": 0.0, "sum": 0.0, "fails": 0})
            st["n"] += 1; st["sum"] += dt; st["max"] = max(st["max"], dt)
            self.__dict__.setdefault("_lat_recent", deque(maxlen=20)).append(dt)
            if not ok:
                st["fails"] += 1
            if dt > self.settings.get("slow_call_s", 2.0) or not ok:
                st["slow"] += 1
                now = time.monotonic()
                prev = getattr(self, "_cooldown_len", 0.0)
                recent = now - getattr(self, "_cooldown_set_at", -1e9) < 300
                length = min(self.settings.get("cooldown_max_s", 120.0),
                             (prev * 2) if (recent and prev) else self.settings.get("cooldown_s", 15.0))
                self._cooldown_len = length
                self._cooldown_set_at = now
                self._cooldown_until = now + length
                self.warn(f"slow/failed exchange call ({dt:.2f}s, ok={ok}); pausing non-critical orders for {length:.0f}s")

    def _cooling_down(self):
        return time.monotonic() < getattr(self, "_cooldown_until", 0.0)

    def _batch_deadline(self, actions, deadline_s):
        """Send a batch but never block on_tick past deadline_s: the platform kills a bot whose on_tick runs over 5 s
        (v5.2 crash-looped 28 times on a slow exchange). Runs in one background thread. Returns the results, or None if
        the call is still in flight (it finishes in the background; the next tick reconciles against fresh state).
        If a previous call is still in flight, nothing new is sent this tick."""
        if BACKTEST:
            return self._timed_batch(actions)
        if not hasattr(self, "_pool"):
            self._pool = ThreadPoolExecutor(max_workers=1)
            self._inflight = None
        if self._inflight is not None and not self._inflight.done():
            return None
        self._inflight = self._pool.submit(self._timed_batch, actions)
        futures_wait([self._inflight], timeout=deadline_s)
        if not self._inflight.done():
            self.warn(f"order batch still running after {deadline_s:.1f}s; continuing without waiting")
            return None
        return self._inflight.result()          # re-raises the batch's own exception (e.g. a request timeout)

    def _pull_quotes(self, reason):
        self._has_gap = True
        self._set_status(reason)
        # Retry while disconnected: a prior cancel request may have failed.
        if self._cooling_down():
            return
        if time.monotonic() - self._last_cancel_at >= 1:
            self._last_cancel_at = time.monotonic()
            try:
                self._batch_deadline([CancelAll()], 1.5)
            except Exception as exc:
                self.warn(f"quote cancellation failed: {type(exc).__name__}: {exc}")

    @staticmethod
    def external_book(view, symbol):
        """Subtract own remaining size at each price, retaining other traders at that price."""
        own = defaultdict(int)
        for order in view.open_orders(symbol):
            own[(order.side, round(order.price, 8))] += max(0, order.remaining)
        book = view.book(symbol)
        def first(levels, side):
            for level in levels:
                qty = level.qty - own[(side, round(level.price, 8))]
                if qty > 0 and math.isfinite(level.price) and level.price > 0:
                    return float(level.price), int(qty)
            return None, 0
        bid, nb = first(book.bids, "buy")
        ask, na = first(book.asks, "sell")
        return bid, ask, nb, na

    @staticmethod
    def external_levels(view, symbol, depth=60):
        """Full external book (own orders removed), best first: (bids desc, asks asc) as [(price, qty)].
        Used by the settle push to plan how far to walk the ETF book."""
        own = defaultdict(int)
        for order in view.open_orders(symbol):
            own[(order.side, round(order.price, 8))] += max(0, order.remaining)
        book = view.book(symbol)
        def clean(levels, side):
            out = []
            for level in levels[:depth]:
                qty = level.qty - own[(side, round(level.price, 8))]
                if qty > 0 and math.isfinite(level.price) and level.price > 0:
                    out.append((float(level.price), int(qty)))
            return out
        return clean(book.bids, "buy"), clean(book.asks, "sell")

    def _reset_if_needed(self, view):
        day = view.account.day or str(view.account.day_end)
        busts = view.account.busts
        if day != self.day:
            day_min = self._day_length(view)
            self.short_day = day_min is not None and day_min <= C.SHORT_DAY["max_day_minutes"]
            self.strategy = self._new_strategy()
            self.day = day
            self.busts = busts
            self.log(f"day {day}: strategy reset; profile={self.settings['centre_mode']}; "
                     f"options={self.settings['enable_options']}; day length {day_min} min; short_day={self.short_day}"
                     + (f" (option caps x {C.SHORT_DAY['option_cap_scale']})" if self.short_day else ""))
        elif busts != self.busts:
            # Reset filters after a bust, but never clear the daily loss stop on a same-day reset.
            halted = self.strategy.halted
            self.strategy = self._new_strategy()
            self.strategy.halted = halted or view.pnl < -C.RISK["daily_loss_limit"]
            self.busts = busts

    def build_snapshot(self, view):
        if not view._state.get("serverTime"):
            raise DataUnavailable("missing exchange clock")
        if not view.account.day_end:
            raise DataUnavailable("missing account dayEnd; waiting for complete state")
        ts = pd.Timestamp(view.server_time, unit="s", tz="UTC").floor("s")
        books = {}
        for symbol in C.PRODUCTS:
            if symbol not in view.products:
                raise DataUnavailable(f"required product {symbol} is unavailable")
            tob = self.external_book(view, symbol)
            if tob[0] is None or tob[1] is None or tob[0] >= tob[1]:
                raise DataUnavailable(f"missing or crossed external book: {symbol}")
            books[symbol] = tob

        options, opt_positions, sources = {}, {}, {}
        push_windows, late_windows, option_src = [], [], {}
        now_s = view.server_time
        if self.settings["enable_options"]:
            # v9: every enabled option symbol (up5, up60 and, if the final test enables it, up15 ...), not a fixed list
            symbols = [s for s in view.options if s.startswith("up")]
            for symbol in symbols:
                info = view.option_info(symbol)
                if info is None or info.strike is None or not math.isfinite(info.strike):
                    continue
                exp = int(info.expiry_min)
                last_trade_settle = info.price_source == "etf_last_trade"
                option_src[exp] = info.price_source
                if info.price_source not in ("etf_last_trade", "etf_mid"):
                    self._set_status(f"{symbol} skipped: unknown price source {info.price_source}")
                    continue
                pos_now = view.position(symbol)
                # v9 LATE PUSH: the settle is the LAST ETF trade printed in the close second itself (checked on 1,400+
                # windows, historical and live: every trade stamped HH:MM:00.xxx counts, and the option book still shows
                # the old window during that second). v8 only pushed while seconds_left > 0, i.e. before the close
                # second, so anyone trading inside the close second overrode us.
                if (last_trade_settle and pos_now and info.window_close <= now_s < info.window_close + 1.0):
                    late_windows.append(dict(exp=exp, wo=pd.Timestamp(info.window_open, unit="s", tz="UTC"),
                                             strike=float(info.strike), pos=pos_now, close=float(info.window_close)))
                # Settle push: windows about to close that we hold a position in (trading stops at
                # min_option_seconds, but the push happens in the last fire_seconds before the close).
                if last_trade_settle and 0 < info.seconds_left <= C.SETTLE_PUSH["fire_seconds"] and pos_now:
                    push_windows.append(dict(exp=exp, wo=pd.Timestamp(info.window_open, unit="s", tz="UTC"),
                                             strike=float(info.strike), pos=view.position(symbol)))
                if info.seconds_left <= self.settings["min_option_seconds"]:
                    continue
                bid, ask, _, _ = self.external_book(view, symbol)
                if bid is None or ask is None or bid >= ask:
                    continue
                wo = pd.Timestamp(info.window_open, unit="s", tz="UTC")
                self.strategy.strikes[(exp, wo)] = float(info.strike)
                options[exp] = (bid, ask, wo)
                opt_positions[(exp, wo)] = view.position(symbol)
                sources[symbol] = info
        active = {(exp, data[2]) for exp, data in options.items()}
        self.strategy.strikes = {k: v for k, v in self.strategy.strikes.items() if k in active}
        seconds_to_end = view.account.day_end - view.server_time
        # There is no SDK trade tape. Do not manufacture trades from lastTradePrice.
        return SimpleNamespace(
            ts=ts, books=books, etf_trades=[], options=options,
            positions={p: view.position(p) for p in C.PRODUCTS},
            opt_positions=opt_positions, pnl=view.pnl, live=True,
            push_windows=push_windows,
            late_windows=late_windows,
            option_src=option_src,
            etf_levels=self.external_levels(view, "etf") if (push_windows or self.settings["enable_options"]) else None,
            last_etf_print=view.last_trade("etf"),
            straw150_count=self.tape.count(int(view.server_time)) if self.strategy.f.get("straw_flow") else None,
            late=seconds_to_end <= self.settings["reset_flatten_start_seconds"],
            very_late=seconds_to_end <= self.settings["reset_flatten_ioc_seconds"],
            option_info=sources,
        )

    def _cap(self, view, symbol, snapshot):
        sdk_cap = view.position_limit(symbol)
        if sdk_cap <= 0:
            raise DataUnavailable(f"missing position limit: {symbol}")
        if symbol.startswith("up"):
            live_cap = max(1, int(C.OPTIONS["max_contracts"] * self.settings["option_inventory_scale"]
                                  * self._opt_scale(symbol)))
        else:
            live_cap = max(1, int(C.QUOTE[symbol]["max_inventory"] * self.settings["inventory_scale"]))
            big = int(self.settings.get("fruit_inventory_cap", {}).get(symbol, 0))
            eq = getattr(getattr(view, "account", None), "equity", 0) or 0
            if big and eq >= self.settings.get("fruit_big_cap_equity", 15000):
                live_cap = big          # v11: bigger fruit caps only once equity leaves margin room for the settle pushes
        if snapshot.late and symbol in C.PRODUCTS:
            live_cap = max(1, int(live_cap * 0.3))
        return min(sdk_cap, live_cap)

    @staticmethod
    def _margin(view, orders):
        """Conservative 100% future notional / $1 per possible option contract.

        Uses separate buy/sell worst cases, so an IOC on each side cannot net out
        before it has filled. Actual exchange margin remains the final authority.
        """
        grouped = defaultdict(lambda: {"buy": 0, "sell": 0, "prices": []})
        for action in orders:
            g = grouped[action["symbol"]]
            g[action["side"]] += action["qty"]
            g["prices"].append(action["price"])
        total = 0.0
        for symbol in set(view.positions) | set(grouped):
            g = grouped[symbol]
            p = view.position(symbol)
            exposure = max(abs(p + g["buy"]), abs(p - g["sell"]))
            if symbol in view.options or symbol.startswith("up"):
                price = 1.0
            else:
                marks = [v for v in [view.best_bid(symbol), view.best_ask(symbol),
                                    view.last_trade(symbol)] + g["prices"]
                         if v is not None and math.isfinite(v) and v > 0]
                if not marks and exposure:
                    raise DataUnavailable(f"cannot value inventory in {symbol}")
                price = max(marks, default=0.0)
            total += exposure * price
        return total

    PAIR_TAGS = ("pair", "pair_stop")

    def _size_order(self, view, snapshot, planned, side_totals, risk_off, permitted_margin,
                    symbol, sign, qty, px, ioc, tag):
        """Largest order (<= qty) for one candidate that fits the live caps, the reduce-only rules and the joint
        worst-case margin together with everything already in `planned`. Returns (qty, order or None); mutates nothing."""
        if symbol not in view.products or sign not in ("+", "-"):
            return 0, None
        if not math.isfinite(px) or px <= 0 or not math.isfinite(qty) or qty <= 0:
            return 0, None
        qty = int(qty)
        if not ioc and symbol in C.PRODUCTS and tag != "wall":
            fq = self.settings.get("fruit_quote_units", {}).get(symbol)
            qty = min(qty, int(fq) if fq else max(1, int(C.QUOTE[symbol]["size"] * self.settings["quote_size_scale"])))
        side = "buy" if sign == "+" else "sell"
        pos = view.position(symbol)
        if tag == "dhedge" and symbol == "etf":
            # the delta hedge has its own (margin-sized) ETF cap, LIVE.delta_hedge_units
            cap = min(view.position_limit(symbol), int(self.settings["delta_hedge_units"]))
            if snapshot.late:
                cap = 0
        elif tag in ("push", "wall", "unwind"):
            # The push is bounded by the exchange position limit and SETTLE_PUSH.max_units (in the strategy),
            # not by the market-making inventory caps or the late-day reduce-only rule.
            cap = view.position_limit(symbol)
        else:
            cap = self._cap(view, symbol, snapshot)
        remaining = (cap - pos if side == "buy" else cap + pos) - side_totals[(symbol, side)]
        # Loss stop and end-of-day orders must not overshoot flat, even across IOC + quotes.
        reduce_only = (risk_off or snapshot.late) and tag not in ("push", "wall", "unwind")
        if reduce_only:
            reducing = (side == "buy" and pos < 0) or (side == "sell" and pos > 0)
            remaining = min(remaining, abs(pos) - side_totals[(symbol, side)]) if reducing else 0
        qty = min(qty, max(0, remaining))
        if qty <= 0:
            return 0, None
        px = view.snap(symbol, px)
        make = Buy if side == "buy" else Sell
        # Binary search the largest integer size inside the joint worst-case budget.
        lo, hi = 0, qty
        while lo < hi:
            mid = (lo + hi + 1) // 2
            trial = make(symbol, px, mid, ioc=ioc)
            if self._margin(view, planned + [trial]) <= permitted_margin + 1e-8:
                lo = mid
            else:
                hi = mid - 1
        if not lo:
            return 0, None
        order = make(symbol, px, lo, ioc=ioc)
        order["_tag"] = tag
        return lo, order

    def plan_orders(self, view, snapshot, actions):
        """Return a complete desired set: IOCs first, then resting quotes.

        Aggregate side quantities are clipped to both live caps and a portfolio
        margin budget, including all resting quotes and possible IOC fills.

        Pair-trade IOCs (tags "pair" / "pair_stop") are two legs that must fill TOGETHER: both legs are sized with
        the same quantity, and if either leg cannot be placed in full at that quantity (cap, reduce-only rule or
        margin) the quantity is reduced until both fit - never one leg alone.
        """
        candidates = []
        option_windows = {}
        # Settle push IOCs go first, in the strategy's order (walk the book, then the 1-unit print).
        for symbol, side, qty, px, tag in actions.ioc:
            if tag == "push":
                candidates.append((symbol, side, qty, px, True, tag))
        for exp, wo, side, qty, px, tag in actions.option_orders:
            symbol = f"up{exp}"
            info = snapshot.option_info.get(symbol)
            if info and pd.Timestamp(info.window_open, unit="s", tz="UTC") == wo:
                candidates.append((symbol, side, qty, px, True, tag))
                option_windows[symbol] = info.window_open
        # Pair legs: grouped by tag, placed as one unit (see below), right after the option orders.
        pair_legs = defaultdict(list)
        for symbol, side, qty, px, tag in actions.ioc:
            if tag in self.PAIR_TAGS:
                pair_legs[tag].append((symbol, side, qty, px))
        for symbol, side, qty, px, tag in actions.ioc:
            if tag not in ("nudge", "push") + self.PAIR_TAGS:
                candidates.append((symbol, side, qty, px, True, tag))
        for symbol, (b, nb, a, na) in actions.quotes.items():
            candidates.extend([(symbol, "+", nb, b, False, f"mm_{symbol}"),
                               (symbol, "-", na, a, False, f"mm_{symbol}")])
        for exp, (wo, b, nb, a, na) in actions.option_quotes.items():
            symbol = f"up{exp}"
            info = snapshot.option_info.get(symbol)
            if info and pd.Timestamp(info.window_open, unit="s", tz="UTC") == wo:
                option_windows[symbol] = info.window_open
                scale = self.settings["option_quote_scale"]
                candidates.extend([(symbol, "+", nb * scale, b, False, f"opt_quote_{exp}"),
                                   (symbol, "-", na * scale, a, False, f"opt_quote_{exp}")])
        baseline = self._margin(view, [])
        budget = max(0.0, view.account.equity * self.settings["margin_fraction"])
        # If already above the buffer, only permit exposure reduction.
        risk_off = baseline > budget or self.strategy.halted
        permitted_margin = max(baseline, budget)
        planned = []
        side_totals = defaultdict(int)

        def sizer(symbol, sign, qty, px, ioc, tag, planned_now, totals):
            return self._size_order(view, snapshot, planned_now, totals, risk_off, permitted_margin,
                                    symbol, sign, qty, px, ioc, tag)

        def commit(order):
            planned.append(order)
            side_totals[(order["symbol"], order["side"])] += order["qty"]

        def pair_unit(tag, legs):
            """Place both legs with one common quantity (or neither): the largest q that fits BOTH legs together."""
            if len(legs) != 2 or legs[0][0] == legs[1][0]:
                return                                   # malformed: never send half a pair

            def both_fit(q):
                trial, totals = [], defaultdict(int, side_totals)
                for symbol, sign, _, px in legs:
                    got, order = sizer(symbol, sign, q, px, True, tag, planned + trial, totals)
                    if got < q:
                        return None
                    trial.append(order)
                    totals[(symbol, order["side"])] += got
                return trial

            lo, hi = 0, min(int(l[2]) for l in legs)     # fitting is monotone in q, so binary search the largest q
            while lo < hi:
                mid = (lo + hi + 1) // 2
                if both_fit(mid):
                    lo = mid
                else:
                    hi = mid - 1
            for order in (both_fit(lo) if lo else None) or []:
                commit(order)

        # push and option orders first, then pair units, then the remaining IOCs and the quotes
        ordered = [c for c in candidates if c[5] == "push" or c[0].startswith("up") and c[4]]
        rest = [c for c in candidates if c not in ordered]
        for symbol, sign, qty, px, ioc, tag in ordered:
            got, order = sizer(symbol, sign, qty, px, ioc, tag, planned, side_totals)
            if order:
                commit(order)
        for tag in self.PAIR_TAGS:
            if tag in pair_legs:
                pair_unit(tag, pair_legs[tag])
        for symbol, sign, qty, px, ioc, tag in rest:
            got, order = sizer(symbol, sign, qty, px, ioc, tag, planned, side_totals)
            if order:
                commit(order)
        return planned, option_windows

    # ------------------------------------------------------------------------------------------------
    # v9 LATE PUSH
    # ------------------------------------------------------------------------------------------------
    def _late_push(self, view, snapshot):
        """Close second of window(s) we hold: print the settle on our side as late in the second as is safe.

        Orders, in one batch: cancel our resting ETF quotes (a stranger hitting them would print on the wrong side),
        A = walk every ETF level on the wrong side of the strike (+ a buffer for levels that appear after we looked),
        B = 1 unit at the first level on our side (its print is that level), then a small resting 'wall' on our side of
        the strike so a house trade after us still prints where we want. Sent at close + LIVE.late_push_at_s."""
        sp = C.SETTLE_PUSH
        wins = snapshot.late_windows
        keys = [(w["exp"], w["wo"]) for w in wins]
        if any(k in self._late_done for k in keys):
            return
        for k in keys:
            self._late_done.add(k)
        levels = snapshot.etf_levels or self.external_levels(view, "etf")
        bids, asks = levels
        if not bids or not asks:
            return
        mid = (bids[0][0] + asks[0][0]) / 2
        used = max(self.strategy.pushed.get(k, 0) for k in keys)
        budget = sp["max_units"] + sp.get("late_extra_units", 0) - used
        if budget <= 1:
            self._push_log.append(dict(keys=keys, status="no budget"))
            return
        plan = plan_push([(w["strike"], w["pos"]) for w in wins], bids, asks, mid, budget)
        deep = False
        if plan is None:
            # v10 deep push, stage 2: we walked the ladder in the second before the close (stage 1). Finish with a
            # full-budget walk priced at the strike + the 1-unit print, whatever the (refilled) book looks like now.
            st = None
            if self.strategy.f.get("deep_push") and any(k in self.strategy.deep_keys for k in keys):
                st = deep_stage1([(w["strike"], w["pos"]) for w in wins], bids, asks, mid, budget,
                                 2 * sp.get("deep_reach", 0.25))
            if st is None:
                self._push_log.append(dict(keys=keys, status="unreachable"))
                return
            side, lo, hi, units, cost, stake = st
            units = budget - 1
            orders = [(side, units, None), (side, 1, lo if side == "+" else hi)]
            deep = True
        else:
            orders, units, cost, stake, (lo, hi) = plan
            if 2 * cost > sp["cost_frac"] * stake:
                self._push_log.append(dict(keys=keys, status="too costly"))
                return
        side = orders[-1][0]
        target = orders[-1][2]
        tick = C.TICK
        # v9.2 FIX. v9/v9.1 sent A with its limit at the last wrong-side level WE SAW, and B / the wall could then fill
        # against asks that appeared below the strike after we looked (the house refills the levels the early push
        # took). Our last order's print then landed on the WRONG side: Oct 10 13:10-16:05, 5 windows (500 UP each) that
        # the early push had already won were lost by our own late print (14:25, 14:55, 15:30, 15:50, 16:05), ~$500 each.
        # Now: A's limit is the last tick on the wrong side of the target range (it clears every wrong-side level there is
        # at arrival, up to what we saw + a buffer), B's limit is generous (any print inside the range wins, 1 unit), and
        # the walls go FIRST in the batch so a wall that is marketable against a stale level is overridden by A and B.
        # v10: A = max(late_min_walk, seen + buffer) whenever the wrong side is bounded (it only fills wrong-side levels
        # that are there on arrival); deep stage 2 walks the whole remaining budget. robust_push_orders handles every
        # range shape (v9.2 raised OverflowError on a DOWN window already in the money and sent nothing).
        a_seen = 0 if deep else (orders[0][1] if len(orders) == 2 else 0)
        if deep:
            a_qty = budget - 1
        else:
            a_qty = min(max(int(self.settings.get("late_min_walk", 60)),
                            a_seen + int(self.settings.get("late_push_buffer", 30))), budget - 1)
        reach = max(self.settings.get("late_push_b_reach", 0.25), self.settings.get("late_push_tolerance", 0.03))
        tol = self.settings.get("late_push_tolerance", 0.03)
        if target is not None and math.isfinite(target):          # B must at least reach the level the plan prints at
            if side == "+" and math.isfinite(lo) and not math.isfinite(hi):
                reach = max(reach, target - lo + tol)
            if side == "-" and math.isfinite(hi) and not math.isfinite(lo):
                reach = max(reach, hi - target + tol)
        cands = [("etf", sd, q, px, ioc, role) for sd, q, px, ioc, role in
                 robust_push_orders(side, lo, hi, a_qty, reach, int(self.settings.get("late_wall_units", 10)))]
        if not cands:
            self._push_log.append(dict(keys=keys, status="empty range"))
            return
        # size B (1 unit, the print that matters) before A, then the walls: a margin-clipped A must never starve B
        cands.sort(key=lambda c: {"push_b": 0, "push_a": 1}.get(c[5], 2))
        a_px = next((c[3] for c in cands if c[5] == "push_a"), float("nan"))
        a_qty = next((c[2] for c in cands if c[5] == "push_a"), 0)
        b_px = next((c[3] for c in cands if c[5] == "push_b"), float("nan"))
        # size against margin / position limits exactly like other orders
        baseline = self._margin(view, [])
        budget_margin = max(0.0, view.account.equity * self.settings["margin_fraction"])
        permitted = max(baseline, budget_margin)
        planned, totals, got_by_tag = [], defaultdict(int), defaultdict(int)
        for symbol, sign, qty, px, ioc, tag in cands:
            got, order = self._size_order(view, snapshot, planned, totals, False, permitted,
                                          symbol, sign, qty, px, ioc, "push" if tag.startswith("push") else tag)
            if order:
                order["_role"] = tag
                planned.append(order)
                totals[(symbol, order["side"])] += got
                got_by_tag[tag] += got
        if got_by_tag["push_b"] < 1 or got_by_tag["push_a"] < a_seen:
            # without B, or with A unable to clear what we saw, our own print could land on the wrong side: send nothing
            self._push_log.append(dict(keys=keys, status="no margin"))
            return
        # wire order: walls first, then A, then B (B's print is the last of ours in the close second)
        rank = {"wall": 0, "push_a": 1, "push_b": 2}
        planned.sort(key=lambda o: rank.get(o.get("_role"), 1))
        wire = [CancelAll("etf")] + [{k: v for k, v in o.items() if not k.startswith("_")} for o in planned]
        # Wait until late in the close second. Aim for our orders to ARRIVE at close + late_push_at_s: subtract half of a
        # recent round trip. Use the wall clock if it agrees with the exchange clock (normally within a few hundred ms),
        # else assume the tick's state is fresh.
        close = min(w["close"] for w in wins)
        recent = list(getattr(self, "_lat_recent", []))
        half_rtt = min(0.4, max(0.02, (sorted(recent)[len(recent) // 2] / 2) if recent else 0.08))
        target = close + self.settings.get("late_push_at_s", 0.70) - half_rtt
        now = time.time()
        lag = now - view.server_time
        if abs(lag) < 1.0:
            delay = target - now
        else:
            delay = target - (view.server_time + (now - getattr(self, "_tick_wall", now)))
        delay = min(max(delay, 0.0), 0.9)
        # v10.1: in a sped-up simulation the exchange clock runs faster than the wall clock, so the same exchange-time
        # target is reached sooner (sleeping 0.8 wall seconds at 24x would land ~19 exchange seconds late, in the next window).
        speed = self._clock_speed()
        if speed > 1.2:
            delay = delay / speed
        if delay > 0:
            time.sleep(delay)
        # v14.1: the new 5m window is already trading at close + ~0.8 s. Ride the same batch with a blind open buy for it
        # (IOC, limit first_limit) so it lands in the window's first match (~1.06 s) like the fastest UP buyers.
        open_first = None
        if (any(w["exp"] == 5 for w in wins) and not snapshot.late and self.settings.get("open_first_buy", True)
                and hasattr(self.strategy, "open_first_order")):
            open_first = self.strategy.open_first_order(5)
        res = self._timed_batch(wire)
        if open_first:
            # SEPARATE request right after the push batch (batches are atomic: a rejected option order must never take the
            # push down with it). Requests are spaced 10 ms, so it still lands well before the ~1.06 s match.
            q, lim = open_first
            try:
                r2 = self._timed_batch([Buy("up5", lim, q, ioc=True)])
            except Exception as e:      # never let the open buy break the push path
                r2 = None
                self.warn(f"open first buy failed: {e}")
            self.log(f"open first buy up5 {q} lim {lim:.2f} after late push (ok={bool(r2)})")
        for k in keys:
            self.strategy.pushed[k] = self.strategy.pushed.get(k, 0) + units
        self._push_log.append(dict(keys=keys, status="sent", side=side, target=orders[-1][2], lo=lo, hi=hi, units=units,
                                   strike=[w["strike"] for w in wins], ok=bool(res), delay=round(delay, 3), deep=deep))
        self._force_requote = True       # the wall must not outlive the close second: refresh next tick even in pipe mode
        if self.settings.get("log_late_push", True):
            w0 = wins[0]
            self.log(f"late push {'+'.join(str(w['exp']) + 'm' for w in wins)} close {pd.Timestamp(close, unit='s'):%H:%M}: "
                     f"pos {[w['pos'] for w in wins]} strike {[round(w['strike'], 3) for w in wins]} -> "
                     f"{'DEEP ' if deep else ''}{'buy' if side == '+' else 'sell'} A {a_qty}u lim {a_px:.2f} (saw {a_seen}), "
                     f"B 1u lim {b_px:.2f}, plan print {orders[-1][2]:.2f} (sent +{delay:.2f}s wait, ok={bool(res)})")

    def _feed_closes(self, view):
        """v14.2: pass settled windows (state 'optionWindows': expiryMin, windowOpen, upWon) to the strategy, oldest first."""
        rec = getattr(self.strategy, "record_close", None)
        if rec is None:
            return
        try:
            wl = view._state.get("optionWindows") or []
            rows = []
            for w in wl if isinstance(wl, list) else []:
                if w.get("upWon") is None or w.get("expiryMin") is None or w.get("windowOpen") is None:
                    continue
                wo = int(w["windowOpen"]); wo = wo // 1000 if wo > 10**11 else wo
                rows.append((wo, int(w["expiryMin"]), bool(w["upWon"])))
            for wo, exp, up in sorted(rows):
                rec(exp, wo, up)
        except Exception:
            pass

    def _note_settles(self, view):
        """Match settled windows (state 'optionWindows', if the exchange sends it) to our late pushes, for the log."""
        try:
            wl = view._state.get("optionWindows") or []
            for w in wl if isinstance(wl, list) else []:
                key = (int(w.get("expiryMin")), pd.Timestamp(int(w.get("windowOpen")) // (1000 if int(w.get("windowOpen")) > 10**11 else 1), unit="s", tz="UTC"))
                for rec in self._push_log:
                    if rec.get("status") == "sent" and key in rec["keys"] and "settle" not in rec:
                        rec["settle"] = float(w.get("settle"))
                        rec["won"] = (rec["lo"] <= rec["settle"] < rec["hi"])
        except Exception:
            pass
        if len(self._push_log) > 400:
            self._push_log = self._push_log[-200:]

    def _push_stats(self):
        sent = [r for r in self._push_log if r.get("status") == "sent"]
        settled = [r for r in sent if "won" in r]
        other = defaultdict(int)
        for r in self._push_log:
            if r.get("status") != "sent":
                other[r["status"]] += 1
        won = sum(1 for r in settled if r["won"])
        return f"sent {len(sent)}, settled {len(settled)}, won {won}; skipped {dict(other)}"

    @staticmethod
    def _signature(orders):
        return sorted((o.side, round(o.price, 8), o.remaining) for o in orders if o.remaining > 0)

    def execute_actions(self, view, snapshot, actions, version, in_worker=False):
        planned, windows = self.plan_orders(view, snapshot, actions)
        # Recheck the latest state immediately before submitting option orders.
        # v8: never wait long for the lock, and never send if this tick has already used most of its 5 s budget.
        if time.monotonic() - getattr(self, "_tick_t0", time.monotonic()) > self.settings.get("send_budget_s", 3.0):
            # (v8.1: in the background worker this means the plan is too old to send)
            raise SkipTick("tick over budget before sending; skipping this second")
        if not self._lock(self.settings.get("lock_timeout_s", 0.5)):
            raise SkipTick("exchange state busy; skipping this second")
        try:
            current = object.__new__(Exchange)
            current._state = self._state
            current._state_updated_at = self._state_updated_at
            current_day = current.account.day or str(current.account.day_end)
            if current_day != self.day:
                raise DataUnavailable("day rolled during tick")
            for symbol, expected in windows.items():
                info = current.option_info(symbol)
                if not info or info.window_open != expected or info.seconds_left <= self.settings["min_option_seconds"]:
                    raise DataUnavailable("option window changed during tick")
        finally:
            self._state_lock.release()
        desired = defaultdict(list)
        iocs = []
        for order in planned:
            (iocs if order["orderType"] == "ioc" else desired[order["symbol"]]).append(order)
        # Synchronize against actual remaining orders rather than a cached desired quote.
        touched = set(desired) | {o.symbol for o in view.open_orders()} | {o["symbol"] for o in iocs}
        changes = []
        new_quotes = []
        ioc_symbols = {o["symbol"] for o in iocs}
        for symbol in sorted(touched):
            target = sorted((o["side"], round(o["price"], 8), o["qty"]) for o in desired[symbol])
            if symbol not in ioc_symbols and target == self._signature(view.open_orders(symbol)):
                continue
            if view.open_orders(symbol):
                changes.append(CancelAll(symbol))
            new_quotes.extend(desired[symbol])
        batch = changes + iocs + new_quotes
        self.last_actions = batch
        if not batch:
            return
        # v9: in pipe mode every call is a chance to be killed by a stalled exchange. Resting-quote refreshes alone are sent
        # at most every LIVE.requote_s seconds; anything with an IOC (option takes, pushes, pair legs, unwinds) goes now.
        if (BACKTEST or self.settings.get("throttle_http", False)) and not iocs and not getattr(self, "_force_requote", False):
            # v10.1: the throttle is measured in EXCHANGE seconds (a sped-up simulation would otherwise refresh quotes
            # only every ~2 x speed exchange seconds and leave them stale)
            if (time.monotonic() - getattr(self, "_last_send", -1e9)) * self._clock_speed() < self.settings.get("requote_s", 2.0):
                self._throttled = getattr(self, "_throttled", 0) + 1
                return
        # Internal tags never go to the exchange API.
        wire = [{k: v for k, v in action.items() if not k.startswith("_")} for action in batch]
        # On a timeout, wait for a fresh state instead of resubmitting an unknown order result.
        self._pending_version = version
        self._pending_at = time.monotonic()
        self._last_send = time.monotonic()
        self._force_requote = False
        results = self._timed_batch(wire) if in_worker else self._batch_deadline(wire, 2.5)
        if results is None:
            # still in flight (or a previous batch is): keep _pending_version so we wait for fresh exchange state
            self.last_results = []
            return
        self.last_results = results
        with self._state_lock:
            self._pending_version = self._state_version
        if len(self.last_results) != len(wire):
            self.warn("batch response incomplete; reconciling against next exchange state")
        self._write_acknowledgements(batch, self.last_results, snapshot.ts)
        for result in self.last_results:
            if isinstance(result, dict) and (result.get("error") or result.get("status") == "rejected"):
                self.warn(f"action rejected: {result.get('error') or result.get('status')}")

    def _append_file(self, name, text):
        directory = self.settings["log_directory"]
        if not directory:
            return
        try:
            os.makedirs(directory, exist_ok=True)
            path = os.path.join(directory, name)
            if os.path.exists(path) and os.path.getsize(path) + len(text.encode()) > self.settings["log_max_bytes"]:
                os.replace(path, path + ".previous")
            with open(path, "a", encoding="utf-8") as f:
                f.write(text)
        except OSError as exc:
            if self._last_log_warning != str(exc):
                self.warn(f"optional file logging unavailable: {exc}")
                self._last_log_warning = str(exc)

    def _write_acknowledgements(self, batch, results, ts):
        if not self.settings["log_directory"]:
            return
        self._append_file("order_acknowledgements.jsonl", json.dumps({
            "ts": str(ts), "actions": batch, "results": results,
            "note": "Acknowledged fills only; not a complete passive-fill ledger",
        }, default=str) + "\n")

    def _log_market(self, snapshot):
        if not self.settings["log_directory"]:
            return
        import io
        output = io.StringIO()
        writer = csv.writer(output)
        # No header, so either rotated file can be read independently by live_check.py.
        for symbol, (bid, ask, nb, na) in snapshot.books.items():
            writer.writerow([str(snapshot.ts), symbol, bid, ask, nb, na])
        self._append_file("live_tob.csv", output.getvalue())

    def _clock_speed(self):
        """v10.1: exchange seconds per wall second, smoothed over ticks (1.0 live; > 1 when a simulation runs sped up)."""
        return getattr(self, "_speed", 1.0)

    def _track_speed(self):
        try:
            srv = float(self.server_time)
        except Exception:
            return
        wall = time.monotonic()
        prev = getattr(self, "_speed_prev", None)
        self._speed_prev = (srv, wall)
        if prev is None:
            return
        ds, dw = srv - prev[0], wall - prev[1]
        if ds <= 0 or ds > 30 or dw <= 1e-3:
            return                                     # day change / gap / frozen clock: ignore this sample
        r = min(1000.0, max(0.25, ds / dw))
        self._speed = 0.8 * getattr(self, "_speed", 1.0) + 0.2 * r

    def on_tick(self):
        self._tick_t0 = time.monotonic()
        self._tick_wall = time.time()
        self._track_speed()
        if not getattr(self, "_sdk_logged", False):
            self._sdk_logged = True
            self._log_sdk_surface()
            try:
                self.log(f"v16 mode={'pipe' if BACKTEST else 'http'}; exchange config: {dict(self._state.get('config') or {})}")
            except Exception:
                pass
            if self.settings.get("straw_flow", True) and C.FEATURES["straw_flow"]:
                self.tape.start()
        if self._batch_busy():
            # v8: the last order batch is still running (slow exchange). Touching the shared state now can block past the
            # platform's 5 s limit, so sit this second out; the next tick reconciles against fresh state.
            self._busy_ticks = getattr(self, "_busy_ticks", 0) + 1
            if self._busy_ticks % 10 == 1:
                self.warn(f"previous order batch still running; skipped {self._busy_ticks} tick(s)")
            return
        self._busy_ticks = 0
        captured = self._capture()
        if captured is None:
            self.warn("exchange state lock busy; skipping this second")
            return
        view, version, updated = captured
        if not BACKTEST and (not updated or time.time() - updated > self.settings["stale_seconds"]):
            self._pull_quotes("stale market data: cancelling quotes")
            return
        if self._pending_version is not None:
            if version <= self._pending_version:
                if time.monotonic() - self._pending_at > self.settings["stale_seconds"]:
                    self._pull_quotes("waiting for post-order state: cancelling quotes")
                return
            self._pending_version = None
        if version == self.last_version:
            return
        self.last_version = version
        try:
            self._reset_if_needed(view)
            snapshot = self.build_snapshot(view)
            second = (self.day, int(snapshot.ts.timestamp()))
            if second == self.last_second:
                return
            if self._has_gap or (self.last_second and second[0] == self.last_second[0]
                                 and second[1] - self.last_second[1] > 2):
                # The Kalman model is fitted at 1 Hz; don't interpret a long gap as one second.
                self.strategy.fv = FairValue()
            self._has_gap = False
            self.last_second = second
            self.ticks += 1
            t0 = time.monotonic()
            self._feed_closes(view)          # v14.2: settled outcomes -> the open-buy off-switch (before the strategy runs)
            actions = self.strategy.on_second(snapshot)
            t1 = time.monotonic()
            self._note_settles(view)
            if snapshot.late_windows and self.settings.get("late_push", True) and self.strategy.f.get("settle_push"):
                # v9: this is the close second of a window we hold. Skip normal orders this second (one call per tick)
                # and send the late push near the END of the close second, so our print is the last one that counts.
                self._late_push(view, snapshot)
                self.status = None
                return
            if (self._cooling_down() and not getattr(self, "_force_requote", False)
                    and not (actions.option_orders or any(x[4] in ("push", "unwind") for x in actions.ioc))):
                # v9: the exchange was slow a moment ago; non-critical requotes wait (resting quotes stay)
                self._skipped_cooldown = getattr(self, "_skipped_cooldown", 0) + 1
                return
            if t1 - t0 > 3.0:
                # The platform kills a bot whose on_tick runs past 5 s (v5.2 was restarted once for this).
                # Skip sending this second rather than risk the restart; the next tick starts fresh.
                self.warn(f"slow tick: strategy took {t1 - t0:.2f}s; skipping orders this second")
                return
            if self.settings.get("async_orders", True) and not BACKTEST:
                # v8.1: plan AND send in the background worker; on_tick returns right away, so it can never pass the
                # platform's 5 s limit however slow the exchange is (v8 still crashed with 'orders 5.78s').
                self._submit_orders(view, snapshot, actions, version)
            else:
                self.execute_actions(view, snapshot, actions, version)
            t2 = time.monotonic()
            if t2 - t0 > 2.0:
                self.warn(f"slow tick: strategy {t1 - t0:.2f}s, orders {t2 - t1:.2f}s")
            self._log_market(snapshot)
            if self.ticks == 1 or self.ticks % self.settings["log_every_ticks"] == 0:
                a = view.account
                self.log(f"P&L {view.pnl:+.2f}; equity {a.equity:.2f}; margin {a.margin_used:.2f}; "
                         f"positions {view.positions}; loss_stop={self.strategy.halted}; "
                         f"rev2h targets {self._rev_text()}; jumps {getattr(self.strategy, 'jump_stats', {})}; "
                         f"short swap {getattr(self.strategy, 'short_stats', {})}")
                st = getattr(self, "_lat", None)
                if st and st["n"]:
                    self.log(f"calls {st['n']} avg {st['sum']/st['n']:.2f}s max {st['max']:.2f}s slow/failed {st['slow']}/{st['fails']}; "
                             f"throttled {getattr(self, '_throttled', 0)}; cooldown-skips {getattr(self, '_skipped_cooldown', 0)}; "
                             f"late pushes {self._push_stats()}")
            self.status = None
        except SkipTick as exc:
            self._set_status(str(exc))
        except Exception as exc:
            self._pull_quotes(f"{type(exc).__name__}: {exc}; cancelling quotes")
