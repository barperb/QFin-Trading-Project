# QFin live upload package

## v15 (Oct 15, from v14.2) — regime gate on ALL option buying
- **Bug from Oct 15 live:** the regime flipped hard DOWN (UP won 11/92 5m windows, ties 38%->0%). v14.2's off-switch only
  gated the OPEN buy; the model takes (-37c/contract), resting bids (-47c) and 60m buys (-50c) kept loading UP because the
  model assumes it can push the settle up. Fruit/ETF still made +$4.5k (Oct 14) / +$0.6k (Oct 15) through it.
- **Fix:** `OPTIONS.regime_gate` stops BUYING UP on every path (open buy, model take, resting bid) when UP has won < 50% of
  the last 12 closes (needs >=8 closes first, else open). Reducing a long and the settle push are untouched, so we flatten
  into the close and earn only fruit/ETF while UP is losing. Fed from the exchange's settled windows (record_close).
- Adaptive: buys UP when UP is winning, goes flat on options when it is losing. Log starts `v15 mode=`.
- Tests: 127 pass. Pipe harness clean.

## v14.2 (Oct 14, from v14.1) — off-switch actually works now
- **Bug found from live fills (Oct 14):** the open-buy off-switch was never fed live. It learned past outcomes from
  `self.last_etf_trade`, but the live adapter never has an ETF trade tape (`etf_trades=[]` always), so `track_closes`
  never fired and `up_hist` stayed empty — the gate was permanently open. On a choppy day v14/v14.1 would have kept
  buying 500 UP a window straight into losses. (Today it didn't bite because UP kept winning 90%+.)
- **Fix:** the adapter now reads settled windows from the exchange state (`optionWindows`: expiryMin/windowOpen/upWon)
  each tick and feeds them to the strategy (`record_close`, deduped per window) before it trades. The off-switch now
  shuts after `gate_n` recent closes go below `gate_rate` UP, exactly as the replay assumed.
- No change to the trading rules, sizing, cap or gate thresholds. Log starts `v14.2 mode=`.
- Tests: 127 pass (1 new, 1 updated). Pipe harness clean.

## v14.1 (Oct 13, from v14) — open-buy speed
- Live 14:05-14:20 UTC: the exchange matches option orders in one batch per second (~x.06 s). The Fruity Boys and qfingroup3
  sweep the house's whole UP ladder (~50 at the ask, 100 at +2c, 200 at +5c) in the window's FIRST batch (1.06 s) at 6-14c.
  v14 got in at 2.07 s and took 50 a second, paying ~16-20c (about $25-30 a window more).
- **Blind first buy**: right after our late push (sent at close + ~0.8 s, when the new 5m window is already trading) the
  adapter sends a separate IOC: buy 350 up5 at <= 20c (`OPTIONS.open_up_buy.first_qty/first_limit`). It lands in the
  1.06 s batch and fills only what the house offers at 20c or less. Separate request: the push batch is atomic and must
  never fail because of it. Skipped if the off-switch is closed, on loss stop, or near the day end. Log line:
  `open first buy up5 350 lim 0.20 after late push`.
- **Sweep**: every later open buy takes the ladder in one order (limit ask + 5c, never above 55c, up to 350) instead of 50/s.
- **Open-buy price cap 55c -> 70c, off-switch 55% -> 60%.** Replay Oct 6-12 (per full day): v14 settings avg +$7.2k, worst
  -$4.5k; v14.1 avg +$9.6k, worst -$2.3k (better on both). Caps above 75c add nothing. A 60m open buy loses at every cap: not added.
- Log starts `v14.1 mode=`. Tests: 126 pass (2 new, 3 updated). Pipe harness clean.

## v14 (Oct 13, from v13)
- **Open UP buy** (`FEATURES.open_up_buy`, `OPTIONS.open_up_buy`): in the first 60 s of every 5m window, buy UP at the ask
  while it is 55c or less, up to 500 contracts, and hold to the close (the existing settle push defends it). Trims are off
  while this is on, so we don't sell back what we just bought.
- **Off-switch**: the bot records whether UP won each close (last ETF trade vs strike, ties = UP). If UP won under 55% of
  the last 12 closes, it stops open-buying until that recovers. With fewer than 6 closes seen (start-up) it is on.
- Why: live Oct 12/13 the house sold 5m UP in the first minute at 48c/37c and UP won 81%/82% (+33c/+45c a contract). The
  Fruity Boys buy ~500 at every open, hold, and push the close up (+$9.2k in 47 recorded windows on Oct 13).
- Replay of our live 5m books Oct 6-12 (50 a second at the touch, +1c per 50 bought, real outcomes), 500/55c/60 s with the
  gate: Oct 6 -$0.1k, Oct 7 -$4.5k, Oct 8 +$4.0k, Oct 9 +$3.5k, Oct 10 +$3.7k, Oct 11 +$20.0k, Oct 12 +$5.7k (77 windows only).
  Without the gate Oct 6-7 (UP won 45-49%) lost $4.4-6.0k a day. Oct 8-10 understate it (those files have gaps in the first minute).
- Log starts `v14 mode=`; open buys show as `opt_open_5` orders.
- Tests: 124 pass (5 new). Pipe harness clean.

## v13 (Oct 12, from v12.1)
- **ETF market making**: 8 units a side (was 2) and an ETF quote cap of 30 (was 12) once equity >= $15k. Spud and T4 make
  9-11c a unit making the ETF on ~1k units/h (named trades, Oct 12); our ETF maker fills mark out +1.4..3.5c a unit.
- **Momentum pull OFF** again (fruit P&L fell from ~$169/h on v11 to ~$100/h on v12.1).
- **Apples min edge back to 1.5c** (apples made -$4 on 11k units at 1c on Oct 12).
- Not added: T4-style 5m cycling (buy dips / sell rips inside the window). Every price-rule variant lost money in the Oct
  8-12 replay (-$3k to -$40k over 5 days), so T4's edge there is timing we can't see, or today's 75% UP regime.
- Tests: 119 pass. Pipe harness clean.

## v12.1 (Oct 12, from v12)
- **Momentum pull on fruit quotes** (`FEATURES.momentum_pull`, config `MOM_PULL`): apples/bananas/oranges/strawberries post
  no bid when the mid rose 4c+ in the last 60 s, and no offer when it fell 4c+. Never blocks a side that cuts a position
  beyond 90 units. Live Oct 11-12 (680k maker units): fills that followed the 60 s move lost 0.6-1.7c a unit at 60 s,
  fills against it made 1.4-2.2c. Skipping the losers is worth ~$1.2k-2.7k/day (fill-level estimate; positive both days,
  in all four fruits). Watermelon is positive in every bucket and is left alone.
- Tests: 119 pass (3 new).

## v12 (Oct 12, from v11)
- **5m resting bid: 15c under value, 25 contracts** (`OPTIONS.quote_min_edge_by_exp={5: 0.15}`, `quote_size_by_exp={5: 50}` x
  option_quote_scale 0.5). Was 3c and 10 contracts. Replay of live books + the public option tape vs v11's setting:
  Oct 8 +$1.6k, Oct 9 +$1.8k, Oct 10 +$2.2k, Oct 11 +$3.1k, Oct 12 (6.5 h) +$0.6k. Takes, trims, pushes, fruit unchanged.
- Researched and rejected (Oct 8-12 replays): a learned win model (the hand model undervalues UP on Oct 11-12 by 15-25 pts,
  but trading on corrected values loses $3.5k/day: it buys earlier and dearer); dumping hopeless UP late (-$1k to -$11k);
  shorting (every setting negative on Oct 11-12); looser trims (+$300/day, noise).
- Tests: 116 pass (2 new). Pipe harness clean.

## v11 (Oct 11, from v10.4)
- **Shorting off** (`FEATURES.option_short_swap=False`). Live 07:38-12:58 UTC the short book made +$77 on 9.5k contracts, and
  shorting at the window open replaced the cheap long: shorted windows averaged -$30 (UP) / +$111 (DOWN) vs +$231 / -$100
  unshorted, about -$1k per 5 h. Trimming longs into rich bids (`trim_long`, 2c) stays ON.
- **Bigger fruit quotes**: 16 units a side for apples/bananas/strawberries and 12 for oranges (was 8; `LIVE.fruit_quote_units`).
  Watermelon and ETF unchanged. 86% of public fruit taker units arrive in prints over 8 units, and our maker fills keep
  about +0.4 to +0.9c a unit 60 s later in every edge bucket (Oct 10 tape).
- **Tighter fruit edge**: min edge 1.5c -> 1.0c for apples/bananas/strawberries (fills at 1c edge marked out as well as 2c).
- **Fruit caps 75 -> 120** (`LIVE.fruit_inventory_cap`), only while equity >= $15k (`fruit_big_cap_equity`), so the start of a
  day ($10k) keeps margin for the settle pushes.
- **Pair trade 25 -> 60 units a leg** (`LIVE.pair_scale=0.60`). Live oranges-apples deviations beyond 5c reverted 2.3-4.9c in
  5 min on Oct 9-11.
- Tests: 114 pass (3 new v11 tests). Pipe-mode harness runs clean.
- Watch live: fruit P&L per hour (was ~$150/h), inventory swings, and that late pushes still win (margin).

## v10.4 (Oct 11, 15:40 Perth): short the 5m UP mid-window when it's rich, always covered before the close

**Upload:** `qfin_bot_live_v10_4.zip`. v10.3 plus one feature (`FEATURES.option_short_swap`). Log starts `v10.4 mode=pipe`;
the P&L line ends `short swap {'shorts': n, 'covers': n}`; orders show as `opt_short_5` / `opt_cover_5`.

`OPTIONS.short_swap = {5: dict(edge=0.15, cap=500, cover_s=60)}`: sell the 5m UP when the bid is 15c+ above our value of
a short, down to -500, only while more than 65 s are left; with 60 s or less left, buy every short back (IOC at the ask
+2c, 50 a second), so we're never short into the close fight. Replay Oct 8 / 9 / 10 / 11 vs holding: +$11.1k / +$2.2k /
+$0.5k / -$2.7k (tools/swap_sim.py). The latest day was negative: watch the short swap counters and the P&L; to switch it
off, set `option_short_swap=False` in config.py FEATURES.

111 tests pass (3 new).

---


## v10.3 (Oct 11, 15:30 Perth): sell long options back when they're rich

**Upload:** `qfin_bot_live_v10_3.zip`. v10.2 plus one change. Log starts `v10.3 mode=pipe`; trims show as `opt_trim_5` orders.

Until now the bot only ever bought options and held to the close (89 windows on Oct 11, zero option sells), while
Spudtrading and T4 sell back mid-window (Spudtrading dumped 500 up5 in one minute at 07:23 UTC).

`OPTIONS.trim_long = {5: dict(edge=0.02, min_left=60)}`: when we're long the 5m UP, the bid is more than 2c above our
own value, and more than 60 s are left, sell up to 50 at the bid (never past flat, never short). That frees cap for
cheaper buys later. Live option-book replay with real outcomes (tools/swap_sim.py): +$4.7k / +$1.0k / +$0.3k / +$0.3k on
Oct 8 / 9 / 10 / 11 (to 07:20 UTC) versus holding, positive every day. Swapping to SHORT mid-window and covering 60 s
before the close made more in total (+$11k) but all of it on Oct 8 and it lost $2.7k on Oct 11, so the bot never opens a short.

108 tests pass (2 new); pipe harness unchanged.

---


## v10.2 (Oct 11, afternoon): bigger close-second wall, bigger fruit quotes

**Upload:** `qfin_bot_live_v10_2.zip`. Same code as v10.1; two live settings. Log starts `v10.2 mode=pipe`.

| setting | v10.1 | v10.2 | why |
|---|---|---|---|
| `LIVE.late_wall_units` | 10 | **40** | The resting bid one tick above the strike after our close-second push. A seller arriving after us hits it instead of printing the settle below the strike (Oct 10: 11 of 93 windows had a trade after our push, 2 flipped). Costs nothing when nobody comes. |
| `LIVE.quote_size_scale` | 0.25 | **0.40** | Fruit quotes 5 -> 8 units a side (ETF 1 -> 2). Our maker fills keep +0.7-0.9c a unit 60 s later (Oct 9-10, ~290k units a day, ETF +2-4c), so more size at the touch should add steady P&L. Inventory caps unchanged. |

**Tested and left alone:**
- 60m option cap: replay Oct 7-10 earns ~$31 a window with ~$188 sd at 500 contracts, linear in the cap. On full
  days that adds ~$750 of mean and only ~$85 of daily sd next to the rest of the book, so cutting it would lower
  mean - sd. (1-hour days still scale it to 0.4 via SHORT_DAY.)
- Strawberry 2h reversion cap 60 -> 150: +$120/day on live Oct 6-10 but 2 of 5 days negative; not worth the risk.
- Strawberry run trigger: 3 up-jumps of 7c in 120 s is still the best (+10.6c / +16.7c, ~7/day incl. Oct 11);
  looser triggers (5c, or 2 jumps) lose money.

Both changes are live-only, so the historical backtest is unchanged ($60,173/day, score $57,285). 106 tests pass.

---


## v10.1 (Oct 11, 09:30 Perth): two settings from v10's first live hour

**Upload:** `qfin_bot_live_v10_1.zip`. Same code as v10; two config changes. Log starts `v10.1 mode=pipe`.

v10's first hour live (00:15-01:10 UTC, `tools/close_second.py`): late push sent in 8 windows, won 6; no window was lost
to our own print after the early push had won (v9.1: 20 of those on Oct 10).

| setting | v10 | v10.1 | why |
|---|---|---|---|
| `FEATURES.deep_push` | on | **off** | 00:45: it walked 105 ETF units up to 55.04 (strike 55.09); the house re-quoted 17 units at 55.03 within 0.7 s, margin then left no room for the close-second walk, and the window was lost anyway. The market maker re-quotes at its own fair value, so walking the ladder early doesn't move it. |
| `LIVE.late_push_at_s` | 0.70 | **0.80** | Other teams trade after our late push more often now: Oct 10, 11 of 93 windows (2 flipped); Oct 11 first hour, 3 of 8 (1 flipped). Our fills land ~0.05 s after sending, so 0.80 still leaves ~0.15 s inside the close second. |

**Sped-up simulations (the final 6-month run).** The bot used wall-clock time in two places that only work at real
speed: the late push slept ~0.7 wall seconds before sending (at 24x that lands ~17 exchange seconds late, in the next
window), and resting quotes were refreshed at most every 2 wall seconds (~48 exchange seconds at 24x). v10.1 measures the
exchange-clock speed from tick to tick and scales both, so it behaves the same in exchange time at any speed. Live
(speed 1.0) nothing changes.

**Entry prices checked, no change.** A replay of the live 5m option books with real outcomes (Oct 8-10, cap 500;
`tools/entry_sweep.py`) puts v10's rule (20c edge while more than 60 s are left, 10c after) at $59.2k over 3 days, against
$48.3k for v9.1's flat 10c. 25c early made $61.9k in total but less on Oct 10, the latest day. Resting a bid one tick above
the best bid (`tools/passive_bid_sim.py`) fills profitably (+20c a contract) but uses cap the takes would have used better:
+$1k over 3 days at best. The 500 cap per window is the binding limit.

104 tests pass; pipe harness late batch sent at +0.73 s.

---


## v10 (Oct 11 morning): v9.2 + pushes that hold to the float, deep push, book-only jump signals

**Upload:** `qfin_bot_live_v10.zip` on the Bots page (Replace bot). It contains everything in v9.2 (below) plus the changes
in this section. Log: `v10 mode=pipe` at start; each close we hold:
`late push 5m close HH:MM: pos [500] strike [..] -> buy A 60u lim .. (saw N), B 1u lim .., plan print ..` (a deep push
reads `DEEP buy A ...`); the periodic P&L line ends with `jumps {'straw_fires': n, 'wm_fades': n, 'deep_pushes': n}`.

### Why upload now: v9.1 threw away ~20 won windows on Oct 10 (`tools/close_second.py`, full day)
Oct 10 final: **tacof +$16,774, 2nd of 11** (T4 +$39,353, Spudtrading +$14,949, qfingroup3 +$14,829). v9.1 ran 13:35-24:00 UTC:
- Held UP in 118 five-minute windows, won 66. 23 were lost with no late push (the ETF ended 20-70c below the strike),
  2 to another team printing after us, and **27 to our OWN late print** (it was the settle, and it was below the strike).
- **In 20 of those 27 the early push had already printed on our side**: the late batch alone turned a win into a loss.
  At 500 contracts that is a ~$500 swing each, roughly **$10k in 10 hours**. It keeps happening while v9.1 is live.
- Causes, from our fills and the tape: (1) B and the wall were priced from a book 0.7 s old; the house had refilled asks
  just below the strike (22:15: 55.76 vs 55.78; 22:20: 55.73 vs 55.76; 23:55: 53.49 vs 53.50) and both bought them.
  (2) The 10-unit wall printed LAST. At 16:50 it bought 10 at exactly the 55.62 strike, and the exchange recorded the
  average 10 x 55.62 / 10 = 55.61999999999999 < 55.62: a tie (which counts UP) lost to float rounding.
- v9.2 fixes (1) and puts the walls first. v10 also fixes the float edge and the crash below.

### Changes on top of v9.2
| area | v10 |
|---|---|
| float-exact boundaries | The exchange compares settle >= strike in float64, and strikes are average prices (API: 56.095000000000006). `first_at_or_above` / `last_below` are exact (v9.2's 1e-9 tolerance would print 55.76 against a 55.760000000000005 strike and lose). Walls sit one tick inside the range so a later multi-unit print at the wall can't land on the boundary. B (1 unit, exact price) is always our last print. |
| one push builder | `strategy.robust_push_orders` builds walk / print / walls for every range shape. v9.2 raised `OverflowError` (quotes cancelled, no push) when the range was unbounded on the side it walked: a DOWN window already in the money, early or late push. |
| late walk floor | Walk A = max(60, seen + 30) units whenever the wrong side is bounded (`LIVE.late_min_walk`). Its limit is the last tick below the strike, so it only fills wrong-side levels that are there on arrival. B is sized before A, so a margin-clipped walk never starves the print. |
| deep push | Strike beyond the visible ETF ladder but within 25c (`SETTLE_PUSH.deep_reach`): in the second before the close walk the whole visible ladder (stage 1); in the close second walk the rest of the budget at the strike + the 1-unit print (stage 2). `late_extra_units` 50 -> 100. Margin still clips everything. Live only. |
| strawberry run follow | Book-only: 3 up-jumps of 7c+ in the strawberry mid within 120 s = the size-150 buyer is running. IOC buy 60 at the ask, hold a +60 target 4 min, fade out over 2 min. Measured +11.8c @60 s / +13.9c @300 s (hist 8 days, 9.4/day) and +10.6c / +16.7c live Oct 7-10. A single jump reverts (08_findings); a run of three continues. |
| watermelon fade | A 7c+ one-second watermelon jump reverses (live -6.5c @60 s, -9.8c @300 s): lean the target 30 units against it for 5 min (passive fills). |
| ETF unwind | 20 units per IOC (was 10): pushes can leave 100-300 units. |

### Tests and backtest
- 104 unit tests on the real team-kit SDK, all passing (19 new: float-exact boundaries incl. the 16:50 tie replay, refill
  replays of 14:15 / 15:30, both trade directions, unbounded ranges, deep push stage 1 and 2, walk floor, jump signals).
- Pipe-mode harness: early push `[buy 12 @50.09 IOC, buy 1 @50.50 IOC]` at close - 1 s; late push 0.63 s into the close
  second `[cancelAll etf, bid 10 @50.11, buy 60 @50.09 IOC, buy 1 @50.50 IOC]`.
- Historical backtest (4 days, `--share 0.25 --mode mid`): **v10 $60,173/day, sd $2,888, score $57,285** vs v9.2 $59,496 /
  $2,878 / $56,618, better on all 4 days (watermelon fade +$669, strawberry follow about even). The push changes can't show
  there (no stale books, no other teams); their value is the 20 windows above.

---


## v9.2 (Oct 11, ~00:30 Perth): stop losing windows to our own late print, pickier option entries, 2-hour reversion

**Upload:** `qfin_bot_live_v9_2.zip` on the Bots page (Replace bot). In the log, look for `v9.2 mode=pipe`, then
`day ...; day length 1440 min; short_day=False`, then each 5m close
`late push 5m close HH:MM: ... buy A 37u lim 56.09 (saw 7), B 1u lim 56.50, plan print 56.12 (... ok=True)`.
The periodic line now ends `rev2h targets warming up (n of 120 minutes of history)` and, after 2 hours, the targets.

### 1. Bug fix: v9/v9.1's late push could print the settle on the WRONG side (the big one)
Our fills for Oct 10 13:10-16:05 UTC (34 five-minute windows, long UP in all of them; `tools/late_push_forensics.py`):
- In 6 windows our own late push printed BELOW the strike and that print became the settle: 14:15 (56.086 vs strike
  56.14), 14:25 (56.095 vs 56.10), 14:55 (56.21 vs 56.25), 15:30 (55.56 vs 55.57), 15:50 (55.402 vs 55.44), 16:05 (55.85 vs
  55.90). 2,840 UP contracts, **about $2.8k of payout lost in under 3 hours**. In 3 of them (14:55, 15:30, 15:50) the early
  push (close - 0.94 s) had already printed at/above the strike and nobody else traded afterwards: the late push alone turned
  a win into a loss. In 14:15 and 14:25 another team sold first, and the late push that should have fixed it printed low.
- Why: between our look at the book and our arrival (~0.7 s) the house refills the ETF asks the early push took. The
  walk order's limit was the last level WE SAW, so new asks below the strike survived it, and the 1-unit print order and the
  resting wall (a bid AT the strike) then bought them: our last print, i.e. the settle, landed below the strike.
- v9.2: the walk (A) is limited to the last tick on the wrong side of the strike and may take 30 units more than it saw
  (`LIVE.late_push_buffer`), so it clears every wrong-side level there is without ever buying on our side; the 1-unit print
  (B) may fill up to 40c past the strike (`LIVE.late_push_b_reach`: any print on our side wins); the wall goes FIRST in the
  batch so a wall that crosses a stale level is overridden by A and B. If margin would clip A below what we saw, the late
  push is not sent (no print beats a wrong print). Same limits for the early push (+5 units, `SETTLE_PUSH.early_buffer`).
- Test: a small matching engine replays the Oct 10 situation (asks refilled below the strike) against both batches: the
  v9.1 batch's last print is below the strike, the v9.2 batch's is above (`tests/...V92PushSafetyTests`, also DOWN side).

### 2. Pickier option entries early in the window (`OPTIONS.take_edge_early_by_exp`, `early_seconds_by_exp`)
Each window is cap-bound (500 contracts). Live, v9.1 bought ~465 of its ~480 contracts per 5m window in the first minute,
then had no room for the better prices that come later. Now 5m takes need 20c of edge while more than 60 s are left (10c
after); 60m takes need 10c while more than 10 minutes are left (5c after). Live option-book replay (real outcomes):

| 5m P&L | Oct 7 | Oct 8 | Oct 9 | Oct 10 | total |
|---|---|---|---|---|---|
| 10c flat (v9.1) | -$0.4k | $17.8k | $12.5k | $10.6k | $40.6k |
| **20c early / 10c last 60 s (v9.2)** | $5.7k | $23.6k | $15.1k | $10.8k | **$55.1k** |
| 25c early | $8.0k | $25.4k | $16.8k | $10.3k | $60.4k |

25c made more over the four days but the best early edge has been drifting down (Oct 10 to 16:00 UTC, incl. the v9 hours:
10c $11.6k, 20c $12.3k, 25c $11.7k), so 20c, which beat 10c on every day. 60m: $2.0k -> $3.0k, better on all 4 days.

### 3. Strawberry knowledge, generalised: 2-hour reversion on all fruits (`FEATURES.reversion_2h`, `REVERSION_2H`)
The size-150 strawberry buyer's move is given back over ~2 hours, and every fruit does the same:
next-2h move = -0.30 x (mid now - mid 2 h ago). No trade tape needed. Target inventory = that expected move / 15c x 60 units
(watermelon 30), steering the normal quotes. Minute-grid sim: +$311-423/day live at a 75-unit cap, positive on 15/15
historical and 5/5 live days. Backtest: +$506/day (positive on all 4 days). No signal in a day's first 2 hours.

### 4. Short days (the final test)
The exchange config says the final test is 20 days of 60 minutes (`backtestDays`, `backtestDayMin`), scored on mean - sd of
daily P&L, so one 60m window (up to 500 contracts) is a whole day's coin flip there. When `config["dayLengthMin"]` (or the
measured gap between two day ends) is 180 minutes or less, option caps are scaled by `SHORT_DAY.option_cap_scale`
(60m x 0.4, 15m x 0.6; 5m stays full). The log line `short_day=True` confirms it. Live days (1440 min) are unchanged.

### Tests and backtest
- 85 unit tests on the real team-kit SDK, all passing (13 new: early/late edges, reversion targets, short days, push safety).
- Pipe-mode harness (strike 50.10, 7 units of asks below it): early push `[buy 12 @50.09 IOC, buy 1 @50.50 IOC]` at
  close - 1 s; late push sent 0.63 s into the close second as `[cancelAll etf, bid 10 @50.10, buy 37 @50.09 IOC,
  buy 1 @50.50 IOC]`; a 4 s stalled call still pauses requotes and the pushes still go.
- Historical backtest (4 days, `--share 0.25 --mode mid`): **v9.2 $59,496/day (sd $2,878) vs v9.1 $55,273 (sd $1,753), better on
  all 4 days**: 5m option takes +$1.9k, resting 5m quotes +$1.6k (fill model optimistic), 2h reversion +$0.5k. The push fix
  can't show here (the backtest has no other traders and a fixed ladder).

### Watch after upload
- Late-push lines: `A ...u lim X` must be one tick below the strike for a long-UP window (above it for long DOWN).
  The `late pushes sent/settled/won` count should now win most windows it fights (v9.1 today: 10 of 15).
- `rev2h targets` appear 2 hours after the bot starts (and 2 hours after each daily reset).

---

## v9.1: crash guard less jumpy
Live, v9's first 10 minutes: no restarts, first late push settled on our print, but exchange calls routinely took 2-2.7 s and
the 2 s rule kept the bot paused for 120 s at a time (no fruit requotes). `slow_call_s` 2.0 -> 3.5, `cooldown_max_s` 120 -> 60.
Exchange config logged: etfFee $0.05, enabledExpiries [5, 60]; final test = 20 simulated days of 60 minutes ('backtestDays',
'backtestDayMin').

## v9 (Oct 10 night): win the close second, price off the basket, survive a slow exchange

**Upload:** `qfin_bot_live_v9.zip` on the Bots page (Replace bot). Watch the log for `v9 mode=pipe; exchange config: {...}`,
then `late push 5m close HH:MM: ...` lines every 5 minutes, and the periodic `calls ... late pushes sent/settled/won` line.

### What the data showed (07_findings.md has the numbers)
1. **The option settle is the LAST ETF trade inside the close second** (every trade stamped HH:MM:00.xxx counts; checked on
   1,163 historical and ~200 live windows with trades in that second, no exceptions). The option book still shows the old
   window during that second. v8 only pushed while `seconds_left > 0`, i.e. one second early, so any team (or house trade)
   printing inside the close second overrode us. Today: windows we pushed won 77.5%; of the losses, most had a later print in
   the last second / close second (e.g. 00:45: we printed +1c over the strike, someone then sold the ETF 20c down).
2. **Hosted bots run in the SDK's pipe mode** (team kit `exchange.py`: `QFIN_BACKTEST=1`, every API call goes through the
   platform synchronously). That is why v7/v8/v8.1 crash-looped: one exchange call stalling 5-7 s = on_tick > 5 s = killed.
   Threads cannot help there (the pipe isn't thread-safe; v8.1's async path never ran).
3. **Price 5m options off the basket**, not the raw ETF: replay of our live option books Oct 7-10, drift 0 -> 0.8 lifted 5m
   P&L from $28.0k to $40.6k over the 4 days (better on every day). The basket predicts the settle better for anything 30 s+ out.
4. **Market rules (team kit):** positions are valued at the mid all the time and closed at the end of the day -> flattening
   only costs money. Position limit 500 on everything, margin 100%, ETF create/redeem exists (fee in `config["etfFee"]`).

### Changes
| area | v9 |
|---|---|
| **late push** (`LIVE.late_push*`) | In the close second of a window we hold, skip normal orders and send ONE batch timed to arrive at close + 0.70 s: cancel our ETF quotes, walk every ETF level on the wrong side of the strike (+10 buffer), print 1 unit on our side (+3c tolerance), then rest a 10-lot "wall" at the strike so a later house trade still prints on our side. Early push kept, now only on the last tick before the close (`fire_seconds` 1.5). Push budget 120 -> 200 units (+50 for the late push); the adapter still clips to margin and the 500 limit. |
| **crash guard** | at most one exchange call per tick; any call slower than 2 s (or failed) pauses non-critical orders 15 s (doubling to 120 s if it repeats within 5 min); in pipe mode resting-quote-only refreshes go at most every 2 s (IOCs always immediately); no CancelAll retries during a pause. Periodic log line shows call latency, throttled ticks, cooldown skips. |
| **option model** | `drift_by_exp {5: 0.8, 60: 0.3}` in every mode (was 0 live); 60m: hold UP to settle like 5m (`sell_up` 60 -> False: our resting 60m asks lost 37c/contract on Oct 10); dynamic expiries (trades `up15` if the final test enables it) and ETF-mid-settled options priced noise-free instead of skipped. |
| **end of day** | `flatten` off and no late-day reduce-only (`reset_flatten_*` = 0): positions close at the mid anyway. Daily loss stop 1.5k -> 3k. |
| **ETF unwind** | pushes leave ETF inventory; above 40 units it is trimmed with 10-lot IOCs at the touch, never within 20 s of a 5m close. |
| **own-quote leak fixed** | v8 re-placed our ETF quotes in the same batch as the early push (e.g. an ask at mid+4c, below a strike we had just pushed above): a buyer lifting it before the close printed the settle on the wrong side. Push seconds now send no ETF quotes; the late push cancels them. |
| **diagnostics** | logs the exchange config once (ETF fee, enabled expiries), every late push, and late-push outcomes when the state carries settled windows. |

### Tests
- 72 unit tests on the **real team-kit SDK** (all pass, including the pipe-transport entry point).
- Pipe-mode harness (`QFIN_BACKTEST=1`, real clock, a 5m close inside the run): early push at close-1 s, late push sent
  0.63 s into the close second as `[cancelAll etf, buy 17 IOC @50.08, buy 1 IOC @50.15, bid 10 @50.10]`; with one call
  stalled 2.5 s the bot pauses requotes for 15 s but still sends the pushes.
- Historical backtest (4 days, `--share 0.25 --mode mid`): **$55,265/day, sd $1,763 (score $53,502)** vs v8.1 $49,896 /
  sd $1,603 (score $48,293); better on all 4 days. The late push itself can't be replayed (no other teams in the data).

### Watch after upload
- `late push ... ok=True` lines at every 5m close where we hold a position; `slow/failed exchange call` warnings should be
  followed by quiet skipping, not restarts. If restarts continue, the stall is longer than a single call: raise `requote_s`.
- If late pushes stop settling on our print, the cut-off may be earlier than measured: lower `LIVE.late_push_at_s` (0.5).

---


## v8.1 (Oct 10 evening): v8 still crash-looped -> orders now never run on the tick clock

v8 went live and crashed 10 times in 54 min ('on_tick took longer than 5s', 'slow tick: orders 5.78s'). Two fixes:
- `LIVE.async_orders` (on): on_tick only reads state and runs the strategy (~10 ms); planning, the state re-check and the
  order batch run on one background thread. While that thread is busy, ticks skip. A slow exchange can no longer kill the bot.
- `LIVE.straw_flow` now **off**: its first `download_data()` pulls every recorded day during trading. Turn it back on once v8.1
  has run a day without restarts. (The SDK signature is now known: `download_data(dest='data', *, overwrite_today=True) -> list[str]`.)
The SDK log also showed methods we haven't used yet: `fair_value`, `create_etf` / `redeem_etf`, `etf_composition`.

## v8 (Oct 10): stop the restart loop, sharper option taking

**Upload:** `qfin_bot_live_v8_1.zip` on the Bots page, same as before. Watch the first minutes of the log for
`SDK methods: ...` and `SDK state keys: ...` (new one-off diagnostics), then the usual `P&L ...` lines.

**1. Stability fix (the big one).** On Oct 10 the Bots page showed **109 restarts** ("on_tick took longer than 5s"); the log
had `batch failed (7139ms): exchange unavailable` / `slow tick: orders 7.15s`. A slow order batch held the SDK state lock and
the next tick waited on it (`with self._state_lock`, no time limit). Downtime from fill gaps: 0.76 h of 10.4 h today (~7%),
plus missed close-second pushes. v8:
- waits at most `LIVE.lock_timeout_s` (0.5 s) for the lock, otherwise skips that second;
- skips a tick entirely while the previous batch is still running (no state access at all);
- won't send if the tick has already used `LIVE.send_budget_s` (3 s); these skips do NOT cancel resting quotes.

**2. 5m options: take only at 10c edge** (`OPTIONS.take_edge_by_exp = {5: 0.10, 60: 0.05}`). 5m windows are cap-bound
(~470 of 500 contracts per window live), so pickier entry buys the same contracts cheaper.

**3. 60m options: fat tails** (`OPTIONS.tail_nu = {60: 8}`, Student-t in `models.OptionModel`). 60m ETF moves fit a
t-distribution with 6-10 degrees of freedom (06_findings.md); 5m stays normal.

| test | v7 | v8 |
|---|---|---|
| replay of OUR live option books Oct 8 / 9 / 10 (cap 500, 50/s at touch, real outcomes) | $28,990 total | **$33,433** (+$4.4k; better on every day, both changes) |
| historical backtest, 4 days, `--share 0.25 --mode mid` | $48,699/day, sd $1,781 | **$49,896/day, sd $1,603** (better on all 4 days; straw_flow is +$74 of that) |

Out-of-sample check on Oct 6-7 (before the close-second push regime): the same 5m long-UP replay LOST money on both days
(5c edge: -$4.2k / -$5.7k; 10c: -$3.7k / -$4.1k). 10c is still the better setting, but the 5m UP edge depends on the UP side
winning the close. If 5m P&L turns negative for a day, that regime has changed: lower `LIVE.option_inventory_scale`.

Same caveats as always: replays don't move the market. The 5m-edge result came from 3 live days; 15c+ was worse on Oct 10,
so don't push it higher without more days.

**4. Strawberries: 2-hour reversion after the size-150 buyer** (`FEATURES.straw_flow`, `config.STRAW_FLOW`). The informed
strawberry buyer (size exactly 150) pushes the price up for ~2 minutes, then over the next ~2 hours it gives it back:
`next-2h move (c) = 11 - 6.6 x (size-150 buys in the last 2 h)` (31 hist days + Oct 6-10; fit on 16 days, out-of-sample
hist->live correlation 0.42). The bot sets a strawberry target inventory from that (max +-60, full size at a 20c expected move)
and the normal quotes lean into it passively.
- Live it needs the trade tape: a background thread calls `self.download_data()` every 10 min (format undocumented, so the
  code digs the trades table out of whatever comes back). If that fails, the feature stays idle and logs
  `straw_flow tape unavailable: ...` - it never touches on_tick timing. The periodic P&L log line now shows
  `straw150_2h=<count>; straw_pred=<expected $ move>`; `download_data() returned ...` is logged once.
- Expect small money: backtest +$74/day (4 days, 3 up); minute-level sim ~$80-100/day at a 75-unit cap, positive on 14-15 of 15
  held-out days. Turn off with `LIVE.straw_flow=False`.
- Researched and NOT built: following the buyer in the first 2 minutes (the big +24c move). The live SDK shows no trade sizes in
  real time, the downloaded tape is ~1 min old (entering 30 s+ late loses money), and a predictive model of the next 150 print
  (gradient boosting on 1 Hz book features) only reached AUC 0.53-0.65 out of sample - not tradeable.

Tests: 63 (52 old + 6 `V8Tests` + 4 `StrawFlowTests` + 1 `AsyncOrderTests`); all pass on a local SDK stand-in except the real-SDK pipe test, as before.

---


## Upload

1. Open https://exchange.qfinuwa.org and log into your team account.
2. Go to **Bots** and upload `qfin_bot_live_ready.zip` as supplied. Do not unzip/re-zip it inside another folder.
3. Uploading starts trading automatically. Watch the bot status and logs immediately.
4. Look for `strategy reset; profile=mid; options=True`, then account P&L, equity, margin and positions.

No passwords belong in this ZIP. The site supplies `exchange.py` and the team connection.
The ZIP has `bot.py` at the root and is below the guide's 5 MB limit.
This is a new deployment package; your original uploaded archives have not been edited.

## v7 = v6 + the v5.3 stability fix
- Order batches run in a background thread; on_tick waits at most 2.5 s (1.5 s for quote cancels), so a slow exchange can't
  push on_tick past the platform's 5 s kill (v5.2 crash-looped 38+ times on the evening of Oct 9).
- Keeps v6's no-UP-selling in 5m windows, the short-UP cap, the settle bias and the 500 option cap.

## v6: never sell UP in 5-minute windows (from the Oct 8-9 fills)
| 5m UP fills | Oct 8 | Oct 9 |
|---|---|---|
| we buy (take) | +12,979 (+17c/contract) | +8,478 (+15c) |
| our resting ask lifted | -7,650 (-21c) | -4,234 (-16c) |
| we sell (take) | 0 | -4,486 (-37c) |
`OPTIONS.sell_up={5: False, 60: True}`: no 5m asks and no 5m sell takes; the bot buys UP and holds to settle. 60m unchanged
(mixed and small). The adapter now logs `slow tick` (stage timings) when a tick passes 2 s and skips sending
when the strategy alone passes 3 s: v5.2 was restarted once by the platform for an on_tick over 5 s. Also tested and REJECTED: an ETF delta hedge of the option book (6 historical days, 25% share: mean
46.3k -> 40.9k, sd 1.65k -> 1.85k at an 80-unit cap; worse at 200).

## v5.2: cap short-UP at 100 contracts (from the Oct 8-9 fills)
Per-window P&L from the exchange's own fills CSV (5-minute options): longs +$2.1k, shorts -$2.5k on Oct 9. Shorts of 300+ were 17
windows, 1 win, ~-$3.4k, and UP won 17/17; shorts under 300 were net positive. `OPTIONS.max_short=100` caps short-UP; longs keep
`max_contracts`. Historical backtest impact is checked in the README table below.

## v5.1 fix (same day): the book may only VETO
v5 let deep, far-away ETF levels RAISE the push value, so it loaded 500 contracts on strikes 27c from the ETF and lost ~$980 in 17 min.
Now `reach = min(affordable from the real book, touch + SETTLE_PUSH.reach)`: never more generous than v4, stricter when the book is thin.

## v5: value options with the real ETF book (from the Oct 8-9 live data)

What the live data showed (337 five-minute windows): by 3 s before the close the ETF book has already decided ~90% of
windows. Strike above the best ask -> UP won 9-20%; strike below the best bid -> UP won 100%; only ~10% of windows had the
strike inside the spread. Live settles also print about +1.2c above the mid, and mean reversion is about half the historical.

Changes (live only; the historical backtest is unchanged - checked: identical fills on 2026-03-26):
- `FEATURES.book_reach` (on): the option model values the settle push with the REAL ETF ask/bid levels each second
  (`Bot.affordable_reach`: furthest print we could pay for within `SETTLE_PUSH.max_units` and `cost_frac`, capped at
  `SETTLE_PUSH.reach_cap` 0.60) instead of "touch + 10c". If the strike is beyond the top of the book the option is valued as
  unpushable, so the bot stops buying it and sells down what it holds. The adapter now supplies `etf_levels` every tick.
- `LIVE.settle_bias` 0.012: adds 1.2c to (ETF mid - strike) in the option model. On the live days this cut the model Brier
  score .1189 -> .1134 and lifted model-vs-quote edge P&L ~25% (both days positive).
- 4 new tests (`BookReachTests`); 46 tests, 45 pass on the stand-in (only the real-SDK pipe test needs the real SDK).
- Not changed: noise width. Tightening the settle noise to the live close-second spread was tested and was worse overall.

Caveat: the Data page has no book depth, so the reach logic is tested with unit tests, not replayed with real depth.
Watch the first hour live: positions in 5m windows whose strike is outside the book should now be small or flat.

## v4: push harder

`SETTLE_PUSH.max_units` 40 -> 120 (ETF units per window across re-fires) and `fire_seconds` 1.5 -> 3.0 (first push at 3 s left, then re-fire every tick the last ETF print is on the wrong side). **Backtest cannot judge this:** raising the unit budget, the cost gate (`cost_frac` up to 3.0) and units up to 150 all gave identical P&L, because pushes never hit those limits in the replay and the replay has no opposing pusher. Whether these help depends on who prints last in the close second live. Risks: ETF inventory left after a push (up to 120 units, bounded by the exchange limit and margin budget; the market-making quotes unwind it), and an earlier first push gives an opponent more time to answer. If settles stop matching our prints, return to 40 / 1.5.

## v3 changes: bigger option cap, bigger fruit/ETF scale

- **`OPTIONS.max_contracts` 300 -> 500.** The live leaderboard showed us pinned at +-300 on up5 and up60 (cap-bound) while the leader held +-500.
  Backtest (mid mode, 25% share, 26 Mar + 17 Jun, `--push-fail` = chance another team overrides our close-second print):

  | other teams override us | cap 300 | cap 500 |
  |---|---|---|
  | 0% | $33.9k/day | **$50.2k/day** |
  | 30% | $26.9k | **$38.4k** |
  | 60% | $19.3k | **$25.7k** |

  The adapter still clips to the exchange position limit and the margin budget (option orders are planned first, so they are not starved by fruit quotes). Margin is $1 per possible contract: 500 + 500 = $1,000.
  **Backtest dollars are an upper bound** (it assumes the option book refills at the touch every second); yesterday's live result was far below the backtest. The *direction* (cap-bound -> bigger cap earns more, even when out-pushed) is what the test supports.
  If live pushes start failing (check settles vs our prints), dial back with `OPTIONS.max_contracts`.
- **`LIVE.quote_size_scale` / `LIVE.inventory_scale` 0.10 -> 0.25** (fruit quotes 5 lots, caps 75 units; ETF cap 12; pair trade 25 units per leg). Live fruit positions were only +-3-12 units, so fruit trading earned almost nothing.
- Tried and **rejected**: a self-calibrating push (learn how often our push wins and shrink the cap). It *lowered* backtest P&L both with and without out-pushing (-$0.9k and -$1.3k/day), so it is not in the package.

## NEW: apples-oranges pair trade (passive on, aggressive off by default)

The spread `oranges mid - apples mid` mean-reverts to its 2-minute EMA (sd of the deviation ~5c; beyond +-5c about 28% of the time;
a 5-8c stretch gives back ~5c in 60 s, over 8c ~7.5c). The bot already had a small `pair_lean` (quote-centre nudge). There are now two
real pair trades, both **1:1 hedged** (equal units on the long and short leg), switched by `FEATURES` and tuned in `config.PAIR_TRADE`:

| version | flag | how it trades |
|---|---|---|
| passive | `pair_passive` (**on**) | when `|dev| >= 5c`, set opposite **target inventories** (long cheap leg, short rich leg; 50% of `max_units` at 5-8c, 100% at 8c+). The normal market-making quotes lean to those targets and fill them. No spread is crossed. |
| aggressive | `pair_aggressive` (off) | when `0.8 x |dev| - cost of crossing both spreads >= 1c` (cost read from the books, ~6c, so dev ~ 9c+) it sends **IOCs on both legs** at the touch, same size, capped by the displayed touch size of both legs. It also sets the targets so the quotes keep the position. |

**Cap and exits** (`PAIR_TRADE`): `max_units` 100 per leg (aggressive: `aggr_max_units` 100). One trade at a time, with the EMA **frozen at the open** as an anchor (the live EMA chases a stretched spread and fakes a reversion). It closes when (1) the spread is back at the anchor (`exit_dev`), (2) `hold_max_s` = 600 s, (3) late in the day (`RISK.flatten_start`; also no new trades), or (4) optional stop-loss `stop_dev` (**off**: it cost $30-120/day in the backtest, and the cap already bounds the loss). After a close the target is 0 and the quotes unwind the legs passively. `cooldown_s` = 30. Pair position is measured from real inventory, so ordinary market-making fills in apples/oranges count against the cap.

**Mid mode.** The pair signal uses only mids, so it needs no Kalman filter and runs in `centre_mode="mid"` (the live setting) when `FEATURES.pair_mid_mode` is on (default). Nothing else needed changing. What does need checking is the *premise*: mid mode exists because live flow may no longer snap prices back, and the spread reversion comes from that same flow. `live_check.py` now also prints the spread reversion per bucket and a verdict. If it says "GONE", set `LIVE.pair_trade=False`.

**Live adapter.** `LIVE.pair_trade` is the master switch. Units per leg scale with `LIVE.inventory_scale` (100 -> 10; aggressive clip 10 -> 1). In `plan_orders` the two pair legs are sized **as one unit**: one common quantity, the largest that fits both legs' position caps, the reduce-only rules (loss stop / late day) and the joint margin budget; if either leg cannot be placed, neither is sent. Our own resting quotes in those fruits are cancelled in the same batch before the IOCs (no self-trade).

**Backtest** (6 days: 19 Jan, 12 Feb, 26 Mar, 22 Apr, 20 May, 17 Jun; same days and same option/push settings for every row; difference = apples/oranges only). Mean $/day for the whole bot, and the gain over the current bot; the pair trade won on all 6 days in every row.

| centre mode | share | current bot | + passive | + aggressive | + both |
|---|---|---|---|---|---|
| kalman | 0.25 | 44,312 | 44,600 (**+287**) | 44,789 (**+477**) | 44,769 (+457) |
| kalman | 1.00 | 73,664 | 74,610 (**+946**) | 74,590 (**+927**) | 74,625 (+962) |
| **mid (live)** | 0.25 | 31,802 | 33,884 (**+2,082**) | 32,881 (**+1,079**) | 33,924 (+2,122) |
| **mid (live)** | 1.00 | 49,978 | 53,417 (**+3,439**) | 51,470 (**+1,492**) | 53,285 (+3,307) |

The pair parameters were tuned on 26 Mar and 17 Jun (kalman, 25%, options off) and then checked on the other four days (passive +229 to +275/day, aggressive +385 to +576/day, all positive). `pair_lean` stays on: it is worth ~$110/day on its own and the passive trade is additive in the test. Run any variant yourself, e.g.
`python backtest.py --share 0.25 --enable pair_aggressive 2026-03-26`, `--disable pair_passive`, `--mode mid`, `--set PAIR_TRADE.max_units=50`.

**Read the numbers with the usual caveats.** The replay keeps the market maker's historical price path, so the reversion is *given*; mid mode "gains" more only because mid mode has no other way to earn it. If live flow is random, the gain may vanish and the legs could lose; the pair cap bounds that. Our own price impact is not modelled for the aggressive IOCs, and no competitor quotes exist in the data (`--share` approximates them). Live, the pair is only 10 units per leg at the default scales, so the real dollars are small until you raise `LIVE.inventory_scale`.

## NEW: options manipulation (settle push), enabled

The organisers allow manipulating the options market, so this version does it deliberately.

**How it works.**
- **The mechanism:** an up/down option settles on the **last ETF trade at or before the close second**. A trade's recorded price is the **average fill price of the order**. So in the close second we can make the settle print land on our side of the strike:
  - **Want UP** (long up): order A buys every ETF ask level below the strike. Order B then buys **1 unit** at the first level at or above the strike, so the print is exactly that level.
  - **Want DOWN:** the same, selling down the bid side to print below the strike. A tie (print == strike) resolves UP.
  - **Top of the hour:** the 5m and 60m windows close in the same second. The bot picks the print range that wins the most contracts across both.
- **Valuation (`models.prob_up_pushed`):** options are valued knowing we will defend our side. A position is worth more when the ETF is within reach of the strike at expiry, so the bot builds bigger option positions (cap raised to 300 contracts per window).
- **Gates:** a push only fires if its estimated cost (price displacement paid, counted twice to cover unwinding the ETF) is at most 50% of the contracts at stake. A window gets at most 40 ETF units across all pushes.
- **Live timing:** the adapter starts pushing when `seconds_left <= SETTLE_PUSH.fire_seconds` (1.5 s). If the latest ETF print is on the wrong side, it fires again on the next exchange state until the window rolls.
- **Exemptions:** push orders are exempt from the market-making inventory caps and the late-day reduce-only rule. They are still bounded by the exchange position limit, `SETTLE_PUSH.max_units` and the margin budget. Our resting ETF quotes are cancelled in the same batch first, so we can't trade with ourselves.

**Backtest** (2 days, we win 25% of eligible flow and option fills):

| version | score $/day |
|---|---|
| previous bot (1-lot nudge, 50-contract cap) | 22,457 |
| settle push, 200-contract cap, reach 0.20 | 33,280 |
| settle push, 200 cap, **reach 0.10** | 35,676 |
| **default now: settle push, 300 cap, reach 0.10** | **44,217** |
| same, but another team out-pushes us 30% of the time (`--push-fail 0.3`) | 37,260 |
| settle push 200 cap, out-pushed 60% of the time | 23,157 |
| settle push, 500 cap (100% share) | 83,789 |

**Things to check live, in order:**
1. **When the close second counts.** Confirm from the first few windows that a trade in the last 1.5 s before `windowClose` sets the settle. Compare the ETF trades you send with the window's reported settle. If the settle is taken from a later second, raise or lower `fire_seconds`.
2. **The real ETF book.** The push uses the real external ETF book levels live. The backtest used a synthetic book (`SETTLE_PUSH.ladder`) fitted to historical fills.
3. **Option liquidity.** The backtest assumes we can take up to 50 contracts per second at the touch, refilled every second. If fills are thinner live, lower `OPTIONS.max_contracts` or `LIVE.option_inventory_scale`.
4. **Other teams.** If they fight the close, our prints get overridden more often. `--push-fail` in the backtest shows the impact. It can't be fully controlled, so don't push sizes up blindly.

New/changed settings: `FEATURES.settle_push`, `SETTLE_PUSH` (reach, max_units, cost_frac, p_win, fire_seconds, ladder),
`OPTIONS.max_contracts=300`, `LIVE.enable_options=True`, `LIVE.settle_push=True`, `LIVE.option_inventory_scale`,
`LIVE.option_quote_scale`. Tests: `SettlePushTests` in `tests/test_live_adapter.py`.

## Initial deployment settings

The strategy is preserved in `strategy.py`; `bot.py` starts the SDK adapter.
Edit the `LIVE` dictionary at the end of `config.py` and re-upload to change the deployment profile.

| Setting | Default |
| --- | --- |
| Price centre | current mid, without historical directional flow signals |
| Apple/banana/orange/strawberry quote | 2 units per side |
| Watermelon/ETF quote | 1 unit per side |
| Apple/banana/orange/strawberry inventory cap | 30 units |
| Watermelon inventory cap | 15 units |
| ETF inventory cap | 5 units |
| Options | **enabled**, cap 300 contracts per window (`OPTIONS.max_contracts` × `LIVE.option_inventory_scale`) |
| Settle push (options manipulation) | **enabled** |
| Portfolio margin budget | 80% of equity, conservative estimate |
| Market data stale threshold | 3 seconds |
| Old 1-lot settlement nudge / settle_value pricing | replaced by the settle push |

The exchange enforces its own limits as well. Portfolio sizing includes both resting quotes and possible IOC fills.
Futures use full notional at the highest available book/trade/order price; options reserve $1 per possible contract.
These estimates deliberately exceed some actual option margin requirements. A buffer is not a guarantee against moving prices or rejected orders.
When current holdings already exceed the budget, or the daily loss stop is latched, orders can only reduce exposure.
Aggregate reducing orders cannot cross through flat. Before day-end, the adapter uses `account.day_end` to restrict risk and flatten.
The daily $1,500 loss-stop parameter remains in `RISK`; lower it there if desired.

## What was implemented

- SDK `Exchange` subclass and `on_tick()` entry point, with SDK authentication/reconnects and official pipe backtest support.
- Consistent market/account/order snapshots copied under the SDK state lock.
- Book levels subtract the remaining quantity of your orders, keeping other traders at the same price.
- Batched cancellations, IOCs and replacement quotes; unchanged quotes retain their place.
- Partial fills and rejected orders reconcile against actual remaining orders on the next state.
- Pending submissions wait for a subsequent state before another submission; timeouts do not trigger an immediate duplicate order.
- Position caps and conservative combined margin sizing for quotes plus IOCs.
- Missing/stale data and exceptions pull quotes. Cancellations are retried while data remains stale.
- HTTP order timeouts, bounded in-memory state and bounded optional on-disk logs.
- Daily state reset, preserving the loss stop through same-day busts.
- Exchange day-end scheduling rather than an assumed UTC midnight reset.
- Official option strikes and timestamps; window checks immediately before submission.
- Historical backtest retained and decoupled from the live entry point.

`FEATURES`, `QUOTE` and other original parameters still describe the historical strategy. `LIVE` restricts their live deployment.
The historical replay does not apply the live adapter's margin/sizing controls; use it for research comparisons rather than live P&L forecasts.

## Enabling options or the Kalman centre

After inspecting initial fills and account behaviour, set `LIVE.enable_options=True` to enable option trading.
With the default scales, option quotes are 2 contracts per side and the live option position cap is 5 contracts.
The adapter only trades enabled products with a valid official strike, an external two-sided book and more than 5 seconds left.
It skips option products whose `price_source` is not `etf_last_trade`, because the fitted model includes last-trade settlement noise.
It verifies window identity again just before submission. The documented API has no conditional window identifier on an order,
so a server-side roll during request transmission cannot be eliminated; the 5-second cutoff reduces that exposure.
`settle_nudge` and `settle_value` stay off; the settle push replaces them (`LIVE.settle_push`).

Set `LIVE.centre_mode="kalman"` only after comparing live behaviour with your historical data.
`CENTRE_MODE` controls the research core's default; `LIVE.centre_mode` controls the uploaded adapter.
The live checker prints a recommendation; it does not edit configuration automatically.

## Optional local logs

Set `LIVE.log_directory` to a writable directory to record:

- `live_tob.csv`: headerless `ts,product,bid,ask,bid_size,ask_size` rows, using external books.
- `order_acknowledgements.jsonl`: strategy-tagged outgoing actions and the exchange's full batch responses.

Each log rotates to one `.previous` file after roughly 5 MB. No unbounded data accumulates.
File logging defaults off. The supplied guide does not document downloading files written by a site-hosted bot.
For a local run, use these logs with:

```bash
python live_check.py logs/live_tob.csv.previous logs/live_tob.csv
```

You can also pass original Parquet top-of-book files. Around four hours of data is a starting point;
short, constant or sparse samples do not establish which price model works live.

## Fill attribution limitation

The provided SDK has no documented passive-fill callback or complete trade tape.
The adapter does not manufacture ETF trades from a repeatedly observed last-trade price,
and does not infer missing fill prices from inventory changes.
Account P&L from the SDK is authoritative for live risk and printed performance.
Order-response logs can contain explicitly acknowledged fills, but are not a complete passive-fill ledger.
`pnl_tracker.py` remains available for historical backtesting. Exact live P&L by strategy requires an official fill-history feed/API.

## Local checks or local running

Keep the supplied team-kit SDK outside the upload ZIP. For local development, copy its `exchange.py` alongside `bot.py`,
or add the team-kit directory to `PYTHONPATH`. Install local dependencies:

```bash
python -m pip install numpy pandas scipy requests websockets
# pyarrow is needed only for Parquet research/backtests
python -m pip install pyarrow
```

Run the offline tests from this directory, with the SDK available:

```bash
python -m unittest discover -s tests -v
```

The supplied SDK also supports running `python bot.py -u TEAM_NAME -p TEAM_PASSWORD` locally.
That starts trading using the same team account; run one active bot per team.
A local process must stay running; the site's upload service runs the bot for you.
To stop a site bot, use **Remove bot**. Positions remain according to the supplied guide;
removal should not be treated as a flatten command or as proof that resting orders were cancelled.

## Validation and remaining live checks

21 offline tests passed against the provided SDK, including its real pipe exchange loop and root upload entry point.
**Settle-push added 4 tests (25), the pair trade adds 17 more (42 total, in `PairTradeTests`).** They were run against a minimal SDK
stand-in, not the real `exchange.py`: 41/42 passed, and the pipe-transport test needs the real SDK. Re-run the full suite with the
team kit before uploading.
Coverage includes 150 randomized portfolio allocations, own-order removal, partial fills, margin, loss stops,
bust/day resets, stale data, incomplete books, window rolls, order rejections, submission timeouts and log rotation.
No live account login, upload or real server order was performed. Your historical Parquet data was not included,
so historical profitability was not rerun. The supplied SDK and guide are the integration contract;
actual server authentication, batch response details, limits and performance still need observation after upload.

## v16 — two-sided regime switch (final submission candidate)

v16 = v15 plus a DOWN mode, driven by the same settled-window history (`up_hist`, fed from `optionWindows`):

| Recent UP win rate (5m: last 12, 60m: last 6) | Behaviour |
|---|---|
| >= 50% | UP mode: buy UP as before (open buy, model takes, resting bids); settle push defends long. |
| 25%–50% | Neutral: no new option risk either way. Fruit/ETF market making continues. |
| <= 25% (5m only) | DOWN mode: no buying; short UP up to 500 via model takes / resting ask; settle push defends short (pushes down). |

Needs at least 8 (5m) / 4 (60m) settled windows before either gate engages; before that it behaves like v14.2.
Config: `OPTIONS.regime_gate` (buy side), `OPTIONS.regime_sell` (sell side). To disable DOWN mode, set `regime_sell={}` (= v15).
Caps chosen by replay (Oct 6-12 books, real outcomes): 5m short at a 25% gate is mildly positive and rises with cap (500 = long cap); a 35% gate loses at every cap; 60m shorting loses at every cap, so 60m has no DOWN mode. UP side unchanged (open buy 500 @ <=70c, the replay best).
Log line on start: `v16 mode=...`. `open_stats` counts `regime_blocked` and `down_mode`.
