"""
QFin Project - Step 3: options + market-maker mechanics + jumps.

Run from the "QFin Project" folder:
    pip install pandas pyarrow numpy scipy
    python 03_deep_dive.py        # every 6th day for tick data, ALL days for option_windows
    python 03_deep_dive.py 12     # every 12th day (faster)

Sections
  A. Option window outcomes (all 182 days)        - win rates, streaks, vol by time of day
  B. Strike/settle noise                           - last-trade price vs mid, effect on P(up)
  C. Fair-value model for up/down options          - vs market quotes: calibration, edge
  D. Option order flow                             - who trades, who wins
  E. Market-maker rules                            - quotes symmetric, mid moves = lambda * signed volume
  F. Big moves                                     - do they continue or revert?
15-minute options are excluded everywhere.
"""
import sys, glob, os
import numpy as np, pandas as pd
from scipy.stats import norm

D = "qfin_project_data/members/"
FRUITS = ["apples", "bananas", "oranges", "strawberries", "watermelon"]
PRODS = FRUITS + ["etf"]
STEP = int(sys.argv[1]) if len(sys.argv) > 1 else 6
pd.set_option("display.width", 250)

def read(table, day): return pd.read_parquet(f"{D}{table}/date={day}.parquet")
all_days = sorted(os.path.basename(f)[5:15] for f in glob.glob(D + "top_of_book/*.parquet"))
days = all_days[:-1][::STEP]            # last file (1 Jul) is a partial day with broken settles
print(f"Tick-level sample: {len(days)} days")

# ---------------------------------------------------------------- A. Window outcomes
W = pd.concat([pd.read_parquet(f) for f in sorted(glob.glob(D + "option_windows/*.parquet"))])
W = W[(W.expiry_min != 15) & (W.settle > 0)].copy()          # settle=0 rows are an end-of-data artifact
W["ret"] = (W.settle - W.strike).astype(float)
print("\nA1. Outcomes (all days)")
print(W.groupby("expiry_min").agg(n=("up_won", "size"), up_rate=("up_won", "mean"),
                                  sd_move=("ret", "std")).round(3))
print("\nA2. Streaks: P(up | previous window up/down)  <- strike = previous settle = a noisy last trade")
for e in [5, 60]:
    w = W[W.expiry_min == e].sort_values("window_open"); prev = w.up_won.shift()
    print(f"  {e}m: after UP {w.up_won[prev == True].mean():.3f}   after DOWN {w.up_won[prev == False].mean():.3f}")
w5 = W[W.expiry_min == 5]
print("\nA3. 5m sd of ETF move by window minute-of-hour (cents)")
print((w5.groupby(w5.window_open.dt.minute).ret.std() * 100).round(1).to_dict())

# ---------------------------------------------------------------- per-second panel for sample days
frames = []
for d in days:
    tb = read("top_of_book", d); tb["mid"] = (tb.bid + tb.ask) / 2
    m = tb.pivot(index="ts", columns="product", values="mid")
    tr = read("trades", d); e = tr[tr["product"] == "etf"]
    f = pd.DataFrame({"etf": m.etf, "bsk": m[FRUITS].sum(axis=1)})
    f["last"] = e.groupby("ts").price.last().reindex(m.index).ffill()
    ob = read("option_top_of_book", d)
    for x in [5, 60]:
        o = ob[ob.expiry_min == x].set_index("ts")
        f[f"b{x}"], f[f"a{x}"], f[f"wo{x}"] = o.bid, o.ask, o.window_open
    frames.append(f)
F = pd.concat(frames)
F["noise"] = F["last"] - F["etf"]

# ---------------------------------------------------------------- B. Strike noise
print(f"\nB1. Last ETF trade minus ETF mid: sd {F.noise.std()*100:.1f}c, "
      f"quantiles {(F.noise.quantile([.05,.25,.5,.75,.95])*100).round(1).to_dict()}")
print("\nB2. P(up) by (strike - ETF mid at open), cents")
for x in [5, 60]:
    w = W[(W.expiry_min == x) & W.window_open.isin(F.index)].copy()
    w["d0"] = (w.strike.values - F.etf.reindex(w.window_open).values) * 100
    w["bucket"] = pd.cut(w.d0, [-100, -10, -5, 5, 10, 100])
    print(f"  {x}m:", w.groupby("bucket", observed=True).up_won.agg(["size", "mean"]).round(3).T.to_string().replace("\n", "\n      "))

# ---------------------------------------------------------------- C. Fair-value model
# P(up) = P( mid_T + e >= K ),  mid_T - mid_t ~ N(drift, var)
#   var   : sigma^2 per second (1.48c) x intraday activity weight, summed over remaining seconds
#   drift : ETF closes ~55% of its gap to the basket
#   e     : settle noise (last trade - mid), empirical distribution
d_etf = F.groupby(F.index.date).etf.diff()
# ETF trends short-term, so 1-second variance understates longer moves: calibrate on 5-minute changes
sig2 = F.groupby(F.index.date).etf.diff(300).var() / 300
v = d_etf ** 2
w_min = (v.groupby(F.index.minute).mean() / v.mean()).values
w_hr = (v.groupby(F.index.hour).mean() / v.mean()).values
secw = np.array([w_min[(s // 60) % 60] * w_hr[s // 3600] for s in range(86400)]); secw /= secw.mean()
cum = np.concatenate([[0], np.cumsum(np.tile(secw, 2))])
noise = np.quantile(F.noise.dropna(), np.linspace(0.01, 0.99, 49))
print(f"\nC0. ETF sigma = {np.sqrt(sig2)*100:.2f}c per sqrt(second)")

rows = []
for x in [5, 60]:
    Wd = W[W.expiry_min == x].set_index("window_open")
    S = F.iloc[::10].dropna(subset=[f"wo{x}"]).copy()
    S["K"] = Wd.strike.reindex(S[f"wo{x}"]).values; S["up"] = Wd.up_won.reindex(S[f"wo{x}"]).values.astype(float)
    S = S.dropna(subset=["K", "up"])
    t_s = ((S.index - S.index.normalize()).total_seconds()).astype(int).values
    tau = ((S[f"wo{x}"] + pd.Timedelta(minutes=x)) - S.index.to_series()).dt.total_seconds().astype(int).values
    var = sig2 * (cum[t_s + tau] - cum[t_s])
    gap = (S.etf + 0.55 * (S.bsk - S.etf) * np.minimum(1, tau / 60) - S.K).values
    S["model"] = norm.cdf((gap[:, None] + noise[None, :]) / np.sqrt(var[:, None] + 1e-10)).mean(1)
    S["mkt"] = (S[f"b{x}"] + S[f"a{x}"]) / 2; S["bid"] = S[f"b{x}"]; S["ask"] = S[f"a{x}"]
    S["tau"] = tau; S["exp"] = x
    rows.append(S[["up", "model", "mkt", "bid", "ask", "tau", "exp"]])
R = pd.concat(rows)
for x in [5, 60]:
    r = R[R.exp == x]
    print(f"\nC1. {x}m  Brier score (lower=better): market {((r.mkt-r.up)**2).mean():.4f}   model {((r.model-r.up)**2).mean():.4f}")
    r = r.assign(bucket=pd.cut(r.mkt, np.linspace(0, 1, 11)))
    print("    calibration:"); print(r.groupby("bucket", observed=True)[["mkt", "model", "up"]].mean().round(3).T.to_string())
    for th in [0.02, 0.05, 0.10]:
        buy, sell = r.model - r.ask > th, r.bid - r.model > th
        pnl = np.concatenate([(r.up - r.ask)[buy], (r.bid - r.up)[sell]])
        print(f"    take when edge > {th:.2f}: {len(pnl)/len(days):5.0f} signals/day, avg PnL {pnl.mean():+.3f} per contract")

# ---------------------------------------------------------------- D. Option flow
O = pd.concat([read("option_trades", d) for d in days]); O = O[O.expiry_min != 15]
O = O.merge(W[["expiry_min", "window_open", "up_won"]], on=["expiry_min", "window_open"])
O["sign"] = np.where(O.aggressor == "buy_up", 1, -1)
O["pnl"] = O.sign * (O.up_won.astype(float) - O.price_up)
O["who"] = np.where(O["size"] == 30, "size 30", np.where(O["size"] == 10, "size 10", "other"))
print("\nD1. Option aggressors: PnL per contract and fraction buying UP")
print(O.groupby(["expiry_min", "who"]).agg(n=("pnl", "size"), pnl=("pnl", "mean"),
                                         buy_up=("sign", lambda s: (s > 0).mean())).round(3))

# ---------------------------------------------------------------- E. Market-maker rules
d = days[0]; tb = read("top_of_book", d); tr = read("trades", d)
tr["sv"] = np.where(tr.aggressor == "buy", 1, -1) * tr["size"].astype(float)
print(f"\nE1. Book is symmetric: bid_size == ask_size in {(tb.bid_size == tb.ask_size).mean():.1%} of rows")
print("E2. Mid change per second vs signed volume in that second:")
for p in PRODS:
    b = tb[tb["product"] == p].set_index("ts"); mid = (b.bid + b.ask) / 2
    sv = tr[tr["product"] == p].groupby("ts").sv.sum().reindex(b.index).fillna(0)
    dm = mid.diff(); k = dm.notna()
    lam = np.polyfit(sv[k], dm[k], 1)[0]
    print(f"  {p:13s} lambda = {lam*100:.3f}c per unit   R2 = {np.corrcoef(sv[k], dm[k])[0,1]**2:.3f}   "
          f"avg |move| in no-trade seconds {dm[k & (sv == 0)].abs().mean()*100:.3f}c")

# ---------------------------------------------------------------- F. Big moves
print("\nF1. After a >30c move within 60s: does it continue (+) or revert (-)? (cents)")
for p in PRODS:
    ev = []
    for dd in days:
        t = read("top_of_book", dd); t = t[t["product"] == p]; s = ((t.bid + t.ask) / 2).values
        r = s[60:] - s[:-60]; last = -10**9
        for i in np.where(np.abs(r) > 0.30)[0]:
            if i - last < 600 or i + 60 + 1800 >= len(s): continue
            last = i; j = i + 60; g = np.sign(r[i])
            ev.append([(s[j+60]-s[j])*g, (s[j+300]-s[j])*g, (s[j+1800]-s[j])*g])
    if ev:
        e = np.array(ev) * 100
        print(f"  {p:13s} {len(e)/len(days):5.1f}/day   next 1m {e[:,0].mean():+.1f}  5m {e[:,1].mean():+.1f}  30m {e[:,2].mean():+.1f}")
