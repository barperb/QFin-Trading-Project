"""
QFin Project - Step 1: data checks + first look at ETF vs basket.

Run from the "QFin Project" folder:
    pip install duckdb pandas
    python 01_data_checks.py            # all 182 days (slower)
    python 01_data_checks.py 7          # first 7 days only

DuckDB queries the parquet files directly, so nothing has to fit in memory.
15-minute options are excluded everywhere (dropped from the final exchange).
"""
import sys, glob, duckdb

DATA = "qfin_project_data/members/"
N_DAYS = int(sys.argv[1]) if len(sys.argv) > 1 else None

c = duckdb.connect()
for t in ["top_of_book", "trades", "option_top_of_book", "option_trades", "option_windows"]:
    files = sorted(glob.glob(f"{DATA}{t}/*.parquet"))[:N_DAYS]
    flist = ", ".join(f"'{f}'" for f in files)
    where = "where expiry_min <> 15" if t.startswith("option") else ""
    c.execute(f"create view {t} as select * from read_parquet([{flist}]) {where}")

def show(title, sql):
    print(f"\n=== {title} ===")
    print(c.sql(sql).df().to_string(index=False))

# ---------------------------------------------------------------- 1. Sanity checks
# Expect: one row per product per second, no nulls, no crossed books.
show("Order book: completeness, spreads, price range", """
select product,
       count(*)                          as rows,
       count(distinct ts)                as unique_secs,
       sum((bid is null or ask is null)::int) as null_quotes,
       sum((ask <= bid)::int)            as crossed,
       round(avg(ask - bid), 4)          as avg_spread,
       round(min((bid+ask)/2), 2)        as min_mid,
       round(max((bid+ask)/2), 2)        as max_mid,
       round(avg(bid_size), 1)           as avg_bid_size
from top_of_book group by 1 order by 1""")

# Largest gap between consecutive snapshots (should be exactly 1 second).
show("Order book: missing seconds", """
with x as (select product, ts - lag(ts) over (partition by product order by ts) as gap from top_of_book)
select product, max(gap) as max_gap, sum((gap > interval 1 second)::int) as n_gaps
from x group by 1 order by 1""")

# 'price' is an AVERAGE fill price, so it's often off the 1c grid when a trade walks levels.
show("Trades: volume, size, buy/sell balance", """
select product,
       count(*)                          as n_trades,
       round(avg(size), 1)               as avg_size,
       round(avg((aggressor = 'buy')::int), 3) as buy_frac,
       round(avg((abs(price*100 - round(price*100)) > 1e-6)::int), 3) as frac_multi_level
from trades group by 1 order by 1""")

show("Options: windows, spreads, up win-rate", """
select w.expiry_min, w.price_source, count(*) as n_windows,
       round(avg(up_won::int), 3)        as up_win_rate,
       sum((settle = strike)::int)       as n_ties
from option_windows w group by 1, 2 order by 1""")

# Brief says each window's settle = next window's strike. Verify.
show("Options: settle == next strike?", """
select expiry_min, sum((settle <> nxt)::int) as mismatches, count(*) as n
from (select *, lead(strike) over (partition by expiry_min order by window_open) as nxt
      from option_windows) where nxt is not null group by 1""")

# ---------------------------------------------------------------- 2. ETF vs basket
# Fair ETF = sum of fruits. Build per-second ETF and basket bid/ask.
c.execute("""
create table eb as
with b as (pivot (select ts, product, bid from top_of_book) on product using first(bid) group by ts),
     a as (pivot (select ts, product, ask from top_of_book) on product using first(ask) group by ts)
select b.ts,
       b.etf as etf_bid, a.etf as etf_ask,
       b.apples+b.bananas+b.oranges+b.strawberries+b.watermelon as bsk_bid,
       a.apples+a.bananas+a.oranges+a.strawberries+a.watermelon as bsk_ask
from b join a using (ts)""")
c.execute("alter table eb add column dev double")
c.execute("update eb set dev = (etf_bid+etf_ask)/2 - (bsk_bid+bsk_ask)/2")

# 'Executable' = you could cross every spread and still lock in a profit.
show("ETF vs basket: how often is there a crossable arb?", """
select round(avg(dev), 4)                              as mean_mid_dev,
       round(stddev(dev), 4)                           as sd_mid_dev,
       round(avg((etf_bid > bsk_ask)::int), 4)         as frac_secs_sell_etf_buy_fruit,
       round(avg((bsk_bid > etf_ask)::int), 4)         as frac_secs_buy_etf_sell_fruit
from eb""")

# How quickly does a mispricing die out? Autocorrelation of the deviation at each lag.
for lag in [1, 5, 15, 30, 60, 300]:
    show(f"Deviation autocorrelation, lag {lag}s",
         f"select round(corr(dev, l), 3) as ac from (select dev, lag(dev, {lag}) over (order by ts) as l from eb)")
