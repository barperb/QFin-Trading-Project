"""
fair_value.py - live fair-value estimator for the fruits (and the ETF), for use inside the bot.

MODEL (why this works: see 04_findings.md)
    Hidden fair value F_i of each fruit is a random walk:           F_i(t+1) = F_i(t) + w_i,   w ~ N(0, Q)
    The market maker's mid only moves on trades, and flow (informed bots) drags it toward F:
                                                                    mid_i(t+1) - mid_i(t) = theta_i * (F_i(t) - mid_i(t)) + noise_i
    A Kalman filter inverts this: every second it looks at how the mid moved and asks
    "how far away must fair be to explain that move?".

WHAT THE FILTER DOES IN PRACTICE (apples)
    - a +1c mid move is immediately believed ~45%;
    - if the price STAYS there, belief rises to 80% after 1 min and ~100% after 5 min;
    - if the price snaps back within 10 s, fair ends up only ~0.1c higher.
    => "a move is real only if it doesn't revert".

SLOW LAYER (hours)
    The fair values themselves are mean-reverting (half-life ~3-7 h) around long-run levels.
    Feb-Jun 2026 averages: apples 10.9, bananas 8.7, oranges 12.0, strawberries 9.7, watermelon 13.2.
    Levels drift a bit month to month and data started 1 Jan at 10 / 8 / 11 / 9 / 12, so on the live
    exchange use a trailing 24-48 h average of the mid as the anchor (LongRunAnchor below).

ETF
    - Predicting the ETF: fair_etf = sum of fruit fair values (best out-of-sample).
    - The informed ETF bot (size 30) fires on ETF vs SUM OF FRUIT MIDS, threshold ~10c.

USAGE
    fv = FairValue()                       # fitted parameters baked in
    each second:  fair = fv.update({'apples': mid, 'bananas': mid, ...})   -> dict of fair values
                  fv.gap('apples')          -> fair - mid (positive = cheap, lean bid)
"""
import numpy as np

FRUITS = ["apples", "bananas", "oranges", "strawberries", "watermelon"]

# Fitted by maximum likelihood on 1-7 Jan 2026 (1-second mids); validated on 28 other days.
THETA = np.array([0.03793, 0.03732, 0.0388, 0.03535, 0.01844])       # pull of mid toward fair, per second
Q_VAR = np.array([2.471e-05, 2.857e-05, 2.984e-05, 5.282e-05, 1.339e-04])  # fair variance per second ($^2)
R_VAR = np.array([1.212e-04, 1.193e-04, 1.184e-04, 1.240e-04, 2.787e-04])  # noise in 1-s mid changes ($^2)
# correlation of fair-value moves (30-min, from smoothed fairs). apples-oranges move together.
CORR = np.array([[1.0, -0.077, 0.654, -0.106, -0.266],
                 [-0.077, 1.0, -0.148, 0.217, -0.173],
                 [0.654, -0.148, 1.0, -0.185, -0.291],
                 [-0.106, 0.217, -0.185, 1.0, -0.083],
                 [-0.266, -0.173, -0.291, -0.083, 1.0]])


class FairValue:
    """Joint Kalman filter over the 5 fruits. Call update() once per second with the latest mids."""

    def __init__(self, use_correlation=True):
        sd = np.sqrt(Q_VAR)
        self.Q = np.outer(sd, sd) * (CORR if use_correlation else np.eye(5))
        self.H = np.diag(THETA)
        self.R = np.diag(R_VAR)
        self.F = None                 # current fair estimates (5,)
        self.P = np.eye(5) * 1e-4     # initial uncertainty (~1c)
        self.prev_mid = None
        self.mid = None

    def update(self, mids: dict) -> dict:
        m = np.array([mids[p] for p in FRUITS], dtype=float)
        if self.F is None:                       # first call: start fair at the mid
            self.F, self.prev_mid, self.mid = m.copy(), m, m
            return self.fair()
        # observation: how the mid moved over the last second, given where fair was
        y = m - self.prev_mid
        v = y - THETA * (self.F - self.prev_mid)
        S = self.H @ self.P @ self.H.T + self.R
        K = self.P @ self.H.T @ np.linalg.inv(S)
        self.F = self.F + K @ v
        self.P = (np.eye(5) - K @ self.H) @ self.P + self.Q
        self.prev_mid, self.mid = m, m
        return self.fair()

    def fair(self) -> dict:
        out = dict(zip(FRUITS, self.F))
        out["etf"] = float(self.F.sum())         # ETF fair = sum of fruit fairs
        return out

    def gap(self, product: str) -> float:
        """fair - mid. Positive -> product is cheap."""
        if product == "etf":
            raise ValueError("ETF mid is not tracked here; use fair()['etf'] - etf_mid")
        i = FRUITS.index(product)
        return float(self.F[i] - self.mid[i])

    def uncertainty(self) -> dict:
        return dict(zip(FRUITS, np.sqrt(np.diag(self.P))))


class LongRunAnchor:
    """Trailing EMA of the mid with a 24 h span (update once per second). anchor - fair = expected pull over hours."""

    def __init__(self, span_seconds=24 * 3600, start=None):
        self.alpha = 2 / (span_seconds + 1)
        self.value = dict(start) if start else None

    def update(self, mids: dict) -> dict:
        if self.value is None:
            self.value = dict(mids)
        else:
            for p, m in mids.items():
                self.value[p] += self.alpha * (m - self.value[p])
        return self.value


if __name__ == "__main__":
    # tiny demo: a mid that jumps +1c and stays vs one that jumps and reverts
    fv = FairValue(use_correlation=False)
    base = {p: 10.0 for p in FRUITS}
    for _ in range(600): fv.update(base)
    jumped = dict(base, apples=10.01)
    print("apples fair after a +1c move that sticks:")
    for s in range(301):
        f = fv.update(jumped)
        if s in (0, 10, 60, 300): print(f"  +{s:3d}s  fair - 10 = {100*(f['apples']-10):.2f}c")
