"""
QFin Project - Step 4: estimating hidden fair values with a Kalman filter.

Run from the "QFin Project" folder:
    pip install pandas pyarrow numpy scipy numba
    python 04_fair_value.py          # fit on first 7 days, test on every 6th day after
    python 04_fair_value.py 12       # test on every 12th day (faster)

What it does
  1. Fits a 2-state model per product by maximum likelihood (first 7 contiguous days):
        fair F:  random walk, variance q per second
        mid:     mid(t+1) - mid(t) = theta * (F(t) - mid(t)) + noise (variance r)
  2. Shows what the filter does: response of estimated fair to a price move that sticks vs one that reverts.
  3. Out-of-sample test: which "fair value" candidate best predicts where the mid goes?
        mid, EMAs, univariate Kalman, joint Kalman (fruits share correlated fair moves),
        and for the ETF: basket mid (sum of fruit mids) and sum of fruit Kalman fairs.
     A true fair value should (a) have the highest R^2 and (b) a slope ~1 at long horizons.
  4. What does the informed ETF bot (size 30) react to: basket MID or basket FAIR?
"""
import sys, glob, os
import numpy as np, pandas as pd
from numba import njit
from scipy.optimize import minimize

D = "qfin_project_data/members/"
FRUITS = ["apples", "bananas", "oranges", "strawberries", "watermelon"]
PRODS = FRUITS + ["etf"]
STEP = int(sys.argv[1]) if len(sys.argv) > 1 else 6
pd.set_option("display.width", 250)

all_days = sorted(os.path.basename(f)[5:15] for f in glob.glob(D + "top_of_book/*.parquet"))[:-1]
train_days, test_days = all_days[:7], all_days[7:][::STEP]

def mids(day):
    tb = pd.read_parquet(f"{D}top_of_book/date={day}.parquet")
    tb["mid"] = (tb.bid + tb.ask) / 2
    return tb.pivot(index="ts", columns="product", values="mid")[PRODS]

# ---------------------------------------------------------------- filters
@njit(cache=True)
def kf(mid, theta, q, r, P0):
    """Univariate filter. Returns fair estimate F(t|t) and log-likelihood."""
    n = len(mid); out = np.empty(n); F = mid[0]; P = P0; ll = 0.0; out[0] = F
    for t in range(n - 1):
        v = (mid[t + 1] - mid[t]) - theta * (F - mid[t])      # surprise in the mid move
        S = theta * theta * P + r
        K = P * theta / S
        F += K * v; P -= K * theta * P                        # update belief about fair
        ll += -0.5 * (np.log(2 * np.pi * S) + v * v / S)
        P += q                                                # fair drifts before next second
        out[t + 1] = F
    return out, ll

@njit(cache=True)
def kf_joint(X, theta, Q, r):
    """5 fruits jointly; fair moves are correlated through Q (apples & oranges)."""
    n = X.shape[0]; F = X[0].copy(); P = np.eye(5) * 1e-4; out = np.empty((n, 5)); out[0] = F
    H = np.diag(theta); R = np.diag(r); I = np.eye(5)
    for t in range(n - 1):
        v = (X[t + 1] - X[t]) - theta * (F - X[t])
        S = H @ P @ H.T + R
        K = P @ H.T @ np.linalg.inv(S)
        F = F + K @ v; P = (I - K @ H) @ P + Q
        out[t + 1] = F
    return out

@njit(cache=True)
def kf_smooth(mid, theta, q, r):
    """Two-sided (uses the future) - NOT tradable, only to study what the fair path looks like."""
    n = len(mid); Ff = np.empty(n); Pf = np.empty(n); F = mid[0]; P = 1e-4
    for t in range(n):
        if t < n - 1:
            v = (mid[t + 1] - mid[t]) - theta * (F - mid[t]); S = theta * theta * P + r
            K = P * theta / S; F += K * v; P -= K * theta * P
        Ff[t] = F; Pf[t] = P; P += q
    Fs = Ff.copy()
    for t in range(n - 2, -1, -1):
        Fs[t] = Ff[t] + Pf[t] / (Pf[t] + q) * (Fs[t + 1] - Ff[t])
    return Fs

# ---------------------------------------------------------------- 1. fit
train = pd.concat([mids(d) for d in train_days])
fits = {}
print("1. Maximum-likelihood fit (train = first 7 contiguous days)")
for p in PRODS:
    x = train[p].values
    nll = lambda a: 1e12 if not 0 < a[0] < 1 else -kf(x, a[0], np.exp(a[1]), np.exp(a[2]), 1e-4)[1]
    best = min((minimize(nll, [t0, np.log(1e-6), np.log(1e-5)], method="Nelder-Mead",
                         options=dict(maxiter=400)) for t0 in [0.002, 0.01, 0.05]), key=lambda r: r.fun)
    th, q, r = best.x[0], np.exp(best.x[1]), np.exp(best.x[2])
    fits[p] = (th, q, r)
    print(f"  {p:13s} theta {th:.4f}/s (mid half-life to fair {np.log(2)/th:4.0f}s)  "
          f"fair vol {np.sqrt(q)*100:.2f}c/sqrt(s) (= {np.sqrt(q*86400):.2f} $/day)  noise {np.sqrt(r)*100:.2f}c")

# joint-model covariance: correlation of 30-min moves of the SMOOTHED fair values
Fs = pd.DataFrame({p: kf_smooth(train[p].values, *fits[p]) for p in FRUITS}, index=train.index)
C = Fs.iloc[::1800].diff().dropna().corr().values
sd = np.sqrt([fits[p][1] for p in FRUITS]); Q = np.outer(sd, sd) * C
thJ = np.array([fits[p][0] for p in FRUITS]); rJ = np.array([fits[p][2] for p in FRUITS])
print("\n  Correlation of fair-value moves (smoothed, 30 min):")
print(pd.DataFrame(C, index=FRUITS, columns=FRUITS).round(2).to_string())
print(f"  Smoothed oranges_fair - apples_fair: mean {(Fs.oranges-Fs.apples).mean():.3f}, sd {(Fs.oranges-Fs.apples).std():.3f}")

# ---------------------------------------------------------------- 2. what the filter does
print("\n2. Filter response (apples): mid jumps +1c ...")
th, q, r = fits["apples"]
stick = np.r_[np.zeros(600), np.full(600, 0.01)]; flick = np.r_[np.zeros(600), np.full(10, 0.01), np.zeros(590)]
a, _ = kf(stick, th, q, r, 1e-4); b, _ = kf(flick, th, q, r, 1e-4)
for s in [0, 10, 60, 300]:
    print(f"  after {s:3d}s: ...and stays -> fair +{a[600+s]*100:.2f}c   |  ...reverts after 10s -> fair +{b[600+s]*100:.2f}c")

# ---------------------------------------------------------------- 3. out-of-sample test
print(f"\n3. Out-of-sample on {len(test_days)} days. Predict mid(t+h)-mid(t) with (candidate - mid), no fitting.")
H = [30, 60, 300, 1800]; acc = {}
for d in test_days:
    m = mids(d)
    U = np.column_stack([kf(m[p].values, *fits[p], 1e-4)[0] for p in FRUITS])
    Jt = kf_joint(m[FRUITS].values, thJ, Q, rJ)
    for i, p in enumerate(PRODS):
        x = m[p].values
        c = {"mid": x, "ema30": m[p].ewm(span=30).mean().values, "ema120": m[p].ewm(span=120).mean().values}
        if p == "etf":
            c["basket_mid"] = m[FRUITS].sum(axis=1).values
            c["sum_fruit_kalman"] = U.sum(1); c["sum_fruit_joint"] = Jt.sum(1)
            c["etf_own_kalman"] = kf(x, *fits["etf"], 1e-4)[0]
        else:
            c["kalman"] = U[:, i]; c["joint_kalman"] = Jt[:, i]
        for name, v in c.items():
            for h in H:
                y = np.r_[x[h:] - x[:-h], np.full(h, np.nan)]; sl = slice(3600, len(x) - h, 5)
                acc.setdefault((p, name, h), ([], [])); acc[(p, name, h)][0].append((v - x)[sl]); acc[(p, name, h)][1].append(y[sl])
rows = []
for (p, name, h), (g, y) in acc.items():
    g, y = np.concatenate(g), np.concatenate(y)
    rows.append(dict(product=p, cand=name, h=h, R2=1 - np.mean((y - g) ** 2) / np.mean(y ** 2),
                     slope=np.dot(g, y) / np.dot(g, g) if np.dot(g, g) > 0 else np.nan))
R = pd.DataFrame(rows)
print("  R^2 (higher = better fair value; 0 = no better than 'fair = mid')")
print(R.pivot_table(index=["product", "cand"], columns="h", values="R2").round(3).to_string())
print("\n  Slope (true fair value -> ~1 at long horizons)")
print(R.pivot_table(index=["product", "cand"], columns="h", values="slope").round(2).to_string())

# ---------------------------------------------------------------- 4. ETF bot trigger
print("\n4. Chance of a size-30 ETF trade in the next second, by |gap| (cents)")
hz = []
for d in test_days[:4]:
    m = mids(d); tr = pd.read_parquet(f"{D}trades/date={d}.parquet")
    hits = set(tr[(tr["product"] == "etf") & (tr["size"] == 30)].ts)
    U = np.column_stack([kf(m[p].values, *fits[p], 1e-4)[0] for p in FRUITS])
    g = pd.DataFrame({"basket_mid": (m[FRUITS].sum(axis=1) - m.etf).values * 100,
                      "sum_fruit_fair": (U.sum(1) - m.etf.values) * 100}, index=m.index).shift(1)
    g["hit"] = g.index.isin(hits); hz.append(g.iloc[3600:])
hz = pd.concat(hz)
for c in ["basket_mid", "sum_fruit_fair"]:
    b = pd.cut(hz[c].abs(), [0, 5, 8, 10, 12, 15, 20, 30, 100])
    print(f"  gap vs {c:15s}", hz.groupby(b, observed=True).hit.mean().round(3).values)
