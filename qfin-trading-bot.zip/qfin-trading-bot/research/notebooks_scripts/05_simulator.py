"""
QFin Project - Step 5: replay simulator for the main strategies, scored like the competition.

Run from the "QFin Project" folder:
    pip install pandas pyarrow numpy scipy numba
    python 05_simulator.py           # every 6th day (~30 days)
    python 05_simulator.py 12        # every 12th day (faster)

Strategies
  A. Fruit + ETF market making: quote 1c inside the market maker, size Q, centred on the mid or the Kalman fair,
     leaning against inventory. Historical aggressor trades fill against us first when our price is strictly better.
  B. 5m / 60m up-down options: take when model differs from the touch by > threshold, cap position per window.
     Optional settle-second nudge: if our ETF 1-lot can flip the result (and nobody else trades that second), do it.
  C. Stress test: same market making with RANDOM order flow (signs shuffled, market maker price rebuilt from the
     0.06c/0.09c/0.19c-per-unit rule) -> what survives if the live exchange has no informed flow.

Score = mean daily PnL - sd of daily PnL.

BIG CAVEATS (read before trusting $ numbers)
  - The market maker's historical price path is replayed unchanged, i.e. it ignores that if flow trades with us
    instead of the market maker, its price would move less. Other teams compete for the same flow.
  - The option model assumes the option market maker doesn't react to our trades and refreshes 50 lots.
  - So treat absolute $ as an UPPER BOUND; the comparisons between variants are the useful part.
"""
import sys, glob, os
import numpy as np, pandas as pd
from numba import njit
from scipy.stats import norm

D = "qfin_project_data/members/"
FRUITS = ["apples", "bananas", "oranges", "strawberries", "watermelon"]
PRODS = FRUITS + ["etf"]
STEP = int(sys.argv[1]) if len(sys.argv) > 1 else 6
LAMBDA = {"apples": 0.0006, "bananas": 0.0006, "oranges": 0.0006, "strawberries": 0.0006,
          "watermelon": 0.0009, "etf": 0.0019}              # $ per unit traded (step 3)
KF = {"apples": (0.03793, 2.471e-05, 1.212e-04), "bananas": (0.03732, 2.857e-05, 1.193e-04),
      "oranges": (0.0388, 2.984e-05, 1.184e-04), "strawberries": (0.03535, 5.282e-05, 1.240e-04),
      "watermelon": (0.01844, 1.339e-04, 2.787e-04)}       # (theta, q, r) from step 4
pd.set_option("display.width", 250)

days = sorted(os.path.basename(f)[5:15] for f in glob.glob(D + "top_of_book/*.parquet"))[:-1][::STEP]
print(f"Simulating {len(days)} days")

@njit(cache=True)
def kalman(mid, theta, q, r):
    n = len(mid); out = np.empty(n); F = mid[0]; P = 1e-4; out[0] = F
    for t in range(n - 1):
        v = (mid[t + 1] - mid[t]) - theta * (F - mid[t]); S = theta * theta * P + r
        K = P * theta / S; F += K * v; P = P - K * theta * P + q; out[t + 1] = F
    return out

@njit(cache=True)
def mm_day(bid, ask, center, tsec, tsign, tsize, Q, h, skew, maxinv):
    """One day of market making. Returns (pnl marked to final mid, units traded, max |inventory|)."""
    tick = 0.01; n = len(bid); inv = 0.0; cash = 0.0; j = 0; m = len(tsec); vol = 0.0; mx = 0.0
    for t in range(1, n):
        c = center[t - 1] - skew * inv                           # lean against inventory
        b = np.floor((c - h) / tick + 1e-9) * tick; a = np.ceil((c + h) / tick - 1e-9) * tick
        b = min(b, ask[t - 1] - tick); a = max(a, bid[t - 1] + tick)  # never cross the market
        qb = Q if inv < maxinv else 0.0; qa = Q if inv > -maxinv else 0.0
        while j < m and tsec[j] < t: j += 1
        while j < m and tsec[j] == t:
            if tsign[j] > 0 and a < ask[t - 1] - 1e-9 and qa > 0:     # buyer hits our better ask
                f = min(qa, tsize[j]); qa -= f; inv -= f; cash += f * a; vol += f
            elif tsign[j] < 0 and b > bid[t - 1] + 1e-9 and qb > 0:   # seller hits our better bid
                f = min(qb, tsize[j]); qb -= f; inv += f; cash -= f * b; vol += f
            j += 1
        mx = max(mx, abs(inv))
    return cash + inv * (bid[n - 1] + ask[n - 1]) / 2, vol, mx

def load_day(d):
    tb = pd.read_parquet(f"{D}top_of_book/date={d}.parquet"); tr = pd.read_parquet(f"{D}trades/date={d}.parquet")
    out = {}
    for p in PRODS:
        b = tb[tb["product"] == p].set_index("ts"); t = tr[tr["product"] == p]
        out[p] = dict(bid=b.bid.values.copy(), ask=b.ask.values.copy(), idx=b.index,
                      tsec=((t.ts - b.index[0]).dt.total_seconds()).astype(np.int64).values,
                      sign=np.where(t.aggressor == "buy", 1.0, -1.0), size=t["size"].values.astype(float))
    return out

def randomise(x, p, rng):
    """Random-flow world: shuffle trade directions, rebuild the market maker's price from its lambda rule."""
    sign = rng.choice([-1.0, 1.0], len(x["sign"]))
    sv = np.bincount(x["tsec"], weights=sign * x["size"], minlength=len(x["bid"]))[:len(x["bid"])]
    mid = (x["bid"][0] + x["ask"][0]) / 2 + LAMBDA[p] * np.cumsum(sv); half = np.median(x["ask"] - x["bid"]) / 2
    return dict(x, sign=sign, bid=np.round((mid - half) * 100) / 100, ask=np.round((mid + half) * 100) / 100)

# ---------------------------------------------------------------- A + C. market making
rows = []; rng = np.random.default_rng(0)
for d in days:
    data = load_day(d)
    for world in ["historical", "random_flow"]:
        X = data if world == "historical" else {p: randomise(data[p], p, rng) for p in PRODS}
        fair = {p: kalman((X[p]["bid"] + X[p]["ask"]) / 2, *KF[p]) for p in FRUITS}
        for p in PRODS:
            x = X[p]; mid = (x["bid"] + x["ask"]) / 2
            if p == "etf":
                centres = {"mid": mid, "kalman": sum(fair.values())}; prm = (5.0, 0.05, 0.002, 50.0)
            else:
                centres = {"mid": mid, "kalman": fair[p]}; prm = (20.0, 0.02, 0.0003, 300.0)
            for mode, c in centres.items():
                pnl, vol, mx = mm_day(x["bid"], x["ask"], c, x["tsec"], x["sign"], x["size"], *prm)
                rows.append(dict(day=d, world=world, product=p, centre=mode, pnl=pnl, units=vol, max_inv=mx))
MM = pd.DataFrame(rows)
print("\nA/C. Market making: daily $ (score = mean - sd)")
g = MM.groupby(["world", "product", "centre"]).agg(mean=("pnl", "mean"), sd=("pnl", "std"), units=("units", "mean"))
g["score"] = g["mean"] - g["sd"]; print(g.round(0).to_string())

# ---------------------------------------------------------------- B. options
W = pd.concat([pd.read_parquet(f) for f in sorted(glob.glob(D + "option_windows/*.parquet"))])
W = W[(W.expiry_min != 15) & (W.settle > 0)]
panel = []
for d in days:
    tb = pd.read_parquet(f"{D}top_of_book/date={d}.parquet"); tb["mid"] = (tb.bid + tb.ask) / 2
    m = tb.pivot(index="ts", columns="product", values="mid"); eb = tb[tb["product"] == "etf"].set_index("ts")
    tr = pd.read_parquet(f"{D}trades/date={d}.parquet"); e = tr[tr["product"] == "etf"]
    f = pd.DataFrame({"etf": m.etf, "bsk": m[FRUITS].sum(axis=1), "ebid": eb.bid, "eask": eb.ask})
    f["last"] = e.groupby("ts").price.last().reindex(m.index).ffill()
    f["etf_trade"] = m.index.isin(set(e.ts))
    ob = pd.read_parquet(f"{D}option_top_of_book/date={d}.parquet")
    for x in [5, 60]:
        o = ob[ob.expiry_min == x].set_index("ts"); g2 = f.copy()
        g2["bid"], g2["ask"], g2["wo"], g2["exp"] = o.bid, o.ask, o.window_open, x
        panel.append(g2)
Pn = pd.concat(panel).dropna(subset=["wo", "bid", "ask"])
noise = np.quantile((Pn["last"] - Pn["etf"]).dropna(), np.linspace(0.02, 0.98, 25))
d1 = Pn.groupby([Pn.index.date, "exp"]).etf.diff(300)
sig2 = d1[Pn.exp == 5].var() / 300
v = Pn[Pn.exp == 5].groupby(Pn[Pn.exp == 5].index.date).etf.diff() ** 2
w_min = (v.groupby(v.index.minute).mean() / v.mean()).values; w_hr = (v.groupby(v.index.hour).mean() / v.mean()).values
secw = np.array([w_min[(s // 60) % 60] * w_hr[s // 3600] for s in range(86400)]); secw /= secw.mean()
cum = np.concatenate([[0], np.cumsum(np.tile(secw, 2))])

def option_sim(exp, th=0.05, nmax=50, nudge=False, sample=2):
    q = Pn[Pn.exp == exp].iloc[::sample]; Wd = W[W.expiry_min == exp].set_index("window_open")
    q = q[q.wo.isin(Wd.index)]
    K = Wd.strike.reindex(q.wo).values
    t_s = ((q.index - q.index.normalize()).total_seconds()).astype(int).values
    tau = ((q.wo + pd.Timedelta(minutes=exp)) - q.index.to_series()).dt.total_seconds().astype(int).values
    var = sig2 * (cum[t_s + tau] - cum[t_s]); gap = (q.etf + 0.55 * (q.bsk - q.etf) * np.minimum(1, tau / 60) - K).values
    model = norm.cdf((gap[:, None] + noise[None, :]) / np.sqrt(var[:, None] + 1e-10)).mean(1)
    q = q.assign(model=model)
    closes = Pn[Pn.exp == exp][["ebid", "eask", "etf_trade"]]; closes = closes[~closes.index.duplicated()]
    out = []
    for wo, g3 in q.groupby("wo"):
        pos = 0; cash = 0.0; n_tr = 0
        for mo, a, b in zip(g3.model.values, g3.ask.values, g3.bid.values):
            if mo - a > th and pos < nmax: n = nmax - pos; cash -= n * a; pos += n; n_tr += n
            elif b - mo > th and pos > -nmax: n = nmax + pos; cash += n * b; pos -= n; n_tr += n
        up = bool(Wd.at[wo, "up_won"]); k = Wd.at[wo, "strike"]; cost = 0.0
        close = wo + pd.Timedelta(minutes=exp)
        if nudge and pos != 0 and close in closes.index and not closes.at[close, "etf_trade"]:
            want_up = pos > 0
            new_up = (closes.at[close, "eask"] if want_up else closes.at[close, "ebid"]) >= k
            if new_up == want_up: up = new_up; cost = 0.15        # cross ETF spread now, unwind later
        out.append(dict(day=str(wo.date()), pnl=cash + pos * float(up) - cost, contracts=n_tr))
    r = pd.DataFrame(out).groupby("day").agg(pnl=("pnl", "sum"), contracts=("contracts", "sum"))
    return r

print("\nB. Options: take when |model - touch| > 5c, max 50 contracts per window")
OPT = {}
for exp in [5, 60]:
    for nudge in [False, True]:
        r = option_sim(exp, nudge=nudge); OPT[(exp, nudge)] = r.pnl
        print(f"  {exp:2d}m nudge={str(nudge):5s}: mean ${r.pnl.mean():7.0f}  sd ${r.pnl.std():5.0f}  "
              f"score ${r.pnl.mean()-r.pnl.std():7.0f}  contracts/day {r.contracts.mean():6.0f}")

# ---------------------------------------------------------------- combined
H = MM[(MM.world == "historical") & (MM.centre == "kalman")].pivot(index="day", columns="product", values="pnl")
C = pd.DataFrame({"options_5m": OPT[(5, True)], "options_60m": OPT[(60, False)],
                  "fruit_mm": H[FRUITS].sum(axis=1), "etf_mm": H["etf"]}).dropna()
print("\nCorrelation of daily PnL between strategies"); print(C.corr().round(2))
tot = C.sum(axis=1)
print(f"Combined: mean ${tot.mean():.0f}  sd ${tot.std():.0f}  score ${tot.mean()-tot.std():.0f}  "
      f"(sum of separate scores ${sum(C[c].mean()-C[c].std() for c in C):.0f})")
