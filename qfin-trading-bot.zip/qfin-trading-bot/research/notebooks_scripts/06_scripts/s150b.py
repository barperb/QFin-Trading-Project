import pandas as pd,glob,numpy as np
def run(kind):
    if kind=='live':
        T=pd.concat([pd.read_parquet(f) for f in sorted(glob.glob('1*data/trades_*.parquet'))]); B=pd.concat([pd.read_parquet(f) for f in sorted(glob.glob('1*data/top_of_book_*.parquet'))])
    else:
        tf=sorted(glob.glob('members/top_of_book/*.parquet')); days=[f.split('=')[1][:10] for f in tf]
        B=pd.concat([pd.read_parquet(f) for f in tf]); T=pd.concat([pd.read_parquet(f'members/trades/date={d}.parquet') for d in days])
    nd=T.ts.dt.date.nunique(); res=[]
    for p in ['apples','bananas','oranges','strawberries','watermelon']:
        m=B[B['product']==p].drop_duplicates('ts',keep='last').sort_values('ts'); mi=m.ts.astype('int64').values//10**9
        mid=((m.bid+m.ask)/2).values; bid=m.bid.values; ask=m.ask.values
        def at(arr,t): i=np.clip(np.searchsorted(mi,t,side='right')-1,0,len(mi)-1); return arr[i]
        t=T[(T['product']==p)&(T['size']==150)]
        for side,sg in [('buy',1),('sell',-1)]:
            x=t[t.aggressor==side].ts.astype('int64').values//10**9
            if len(x)<5: continue
            r={'kind':kind,'product':p,'side':side,'n/day':len(x)/nd,'pre':((at(mid,x)-at(mid,x-1))*sg*100).mean()}
            for d in [1,2]:
                e=at(ask if sg>0 else bid,x+d)
                for h in [60,300]:
                    pnl=(at(mid,x+h)-e)*sg*100; r[f'take d{d} h{h}']=pnl.mean()
            r['hit d1 h60']=((at(mid,x+60)-at(ask if sg>0 else bid,x+1))*sg>0).mean()
            res.append(r)
    return pd.DataFrame(res)
pd.set_option('display.width',200)
print(pd.concat([run('hist'),run('live')]).round(2).to_string())
