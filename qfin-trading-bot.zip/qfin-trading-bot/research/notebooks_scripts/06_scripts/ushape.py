import pandas as pd,glob,numpy as np
H=pd.concat([pd.read_parquet(f) for f in sorted(glob.glob('members/trades/*.parquet'))])
L=pd.concat([pd.read_parquet(f) for f in sorted(glob.glob('1*data/trades_*.parquet'))])
out={}
for nm,T in [('hist',H),('live',L)]:
    T=T.copy(); T['min']=T.ts.dt.minute; T['hr']=T.ts.dt.hour
    nd=T.ts.dt.floor('h').nunique()  # hours observed
    v=T.groupby('min')['size'].sum(); out[nm+'_vol_min']=v/v.mean()
    hrs=T.groupby('hr').ts.apply(lambda x:x.dt.floor('h').nunique())
    vh=T.groupby('hr')['size'].sum()/hrs; out[nm+'_vol_hr']=vh/vh.mean()
    s=T[(T['product']=='strawberries')&(T['size']==150)&(T.aggressor=='buy')]
    out[nm+'_s150_min']=s.groupby(s.ts.dt.minute//5*5).size()
    out[nm+'_s150_hr']=s.groupby(s.ts.dt.hour).size()/hrs
    print(nm,'hours observed',T.ts.dt.floor('h').nunique(), 'hours by hr',hrs.to_dict() if nm=='live' else '')
pd.set_option('display.width',250)
a=pd.DataFrame({k:v for k,v in out.items() if k.endswith('vol_min')}); print((a.groupby(a.index//5*5).mean()).round(2).T.to_string())
b=pd.DataFrame({k:v for k,v in out.items() if k.endswith('vol_hr')}); print(b.round(2).T.to_string())
print(pd.DataFrame({k:v for k,v in out.items() if 's150_min' in k}).T.to_string())
print(pd.DataFrame({k:v for k,v in out.items() if 's150_hr' in k}).round(2).T.to_string())
pd.concat({'hist':out['hist_vol_min'],'live':out['live_vol_min']},axis=1).to_csv('./06_work/ushape_min.csv')
pd.concat({'hist':out['hist_vol_hr'],'live':out['live_vol_hr']},axis=1).to_csv('./06_work/ushape_hr.csv')
