# Step 6 scripts
Run each from the `qfin_project_data` folder, e.g. `python ../06_scripts/runs.py hist 100`.
Intermediate files go to `qfin_project_data/06_work/` (create it first). Charts are written to `charts/`.
Order: opt1.py (option move moments), runs.py (hist/live, 80/100) -> s150b.py -> ushape.py -> panel.py -> fit.py, fit2.py, sim.py -> charts.py, chart23.py.
Historical tick results use 15 days of top_of_book (every 12th day); trade-only results use 31 days (every 6th day).
