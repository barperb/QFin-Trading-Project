import pandas as pd,glob,numpy as np,json
from scipy import stats
P=json.load(open('../bot/option_params.json'))
W=pd.concat([pd.read_parquet(f) for f in sorted(glob.glob('members/option_windows/*.parquet'))]); W['kind']='hist'
WL=pd.concat([pd.read_parquet(f) for f in sorted(glob.glob('1*data/option_windows_*.parquet'))]).drop_duplicates(['expiry_min','window_open']); WL['kind']='live'
# reconstruct from 31 days of trades
T=pd.concat([pd.read_parquet(f) for f in sorted(glob.glob('members/trades/*.parquet'))]); e=T[T['product']=='etf'].sort_values('ts')
last=e.groupby('ts').price.last()
rows=[]
for em in [5,60]:
    grid=pd.date_range(last.index.min().floor('D'),last.index.max().ceil('D'),freq=f'{em}min')
    idx=last.index.searchsorted(grid,side='right')-1  # last trade at or before boundary second
    px=pd.Series(np.where(idx>=0,last.values[np.clip(idx,0,None)],np.nan),index=grid)
    d=pd.DataFrame({'window_open':grid[:-1],'strike':px.values[:-1],'settle':px.values[1:]}); d['expiry_min']=em
    d=d[d.window_open.dt.date.isin(set(last.index.date))]
    rows.append(d)
R=pd.concat(rows); R['kind']='hist31'
# validate reconstruct vs option_windows
m=R.merge(W,on=['expiry_min','window_open'],suffixes=('','_w'))
print('reconstruct check: n',len(m),'max |strike diff|',(m.strike-m.strike_w).abs().quantile([.5,.99,1]).round(4).to_dict(),'settle',(m.settle-m.settle_w).abs().quantile([.5,.99]).round(4).to_dict())
def sdprof(wo,em):
    # expected variance multiplier: average minute mult over window * hour mult
    mm=np.array(P['minute_var_mult']); hm=np.array(P['hour_var_mult'])
    out=[]
    for t in wo:
        mins=[(t+pd.Timedelta(minutes=k)) for k in range(em)]
        out.append(np.mean([mm[x.minute]*hm[x.hour] for x in mins]))
    return np.sqrt(np.array(out))
res=[]
for nm,D in [('hist (31 days)',R),('live (Oct 8-9)',WL)]:
    for em in [5,60]:
        d=D[D.expiry_min==em].dropna().copy()
        x=(d.settle-d.strike)*100
        z=x/sdprof(d.window_open,em)
        for lab,v in [('raw c',x),('vol-adjusted',z)]:
            res.append({'sample':nm,'expiry':em,'series':lab,'n':len(v),'mean':v.mean(),'sd':v.std(),'skew':stats.skew(v),'exkurt':stats.kurtosis(v),
                        'P(up)':(v>=0).mean(),'median':v.median(),'p1':v.quantile(.01),'p99':v.quantile(.99),
                        'JB p':stats.jarque_bera(v).pvalue})
        if nm.startswith('hist'): d['x']=x.values; d['z']=z.values; d.to_parquet(f'./06_work/ret_{em}.parquet')
pd.set_option('display.width',250)
print(pd.DataFrame(res).round(3).to_string())

# drop windows opening at 00:00 UTC: with every-6th-day sampling their strike comes from a day that isn't loaded
for em in [5,60]:
    d=pd.read_parquet(f'./06_work/ret_{em}.parquet')
    d=d[~((d.window_open.dt.hour==0)&(d.window_open.dt.minute==0))]
    d.to_parquet(f'./06_work/ret_{em}_clean.parquet')
    v=d.z.values; print(em,'clean: skew',round(stats.skew(v),3),'exkurt',round(stats.kurtosis(v),3),'P(up)',round((v>=0).mean(),3))
