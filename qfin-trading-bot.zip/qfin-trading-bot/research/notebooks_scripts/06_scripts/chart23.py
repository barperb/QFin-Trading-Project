import pandas as pd,numpy as np,json,matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy import stats
exec(open('../06_scripts/fit.py').read().split("pd.set_option")[0])
X=X.dropna(subset=['bid','ask'])
C=['#2a78d6','#eb6834','#1baf7a','#eda100']; INK='#0b0b0b'; INK2='#52514e'; GRID='#e4e3df'
plt.rcParams.update({'font.size':10,'axes.edgecolor':INK2,'axes.labelcolor':INK2,'xtick.color':INK2,'ytick.color':INK2,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.color':GRID,'grid.linewidth':0.6,'figure.facecolor':'#fcfcfb','axes.facecolor':'#fcfcfb','lines.linewidth':2})
fig,ax=plt.subplots(1,4,figsize=(17,4.4))
d=pd.read_parquet('./06_work/ret_5_clean.parquet'); zs=((d.z-d.z.mean())/d.z.std()).values
bins=np.linspace(-5,5,51); ax[0].hist(zs,bins=bins,density=True,color=C[0],alpha=0.85,label='5m ETF move, vol-adjusted')
xx=np.linspace(-5,5,300); ax[0].plot(xx,stats.norm.pdf(xx),color=C[1],label='normal'); ax[0].set_yscale('log'); ax[0].set_ylim(1e-4,1)
ax[0].set_title(f'5m moves: skew {stats.skew(zs):.2f}, excess kurt {stats.kurtosis(zs):.2f}',loc='left',color=INK,fontsize=11); ax[0].set_xlabel('standardised move (sd)'); ax[0].legend(frameon=False,fontsize=9)
bins=np.r_[-3,-2,-1.5,-1.0,-0.6,-0.3,-0.1,0.1,0.3,0.6,1.0,1.5,2,3]
for i,(kind,em,tt) in enumerate([('hist',5,'5m historical'),('hist',60,'60m historical'),('live',5,'5m live Oct 8–9')]):
    s=X[(X.kind==kind)&(X.expiry_min==em)&(X.z.between(-3,3))].copy(); s['b']=pd.cut(s.z,bins)
    s['pn']=price(s.gap.values,s.sd.values)
    g=s.groupby('b',observed=True).agg(z=('z','mean'),real=('y','mean'),mkt=('q','mean'),pn=('pn','mean'))
    a=ax[i+1]
    a.plot(g.z,g.real-g.mkt,'-o',ms=4,color=C[0],label='realised − market quote')
    a.plot(g.z,g.pn-g.mkt,'-',color=C[2],label='normal+settle-noise model − market')
    a.axhline(0,color=INK2,lw=0.8); a.set_ylim(-0.25,0.25); a.set_xlabel('moneyness z = (ETF − strike) / remaining sd')
    a.set_title(tt,loc='left',color=INK,fontsize=11)
    if i==0: a.set_ylabel('P(up) gap (×100 = cents)'); a.legend(frameon=False,fontsize=9)
fig.tight_layout(); fig.savefig('../charts/23_option_skew_kurtosis.png',dpi=130)
