import pandas as pd,glob,numpy as np,json
P=json.load(open('../bot/option_params.json'))
mm=np.array(P['minute_var_mult']); hm=np.array(P['hour_var_mult']); sig=P['sigma_per_sqrt_s']
sod=np.arange(86400); varps=sig**2*mm[(sod//60)%60]*hm[sod//3600]
cum=np.r_[0,np.cumsum(np.r_[varps,varps])]  # two days to wrap
def remvar(t_sod,tau): return cum[t_sod+tau]-cum[t_sod]
def build(kind):
    if kind=='hist':
        days=[f.split('=')[1][:10] for f in sorted(glob.glob('members/option_top_of_book/*.parquet'))]
        O=pd.concat([pd.read_parquet(f'members/option_top_of_book/date={d}.parquet') for d in days])
        W=pd.concat([pd.read_parquet(f'members/option_windows/date={d}.parquet') for d in days])
        B=pd.concat([pd.read_parquet(f'members/top_of_book/date={d}.parquet') for d in days])
    else:
        O=pd.concat([pd.read_parquet(f) for f in sorted(glob.glob('1*data/option_top_of_book_*.parquet'))]).drop_duplicates()
        W=pd.concat([pd.read_parquet(f) for f in sorted(glob.glob('1*data/option_windows_*.parquet'))]).drop_duplicates(['expiry_min','window_open'])
        B=pd.concat([pd.read_parquet(f) for f in sorted(glob.glob('1*data/top_of_book_*.parquet'))]).drop_duplicates()
    e=B[B['product']=='etf'].drop_duplicates('ts',keep='last').sort_values('ts')
    ei=e.ts.astype('int64').values//10**9; emid=((e.bid+e.ask)/2).values
    O=O.merge(W,on=['expiry_min','window_open'],how='inner')
    O['t']=O.ts.astype('int64')//10**9
    O=O[O.t%5==0]
    O['close']=O.window_open.astype('int64')//10**9+O.expiry_min*60
    O['tau']=O.close-O.t
    O=O[(O.tau>0)&(O.tau<=O.expiry_min*60)]
    i=np.clip(np.searchsorted(ei,O.t.values,side='right')-1,0,None)
    O['etf']=emid[i]
    O['sd']=np.sqrt(remvar((O.t%86400).values,O.tau.values))
    O['gap']=O.etf-O.strike
    O['z']=O.gap/O.sd
    O['q']=(O.bid+O.ask)/2
    O['y']=O.up_won.astype(float)
    O['reset']=(O.window_open.dt.hour==0)&(O.window_open.dt.minute==0)
    O['kind']=kind
    return O[['ts','kind','expiry_min','window_open','tau','strike','etf','gap','sd','z','bid','ask','q','y','reset','settle']]
X=pd.concat([build('hist'),build('live')]); X.to_parquet('./06_work/panel.parquet'); print(X.groupby(['kind','expiry_min']).size())
