import pandas as pd,glob,numpy as np,matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy import stats
C=['#2a78d6','#eb6834','#1baf7a','#eda100']; INK='#0b0b0b'; INK2='#52514e'; GRID='#e4e3df'
plt.rcParams.update({'font.size':10,'axes.edgecolor':INK2,'axes.labelcolor':INK2,'xtick.color':INK2,'ytick.color':INK2,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.color':GRID,'grid.linewidth':0.6,'figure.facecolor':'#fcfcfb','axes.facecolor':'#fcfcfb','lines.linewidth':2})
# ---- chart 21
def curve(kind):
    if kind=='live':
        T=pd.concat([pd.read_parquet(f) for f in sorted(glob.glob('1*data/trades_*.parquet'))]); B=pd.concat([pd.read_parquet(f) for f in sorted(glob.glob('1*data/top_of_book_*.parquet'))])
    else:
        tf=sorted(glob.glob('members/top_of_book/*.parquet')); days=[f.split('=')[1][:10] for f in tf]
        B=pd.concat([pd.read_parquet(f) for f in tf]); T=pd.concat([pd.read_parquet(f'members/trades/date={d}.parquet') for d in days])
    m=B[B['product']=='strawberries'].drop_duplicates('ts',keep='last').sort_values('ts'); mi=m.ts.astype('int64').values//10**9; mid=((m.bid+m.ask)/2).values
    at=lambda t: mid[np.clip(np.searchsorted(mi,t,side='right')-1,0,None)]
    x=T[(T['product']=='strawberries')&(T['size']==150)&(T.aggressor=='buy')].ts.astype('int64').values//10**9
    hs=np.r_[-30,-10,-5,-2,-1,0,1,2,5,10,20,30,60,120,180,300,600,900]
    base=at(x-2)
    return hs,[((at(x+h)-base)*100).mean() for h in hs],len(x)
fig,ax=plt.subplots(1,2,figsize=(12,4.6))
for i,k in enumerate(['hist','live']):
    hs,v,n=curve(k); ax[0].plot(hs,v,'-o',ms=4,color=C[i],label=f"{'historical (15 days)' if k=='hist' else 'live Oct 8–9'}  n={n}")
ax[0].axvline(0,color=INK2,lw=0.8,ls='--'); ax[0].set_xscale('symlog',linthresh=10); ax[0].set_xlabel('seconds from the size-150 buy print'); ax[0].set_ylabel('strawberry mid change (c), from 2s before')
ax[0].set_title('Strawberries: mid after a size-150 BUY',loc='left',color=INK,fontsize=11); ax[0].legend(frameon=False)
b=pd.read_parquet('./06_work/straw_big_hist_100.parquet'); ks=np.arange(1,7); w=0.38
for j,(sg,lab) in enumerate([(1,'buy runs'),(-1,'sell runs')]):
    vals=[b[(b.pos==k)&(b.sgn==sg)].f300.mean() for k in ks]
    ax[1].bar(ks+(j-0.5)*w,vals,w-0.04,color=C[j],label=lab)
ax[1].axhline(0,color=INK2,lw=0.8); ax[1].set_xlabel('k-th consecutive 100+ lot trade on the same side (gaps ≤ 2 min)'); ax[1].set_ylabel('next 5 min move in trade direction (c)')
ax[1].set_title('Runs of 100+ lots: buys continue, sells reverse',loc='left',color=INK,fontsize=11); ax[1].legend(frameon=False)
fig.tight_layout(); fig.savefig('../charts/21_strawberry_informed_buyer.png',dpi=130)
# ---- chart 22
a=pd.read_csv('./06_work/ushape_min.csv',index_col=0); h=pd.read_csv('./06_work/ushape_hr.csv',index_col=0)
fig,ax=plt.subplots(1,2,figsize=(12,4.2))
for i,c in enumerate(['hist','live']):
    ax[0].plot(a.index,a[c].rolling(3,center=True,min_periods=1).mean(),color=C[i],label='historical (31 days)' if c=='hist' else 'live Oct 8–9')
    ax[1].plot(h.index,h[c],'-o',ms=4,color=C[i],label='historical (31 days)' if c=='hist' else 'live Oct 8–9 (1–2 h per point)')
ax[0].set_xlabel('minute of the hour'); ax[0].set_ylabel('volume ÷ average'); ax[0].set_title('Minute-of-hour U-shape (all products)',loc='left',color=INK,fontsize=11); ax[0].legend(frameon=False)
ax[1].set_xlabel('hour of day, UTC (Perth = UTC+8)'); ax[1].set_title('Hour of day: busiest 23:00–01:00 UTC = 7–9 am Perth',loc='left',color=INK,fontsize=11); ax[1].legend(frameon=False); ax[1].set_xticks(range(0,24,3))
fig.tight_layout(); fig.savefig('../charts/22_activity_u_shape.png',dpi=130)
