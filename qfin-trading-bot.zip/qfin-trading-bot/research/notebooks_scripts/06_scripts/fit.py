import pandas as pd,numpy as np,json
from scipy import stats
P=json.load(open('../bot/option_params.json'))
noise=np.array(P['settle_noise_quantiles'])
X=pd.read_parquet('./06_work/panel.parquet')
X=X[X.expiry_min.isin([5,60])&(~X.reset)&(X.tau>=5)]
def price(gap,sd,nu=None,b=0.0,noise=noise):
    a=(gap[:,None]+noise[None,:])/sd[:,None]+b
    if nu is None: p=stats.norm.cdf(a)
    else: p=stats.t.cdf(a*np.sqrt(nu/(nu-2)),nu)
    return p.mean(1)
def ll(p,y): p=np.clip(p,1e-4,1-1e-4); return -(y*np.log(p)+(1-y)*np.log(1-p)).mean()
pd.set_option('display.width',250)
rows=[]
for kind in ['hist','live']:
  for em in [5,60]:
    d=X[(X.kind==kind)&(X.expiry_min==em)]
    if kind=='hist': d=d.sample(min(len(d),120000),random_state=0)
    g,s,y,q=d.gap.values,d.sd.values,d.y.values,d.q.values
    r={'kind':kind,'em':em,'n_obs':len(d),'windows':d.window_open.nunique(),'LL market':ll(q,y),'Brier market':((q-y)**2).mean()}
    for nu in [None,30,10,6,4,3]:
        p=price(g,s,nu); r[f'LL nu={nu or "inf"}']=ll(p,y)
    # market-implied nu: fit q to price without noise
    best=min([(((price(g,s,nu,noise=np.zeros(1))-q)**2).mean(),nu or 999) for nu in [None,30,10,6,4,3]]); r['market-implied nu']=best[1]
    rows.append(r)
print(pd.DataFrame(rows).round(4).T.to_string())
