import pandas as pd,numpy as np,json
from scipy import stats
exec(open('../06_scripts/fit.py').read().split("pd.set_option")[0])
X=X.dropna(subset=['bid','ask'])
X['day']=X.ts.dt.date
rows=[]
for kind in ['hist','live']:
  for em in [5,60]:
    d=X[(X.kind==kind)&(X.expiry_min==em)]
    y,a,bd=d.y.values,d.ask.values,d.bid.values
    for lab,nu,b in [('normal+noise (≈ bot)',None,0),('fat tails t8 +noise',8,0),('t8 + up-skew 0.1sd',8,0.1)]:
        f=price(d.gap.values,d.sd.values,nu,b)
        buy=f-a>0.05; sell=bd-f>0.05
        pnl=np.r_[(y-a)[buy],(bd-y)[sell]]
        # per day for t-stat
        dd=pd.DataFrame({'day':np.r_[d.day.values[buy],d.day.values[sell]],'p':pnl}).groupby('day').p.mean()
        rows.append({'kind':kind,'em':em,'pricer':lab,'signals':len(pnl),'buys %':buy.sum()/max(len(pnl),1),'c/contract':pnl.mean()*100,'hit':(pnl>0).mean(),'days +':f'{(dd>0).sum()}/{len(dd)}'})
pd.set_option('display.width',250)
print(pd.DataFrame(rows).round(2).to_string())
