import pandas as pd,numpy as np,json
from scipy import stats
exec(open('../06_scripts/fit.py').read().split("pd.set_option")[0])
X=X.dropna(subset=['bid','ask'])
pd.set_option('display.width',250)
bins=[-9,-2,-1.25,-0.75,-0.4,-0.15,0.15,0.4,0.75,1.25,2,9]
for kind in ['hist','live']:
  for em in [5,60]:
    d=X[(X.kind==kind)&(X.expiry_min==em)].copy()
    d['pn']=price(d.gap.values,d.sd.values)
    d['zb']=pd.cut(d.z,bins)
    t=d.groupby('zb',observed=True).agg(n=('y','size'),realized=('y','mean'),market=('q','mean'),normal_noise=('pn','mean'),Phi_z=('z',lambda z:stats.norm.cdf(z).mean()))
    print(f'\n== {kind} {em}m  LL market {ll(d.q.values,d.y.values):.4f}  LL normal+noise {ll(d.pn.values,d.y.values):.4f}')
    print(t.round(3).T.to_string())
    # symmetry: P(up|z>0 bucket)+P(up|mirror)-1
    # skew fit: best location shift b
    bs=[(ll(price(d.gap.values,d.sd.values,None,b),d.y.values),b) for b in np.arange(-0.15,0.16,0.025)]
    print('best shift b (sd units):',min(bs)[1], ' LL',round(min(bs)[0],4),' P(up) at |z|<0.15:',round(d[d.z.abs()<0.15].y.mean(),3),'n',(d.z.abs()<0.15).sum())
