import pandas as pd,glob,numpy as np,sys
rng=np.random.default_rng(0)
def load(kind):
    if kind=='live':
        T=pd.concat([pd.read_parquet(f) for f in sorted(glob.glob('1*data/trades_*.parquet'))])
        B=pd.concat([pd.read_parquet(f) for f in sorted(glob.glob('1*data/top_of_book_*.parquet'))])
    else:
        tf=sorted(glob.glob('members/top_of_book/*.parquet'))
        days=[f.split('=')[1][:10] for f in tf]
        B=pd.concat([pd.read_parquet(f) for f in tf])
        T=pd.concat([pd.read_parquet(f'members/trades/date={d}.parquet') for d in days])
    return T,B
MINSZ=int(sys.argv[2]) if len(sys.argv)>2 else 80
GAP=120
T,B=load(sys.argv[1])
B['mid']=(B.bid+B.ask)/2
out=[]
for p in ['apples','bananas','oranges','strawberries','watermelon','etf']:
    m=B[B['product']==p].set_index('ts')['mid']
    m=m[~m.index.duplicated(keep='last')].sort_index()
    t=T[(T['product']==p)].sort_values('ts')
    big=t[t['size']>=MINSZ].copy()
    big['sgn']=np.where(big.aggressor=='buy',1,-1)
    def runs(sgn,ts):
        rid=np.zeros(len(sgn),int); pos=np.zeros(len(sgn),int)
        r=0;k=0
        for i in range(len(sgn)):
            if i>0 and (sgn[i]!=sgn[i-1] or (ts[i]-ts[i-1])>GAP or ts[i]<ts[i-1]): r+=1;k=0
            rid[i]=r;k+=1;pos[i]=k
        return rid,pos
    ts=big.ts.astype('int64').values//10**9
    rid,pos=runs(big.sgn.values,ts)
    big['rid']=rid;big['pos']=pos
    L=big.groupby('rid').pos.max()
    # null: shuffle signs
    nL=[]
    for _ in range(20):
        s=rng.permutation(big.sgn.values); r2,p2=runs(s,ts); nL.append(pd.Series(p2).groupby(r2).max())
    nL=pd.concat(nL)
    # forward mids
    mi=m.index.astype('int64')//10**9
    def mid_at(t):
        idx=np.searchsorted(mi.values,t,side='right')-1
        v=m.values[np.clip(idx,0,len(m)-1)].astype(float); v[idx<0]=np.nan; return v
    t0=ts
    m0=mid_at(t0)  # mid at/after trade second (ts recorded per second, tob same second probably post-trade)
    mb=mid_at(t0-1)
    for h in [60,300,900,1800]:
        big[f'f{h}']=(mid_at(t0+h)-m0)*big.sgn*100
    big['imp']=(m0-mb)*big.sgn*100
    row={'product':p,'big/day':len(big)/T.ts.dt.date.nunique(),
         'runs>=3':(L>=3).sum(),'runs>=5':(L>=5).sum(),'null>=5':(nL>=5).sum()/20,
         'P(same side next)':(big.sgn.values[1:]==big.sgn.values[:-1]).mean()}
    for k in [1,3,5]:
        sel=big[big.pos==k]
        row[f'n@{k}']=len(sel)
        for h in [60,300,900,1800]: row[f'@{k} f{h}']=sel[f'f{h}'].mean()
    row['imp']=big.imp.mean()
    out.append(row)
    if p=='strawberries': big.to_parquet(f'./06_work/straw_big_{sys.argv[1]}_{MINSZ}.parquet')
pd.set_option('display.width',250)
print(pd.DataFrame(out).set_index('product').round(2).T.to_string())
