"""
QFin Project - Step 2: how the products move.

Run from the "QFin Project" folder:
    pip install pandas pyarrow numpy
    python 02_price_dynamics.py          # every 6th day (~31 days) - what the findings used
    python 02_price_dynamics.py 1        # every day (slow, lots of RAM)

Sections
  A. Mean reversion vs trending      (autocorrelation, variance ratio)
  B. How products relate             (return + level correlations, apples/oranges pair)
  C. ETF vs basket lead-lag          (who closes the gap)
  D. Time-of-day / minute-of-hour    (activity cycles)
  E. Trade markouts                  (who is informed; is market making profitable)
  F. Mean-reversion signal           (mid minus EMA -> future move)
"""
import sys, glob, os
import numpy as np, pandas as pd

D = "qfin_project_data/members/"
FRUITS = ["apples", "bananas", "oranges", "strawberries", "watermelon"]
PRODS = FRUITS + ["etf"]
STEP = int(sys.argv[1]) if len(sys.argv) > 1 else 6
pd.set_option("display.width", 250)

days = sorted(os.path.basename(f)[5:15] for f in glob.glob(D + "top_of_book/*.parquet"))[::STEP]
print(f"Using {len(days)} days: {days[0]} .. {days[-1]}")

def load_mids(day):
    df = pd.read_parquet(f"{D}top_of_book/date={day}.parquet")
    df["mid"] = (df.bid + df.ask) / 2
    return df.pivot(index="ts", columns="product", values="mid")[PRODS]

M = {d: load_mids(d) for d in days}                 # one mid DataFrame per day (86400 x 6)
L = pd.concat(M.values())
T = pd.concat([pd.read_parquet(f"{D}trades/date={d}.parquet") for d in days]).reset_index(drop=True)
T["sign"] = np.where(T.aggressor == "buy", 1, -1)

def pooled(fn):
    """Apply fn to each day's mids and concatenate (avoids gluing non-adjacent days together)."""
    return np.concatenate([fn(m) for m in M.values()])

# ---------------------------------------------------------------- A. Mean reversion
# Negative autocorrelation of consecutive k-second returns = price overshoots then comes back.
print("\nA1. Autocorr of consecutive k-second returns")
out = {}
for k in [1, 5, 10, 30, 60, 300, 900]:
    out[k] = {}
    for p in PRODS:
        r = [np.diff(m[p].values[::k]) for m in M.values()]
        x = np.concatenate([a[:-1] for a in r]); y = np.concatenate([a[1:] for a in r])
        out[k][p] = np.corrcoef(x, y)[0, 1]
print(pd.DataFrame(out).T.round(3))

# Variance ratio: <1 = mean reverting, >1 = trending, =1 = random walk.
print("\nA2. Variance ratio  Var(k-sec return) / (k * Var(1-sec return))")
v1 = {p: np.var(pooled(lambda m: np.diff(m[p].values))) for p in PRODS}
vr = {k: {p: np.var(pooled(lambda m: np.diff(m[p].values[::k]))) / (k * v1[p]) for p in PRODS}
      for k in [5, 30, 60, 300, 900, 3600, 14400]}
print(pd.DataFrame(vr).T.round(3))

# ---------------------------------------------------------------- B. Relationships
print("\nB1. Correlation of 60s returns");  print(pd.concat([m.iloc[::60].diff() for m in M.values()]).corr().round(3))
print("\nB2. Correlation of price LEVELS"); print(L.corr().round(3))
sp = L.oranges - L.apples
print(f"\nB3. oranges - apples: mean {sp.mean():.3f}, sd {sp.std():.3f}  (sd of oranges alone {L.oranges.std():.3f})")

# ---------------------------------------------------------------- C. ETF vs basket
print("\nC1. Lead-lag: corr(past h-sec move of X, next h-sec move of Y)")
for h in [1, 5, 10, 30]:
    B = [np.diff(m[FRUITS].sum(axis=1).values[::h]) for m in M.values()]
    E = [np.diff(m.etf.values[::h]) for m in M.values()]
    bl = np.corrcoef(np.concatenate([b[:-1] for b in B]), np.concatenate([e[1:] for e in E]))[0, 1]
    el = np.corrcoef(np.concatenate([e[:-1] for e in E]), np.concatenate([b[1:] for b in B]))[0, 1]
    print(f"  h={h:>2}s  basket leads ETF {bl:.3f}   ETF leads basket {el:.3f}")

print("\nC2. Regress future move on dev = ETF mid - basket mid (beta -1 = that leg closes whole gap)")
for h in [5, 10, 30, 60]:
    X, YE, YB = [], [], []
    for m in M.values():
        b = m[FRUITS].sum(axis=1).values; e = m.etf.values; dev = e - b
        X.append(dev[:-h]); YE.append(e[h:] - e[:-h]); YB.append(b[h:] - b[:-h])
    X, YE, YB = map(np.concatenate, (X, YE, YB))
    print(f"  h={h:>2}s  beta_ETF {np.polyfit(X, YE, 1)[0]:.3f}  beta_basket {np.polyfit(X, YB, 1)[0]:.3f}")

# ---------------------------------------------------------------- D. Time patterns
print("\nD1. Mean |1s mid change| (cents) by UTC hour")
print((L.diff().abs().groupby(L.index.hour).mean() * 100).round(3).T.to_string())
print("\nD2. Fruit trades by minute-of-hour (count across sample)")
fr = T[T["product"] != "etf"]
print(fr.groupby(fr.ts.dt.minute).size().values)

# ---------------------------------------------------------------- E. Markouts
# For each trade: how far did the mid move in the aggressor's favour after h seconds?
# edge_vs_mid = what the aggressor paid over the pre-trade mid = what a passive quoter earned up front.
# Passive quoter's net = edge_vs_mid - markout.
print("\nE1. Markouts in cents, signed by aggressor, by trade size")
rows = []
for p in PRODS:
    t = T[T["product"] == p].copy(); s = L[p]
    pre = s.reindex(t.ts - pd.Timedelta("1s")).values
    t["edge_vs_mid"] = t.sign * (t.price - pre) * 100
    for h in [1, 10, 60, 300]:
        t[f"m{h}"] = t.sign * (s.reindex(t.ts + pd.Timedelta(f"{h}s")).values - pre) * 100
    t["bucket"] = pd.cut(t["size"], [0, 5, 10, 20, 29, 30, 50, 1000])
    g = t.groupby("bucket", observed=True)[["edge_vs_mid", "m1", "m10", "m60", "m300"]].mean()
    g["n"] = t.groupby("bucket", observed=True).size(); g["product"] = p; rows.append(g)
print(pd.concat(rows).round(2).to_string())

# ETF size-30 trades specifically: the informed ETF bot.
e = T[(T["product"] == "etf") & (T["size"] == 30)]
bsk = L[FRUITS].sum(axis=1)
dev = (L.etf - bsk).reindex(e.ts - pd.Timedelta("1s")).values * 100
print(f"\nE2. ETF size-30 trades: {len(e)/len(days):.0f}/day. Mean pre-trade ETF-basket dev: "
      f"buys {np.nanmean(dev[e.sign == 1]):.1f}c, sells {np.nanmean(dev[e.sign == -1]):.1f}c")

# ---------------------------------------------------------------- F. Mean-reversion signal
print("\nF1. corr( mid - EMA(span), future h-sec move )")
rows = []
for p in PRODS:
    for span in [30, 120, 600]:
        for h in [10, 60, 300]:
            X = pooled(lambda m: (m[p] - m[p].ewm(span=span).mean()).values[3600:-h:10])
            Y = pooled(lambda m: (m[p].shift(-h) - m[p]).values[3600:-h:10])
            rows.append(dict(product=p, span=span, h=h, corr=np.corrcoef(X, Y)[0, 1]))
print(pd.DataFrame(rows).pivot_table(index=["product", "span"], columns="h", values="corr").round(3).to_string())
