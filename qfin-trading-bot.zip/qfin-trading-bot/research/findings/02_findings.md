# Step 2 findings – how the products move

Sample: 36 days (1–7 Jan plus every 6th day to 30 Jun). Script: `02_price_dynamics.py`. 15-min options excluded.

## 1. Fruits mean-revert strongly; the ETF does not
- 60s-return autocorrelation: apples/bananas/oranges ≈ **−0.24**, strawberries/watermelon ≈ −0.13, ETF ≈ +0.02.
- Variance ratio at 5 min: apples 0.30, bananas 0.30, oranges 0.34, strawberries 0.51, watermelon 0.59, **ETF 1.63** (ETF trends short-term — it's catching up to the basket).
- Signal `mid − EMA(120s)` → next-60s move: corr ≈ −0.29 (apples, bananas), −0.26 oranges, −0.15 strawberries, −0.13 watermelon.
- Size: apples |mid−EMA| > 6c (12% of the time) → mid moves ≈ 3.8c back within 60s. Crossing the spread both ways costs ~6c, so **use it to skew passive quotes, not to take**.

## 2. Hidden structure between fruits
- **Oranges ≈ apples + $1.04** (level corr 0.91, OLS slope 1.04). The spread reverts: corr −0.43 at 60s. Pair trade.
- Strawberries–bananas level corr 0.52; watermelon loads ~0.4 on apples and bananas. Weaker, worth a second look.
- 1s returns across fruits are uncorrelated — the link is in the slow fair values, not in tick noise.

## 3. ETF follows the basket
- Past 10–30s basket move predicts next ETF move: corr **0.34–0.44**. ETF does not lead the basket.
- When ETF mid ≠ basket mid, over 60s the ETF closes ~56% of the gap and the basket ~38%.
- The **informed ETF bot trades exactly size 30** (~2,170/day, bursts ~2s apart, 3–4 in a row). It fires when ETF is ~18c off the basket and trades toward it; mid moves +5.9c further after it prints. Following it at the touch still loses (15c spread) — the edge is to already be positioned/quoted on the basket signal.

## 4. Time cycles (volatility and volume move together)
- **Minute-of-hour**: activity at minute 0 is ~2.6× minute 30 (smooth U-shape). Matters for option vol and for quote width.
- **Hour-of-day**: busiest around 00:00 UTC (≈1.7× the 04–20 UTC baseline). No weekday effect.

## 5. Flow and market making
- Aggressors pay ~3c over mid in fruits; 5-min markout only 0.5–1.8c for apples/bananas/oranges/strawberries → **passive quoter nets ~1.5–2.5c/unit**. Most flow is uninformed.
- **Watermelon** is the exception: small/medium trades (≤25) carry 2–3.5c permanent impact — its informed bot hides in normal sizes. Quote watermelon wider / lean on the signal.
- Big fruit trades (50+) push the price ~4c then half reverts — fade them.

## Next steps
- Options: price 5m/60m up-down using the vol cycle + ETF-follows-basket signal; compare to quoted prices and `option_windows` outcomes.
- Estimate each fruit's fair value (EMA / flow model) and backtest a quoting strategy with skew.
- Confirm oranges–apples and other fruit links across all 182 days.
