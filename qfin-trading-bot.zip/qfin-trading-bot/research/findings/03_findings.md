# Step 3 findings: options, market-maker mechanics, jumps

Script: `03_deep_dive.py`. Option outcomes use all 182 days. Tick-level results use 35 sample days. 15-minute options are excluded. Results for steps 1–2 are in `02_findings.md`.

## Headline: the 5-minute option market is mispriced
The option quotes behave as if strike and settle were the ETF **mid**. In fact both are set by the **last ETF trade**, and that trade sits about 11c (sd) off the mid, because it usually hits the bid or the ask (±7.5c).

- **Evidence 1: outcomes of consecutive windows are negatively correlated.** Each window's strike is the previous window's settle, which is a noisy trade price. After an UP window, the next is up only 44.1% of the time. After a DOWN window, it's 56.3%. For 60m it's 47.0% vs 54.8%.
- **Evidence 2: the strike can be read off at the open.** You can see how far the strike sits from the mid as soon as the window opens, and that predicts the result:

| strike − mid at open | < −10c | −10 to −5c | ±5c | +5 to +10c | > +10c |
|---|---|---|---|---|---|
| P(up), 5m | **0.72** | 0.62 | 0.49 | 0.39 | **0.27** |

- **Model.** P(up) = P(mid at expiry + settle noise ≥ strike). It has three parts:
  - **Remaining volatility:** 1.49c per √second, scaled by a time-of-day profile.
  - **Drift:** the ETF closes about 55% of its gap to the basket.
  - **Settle noise:** the empirical distribution of last trade minus mid.
- **Result for 5m.**
  - The model is well calibrated where the market is overconfident. When the market says 4%, the real rate is 8.6%. When it says 96%, it's 91%.
  - Brier score (lower is better): market 0.179, model 0.166.
- **Hypothetical taking** (buy or sell at the touch when model edge > 5c, hold to expiry, sampled every 10s):
  - 5m: **+12.6c per contract**. This held in both halves of the sample (Jan–Mar 12.6c, Apr–Jun 12.7c).
  - 60m: +9.4c per contract, a smaller edge.
- **Where the 5m edge is biggest:** near expiry. It's 17c in the last 30s, falling to 10c early in the window.
- **Caveats:**
  - This is not a backtest. It ignores our own market impact, and signals 10s apart overlap. The option book shows 50 lots at the touch.
  - Model parameters were fitted on the same sample. There are only 3, so the risk of overfitting is low, but it should be checked on held-out days.
- **Grey area:** a 1-lot ETF trade in the settle second would move the settle price. The brief reserves the right to ban this. **We should not rely on it.**

## Other option findings
- **Win rates:** 5m up rate 50.2%, 60m 50.8%. Neither is significantly different from 50%.
- **Volatility by window start:** the ETF move is 40c (sd) for windows starting at minute :00, 25c at :30 and 38c at :55. Volatility can't be treated as constant.
- **Option order flow:**
  - Aggressors not trading size 10 or 30 buy UP 58–59% of the time and lose 2–3c per contract. That's retail-style flow.
  - Size-10 and size-30 bots are roughly break-even (±1c). They're not strongly informed.
- **Option quote lag:** option quotes follow the ETF with a lag spread over roughly 10 seconds.

## The fruit/ETF market maker is mechanical
- **Quote sizes:** bid size equals ask size 100% of the time, so the order book imbalance carries no signal.
- **Price moves only on trades:** in each second, the mid change equals λ × signed volume, with R² 0.97–0.98. Seconds with no trades move less than 0.01c.
  - λ = 0.06c per unit for apples, bananas, oranges and strawberries, 0.09c for watermelon and 0.19c for the ETF.
  - **Consequence:** fair value is never quoted directly. Prices only move because of flow. The informed bots push the price toward a hidden fair value, and uninformed noise gets reversed. That explains the mean reversion in step 2.
  - **Usable directly:** we can predict our own market impact exactly. Buying N units moves the mid by about λN.
- **Quote size and spread signal volatility:** the market maker's quote size (4–9) and spread (5–10c) move together. When size is small or the spread is wide, the next 60s move is larger. Apples at size 9 averages 4.3c over 60s; at size 4 it's 6.8c.

## Fruit correlations over longer horizons (30 min – 2 h)
- **Pairs that move together:** apples–oranges 0.6 (the pair from step 2), and strawberries–bananas 0.3.
- **Pairs that move oppositely:** bananas against apples and oranges, about −0.2.
- **No lead-lag between fruits:** any delay from 5 to 300 seconds shows nothing. The only lead-lag is basket → ETF, about 10s.
- **No clock pattern in price levels:** there's no clear daily or hourly cycle in prices, and the periodogram shows no sharp peak. The only strong clock pattern is in volatility and volume (step 2).

## Big moves (> 30c within 60s)
| product | per day | next 5 min | next 30 min | meaning |
|---|---|---|---|---|
| strawberries | 12 | **+6.0c** | +1.1c | momentum: likely genuine jumps in fair value |
| ETF | 42 | +3.8c | +1.9c | momentum: catching up with the basket |
| watermelon | 56 | **−7.3c** | −7.6c | reversal: noise, fade it |
| apples / bananas | 4–5 | ~0 | −4 to −5c | slow reversal |

## What this means for strategy (priority order)
1. **5m options:** price with the model above. Take or quote when the model differs from the market. The largest and most stable edge is here, which fits the brief's line that "most money is in options".
2. **Fruit market making:** quote around a fair value of mid − k·(mid − EMA). Lean quotes on the apples–oranges spread. Quote watermelon wider and fade its big moves.
3. **ETF:** keep ETF quotes in line with the basket (ETF fair value = basket). Pull or lean quotes when the ETF is more than 15c from the basket, because the size-30 bot is about to trade.
4. **Strawberries:** don't fade big moves; they tend to continue.

## Open questions
- **Fruit fair values:** can we recover them from informed flow? Try a Kalman filter on the mid using λ and the markouts.
- **Rules still TBD:** ETF create/redeem fee, and margin or futures treatment of short positions.
- **Proper backtest:** a PnL simulation with queue position, our own market impact and position limits, scored as mean − sd of daily PnL.
