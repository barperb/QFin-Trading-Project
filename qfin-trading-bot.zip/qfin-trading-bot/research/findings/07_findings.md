# Step 7 findings: the close second, the hosted runtime, and what went into v9

**Data:**
- Live exchange downloads, Oct 4–10. Two of these were partial: Oct 9 to 08:56 UTC, Oct 10 to ~10:30 UTC.
- Our fills CSVs.
- 15 historical days.
- The QFin team kit: the real `exchange.py`, market rules and the guide.

**Tools:** the scripts are in `bot_v9/tools/`.

## 1. The option settle is the last ETF trade inside the close second

| sample | 5m windows with ETF trades in the close second | settle = LAST trade in that second | = an earlier trade | = last trade before it |
|---|---|---|---|---|
| historical (15 days) | 1,163 | **1,163** | 0 | 0 |
| live Oct 7 / 8 / 9 / 10 | 78 / 100 / 56 / 25 | **all** | 0 | 0 |

- **The book still shows the old window.** At the close second (HH:MM:00), the option book shows the old window in 160 of 160 seconds checked (Oct 9).
- **v8 never pushed then.** It pushed only while `seconds_left > 0`, so it never acted inside the deciding second.

**Push forensics, live Oct 10 (5m windows, to ~10:30 UTC):**
- **Overall:** we held a position in 114 windows and pushed in 71.
  - **Pushed:** won 77.5%.
  - **Not pushed:** won 46.5%. 17 of these had the ETF ≥ 15c below the strike, outside the push budget, and all were lost.
- **Did our print reach the strike?** Our last print reached the strike in 92% of pushes. Of those, we won 85%.
  - The losses had a later print in the last second or in the close second.
  - In one case (00:45) we printed +1c over the strike, then someone sold the ETF 20c down.
- **When our orders arrive:** our orders reach the exchange about 75–100 ms after the second boundary on normal days, and 0.1–0.8 s on slow days (Oct 10).
- **Self-harm found:** the early push batch put our own 1-lot ETF quotes back on the book. These were sometimes an ask *below* a strike we had just pushed above, so a buyer could set the settle against us.

**v9:**
- **Late push:** one batch, timed to arrive at close + 0.70 s:
  - cancel our ETF quotes
  - walk the wrong-side levels (+10 buffer)
  - print 1 unit on our side
  - rest a 10-lot "wall" at the strike
- **Push seconds:** they no longer re-place our ETF quotes.
- **Push budget:** 120 → 200 units (+50 for the late push).

## 2. Hosted bots run in the SDK's pipe mode; that is why we crash

**Evidence:**
- The team kit's `exchange.py` has a pipe transport (`QFIN_BACKTEST=1`): state arrives each tick, and every API call goes through the platform synchronously.
- Our live logs never show the SDK's normal "logged in / ready" lines.
- A batch took 5.8–7.1 s and returned `exchange unavailable`, even though our HTTP timeout was 1.25 s. That timeout only applies outside the pipe.
- A stalled exchange call therefore means on_tick > 5 s, and the bot is killed: 109 restarts for v7 and 10 for v8 on Oct 10.
- Threads can't fix it, because the pipe isn't thread-safe.

**v9:**
- At most one call per tick.
- Resting-quote-only refreshes at most every 2 s (IOCs immediately).
- A 15 s pause after any slow or failed call, doubling to 120 s if it repeats within 5 min.

## 3. Price 5m options off the basket

The basket (sum of fruit mids) predicts the settle better than the ETF mid for anything 30 s or more out:

| time before close | hit rate, basket | hit rate, ETF |
|---|---|---|
| 4 min | 0.656 | 0.639 |
| 30 s | 0.820 | 0.802 |

Replay of our live option books (take at the touch when model − ask > edge, cap 500, real outcomes), 5m P&L summed over Oct 7–10:

| model drift toward the basket | 0 | 0.3 | 0.55 | 0.8 | 1.0 |
|---|---|---|---|---|---|
| 5m P&L | $28.0k | $34.2k | $38.2k | $40.6k | $42.1k |

- **Every day improves** at each step. Oct 7: −$4.1k → −$0.4k at 0.8.
- **60m is mixed,** so it gets less drift.
- **v9 setting:** drift {5m: 0.8, 60m: 0.3}, in every mode (it was 0 live).

## 4. Market rules that change the bot (team kit)

- **End of day:** positions are valued at the mid continuously, and every position is closed at the end of the day. Flattening only paid spreads, so it's **off in v9**, along with the late-day reduce-only rule.
- **Limits:** position limit 500 on every product, options included. Margin is 100% of notional. Each day starts with $10,000. Memory is about 100 MB.
- **ETF creation/redemption** (one of each fruit ↔ 1 ETF) exists, with fee `config["etfFee"]`. v9 logs the config at startup.
- **Option pricing source:** `price_source` can be `etf_mid`. Historically the 15m option settled on the mid. v9 trades any enabled option and prices mid-settled ones without print noise.
- **Final ranking:** every team's bot as uploaded at the deadline, trading together in a simulated market for several days. The score is mean − sd of daily P&L.

## 5. Checked and not built

- **ETF vs basket crossable arbitrage on the live books:** it happens thousands of seconds a day at 5–15c, but at the touch it's only about 1–2 units (team 1-lot quotes). That's about $100–300/day before fees and legging risk.
- **Pushing the ETF to cheapen the option book before buying:**
  - The live option book re-prices off a ~5–10 s average of the ETF, with σ ≈ 2.3c/√s (it's less confident than the house option market maker historically).
  - A 10c ETF move shifts UP about 0.10 at the open.
  - It's plausible, but it needs a live test, so it's not in v9.
- **Strike engineering (printing the settle higher to make the next window's UP cheaper):** also plausible. It depends on push reliability at a distance, which v9's logs will measure.

## 6. Other teams (live P&L history, `team_tracking/`)

**Daily results:**

| team | Oct 8 | Oct 9 |
|---|---|---|
| kai | $15.7k | $25.1k |
| KnightCapital | $9.2k | $9.8k |
| T4 | – | $16.2k |
| us (tacof) | $6.4k | $0.7k |

- **Oct 9:** v5.2 crash-looped that evening.
- **Oct 10 (to ~12:45 UTC):** T4 $18.4k, us $10.1k.
- **Who's on which side:** T4 and qfingroup3 have sat on −500 up5 (DOWN) at times, so they're on the other side of our close-second fights.
