# Step 9 findings: Oct 10 full day, the late-push losses, where the option money is, and v10

**Data:** live market data for all of Oct 10 (downloaded after the 00:00 UTC day end), our own fills for Oct 10,
positions / volume-matrix snapshots at 15:55, 16:35 and 23:35 UTC, daily results to Oct 10, historical handout days for
the backtest. Scripts: `bot_v10/tools/` (`close_second.py` for the close-second forensics).

## 1. Oct 10 result

| team | Oct 10 P&L |
|---|---|
| T4 | +$39,353 |
| **tacof (us, v9.1)** | **+$16,774** (2nd) |
| Spudtrading | +$14,949 |
| qfingroup3 | +$14,829 |
| T44 | +$6,408 |
| low hanging fruit | +$6,380 |
| Group 8 | +$3,674 |
| The Fruity Boys | +$3,269 |
| kai | +$1,802 |
| Group 3 | -$492 |
| KnightCapital | -$1,840 |

v9.1 ran from 13:35 UTC with 1 restart all day. Its log at 23:34: `late pushes sent 92, settled 92, won 67; skipped {'unreachable': 20}`.

## 2. The late push lost windows we had already won

Every 5m close from 13:35 to 24:00 UTC, matching our ETF orders to the public tape (`close_second.py`):

| | windows |
|---|---|
| held UP (avg 481 contracts) | 118 |
| won | 66 |
| lost, no late push (ETF ended 20-70c below the strike) | 23 |
| lost, another team printed after our late push | 2 |
| **lost, OUR late print was the settle, below the strike** | **27** |
| ... of which the early push had already printed on our side | **20** |

- **Cost:** those 20 windows are a ~$500 swing each at 500 contracts, about **$10k in 10.4 hours**. It happened in every hour.
- **Cause 1, a stale book.** B (the 1-unit print) and the wall were priced from the book seen at the tick. About 0.7 s
  later the house had refilled asks just under the strike, and both orders bought them. Examples (strike vs our last print):
  - 22:15: 55.78 vs 55.76
  - 22:20: 55.76 vs 55.73
  - 23:55: 53.50 vs 53.49
  - 20:50: 55.47 vs 55.45
- **Cause 2, float rounding.** The exchange records a trade at its average fill price in float64 and compares
  settle >= strike exactly (a tie counts UP).
  - At 16:50 our 10-unit wall was the last print, at exactly the 55.62 strike.
  - The average was 10 x 55.62 / 10 = 55.61999999999999, so the tie was lost to rounding.
  - Strikes carry the same noise (the API shows 56.095000000000006 and 56.13999999999999).
- **v9.2** (built by another session on Oct 10, never uploaded) fixed cause 1:
  - the walk is priced at the strike;
  - the walls go first on the wire.
- **v10** also fixes cause 2:
  - boundaries use exact float64 compares;
  - B (1 unit, exact price) is always our last print;
  - walls sit one tick inside the range.

## 3. Where the option money is

**5m UP is underpriced by the house option market maker, because every big team pushes UP at the close.** At the touch:

| 60 s before the close | Oct 6 | Oct 7 | Oct 8 | Oct 9 | Oct 10 |
|---|---|---|---|---|---|
| UP win rate | 45% | 50% | 59% | 59% | 60% |
| buy at the ask, ¢ per contract | -3.3 | -2.0 | +8.7 | +12.1 | +8.5 |

The 60m UP is roughly fair: −1 to −4c at the ask and −2 to −5c at the bid. There's no edge on either side on average.

**Tape, Oct 8–10, 5m.** These are trades by other traders, not ours:
- UP buyers made about $283k: $173k as takers, plus $110k for the bid side when someone sold UP into it.
- That's about $94k/day, while all teams together made about $100k on Oct 10. **Almost all team profit is UP bought from the house.**
- About 2,400 UP contracts trade per 5m window, against a 500-contract position cap. Teams cycle in and out; we buy ~480 and hold.

**Cheap late UP is the best value per contract.** Market-wide UP buys on Oct 10, by seconds since the window opened:

| seconds since open | avg price | UP win rate | ¢ per contract |
|---|---|---|---|
| 0–30 | 0.48–0.51 | 61–66% | +13 to +15 |
| 120–180 | 0.41 | 59% | +18 |
| 240–300 (last minute) | 0.34 | 58% | +23 |

v9.1 bought ~430 of its contracts in the first 30 s. v9.2's 20c early edge saves the cap for later, which is the right
direction. Those late contracts win through pushes, which is why the push fixes and the deep push matter.

## 4. Other teams

**T4 (+$39k on Oct 10)** trades both sides of the 5m option:
- At 15:55 UTC it held +500 up5.
- At 16:35 it held −160 up5 and −203 up60.
- 8 s before the 23:35 close it held −440 up5, against +249 for us, +400 for Spudtrading and +440 for qfingroup3. UP won that window.
- In the volume matrix, T4 sold UP to house-options (245 contracts) and mostly bought fruit from house-flow.
- From the earlier P&L history, T4 earns between closes (~$30 per 200 s) and on both outcomes.
- Without names on the tape, we can't tell whether that is option market making or stale-quote scalping.

**qfingroup3 (+$14.8k)** trades options only. It is usually long up5 and short up60 (−350 to −500).

**kai** has dropped off: +$1.8k on Oct 10, after $15.7k and $25.1k on the two days before. It held only −207 ETF all day.

## 5. v10 = v9.2 + these changes

- Float-exact push boundaries; walls one tick inside the range; B is always our last print.
- One push builder (`robust_push_orders`) for every range shape. v9.2 raised `OverflowError` and sent no push for a DOWN
  window that was already in the money.
- Late walk ≥ 60 units, priced at the strike, so it only fills wrong-side levels. B is sized before A for margin.
- Deep push for strikes up to 25c beyond the visible ETF ladder: walk the ladder 1 s before the close, then the rest of
  the budget in the close second. It is live only and can't be measured in the backtest.
- Book-only jump signals:
  - strawberry run follow (3 up-jumps of 7c+ in 120 s; buy 60, hold 4 min);
  - watermelon jump fade (lean 30 units for 5 min).
- ETF unwind: 20 units per IOC.
- **Tests:** 104 unit tests on the real SDK, all passing. The pipe-mode harness checks the batch timing.
- **Backtest** (4 historical days): v10 $60,173/day, sd $2,888, score $57,285, against v9.2's $59,496 / $2,878 / $56,618.
  v10 is better on all 4 days.

## 6. Next

1. Upload v10. Then watch the `late push ... A 60u ... B 1u` lines and the won/sent ratio. v9.1 won 64 of the 93 windows where it sent a late push.
2. Watch the `DEEP` pushes: how often they fire, and whether they win often enough to pay for the ETF they leave behind.
3. Option cycling: other teams trade ~5x the cap per window. A replay that sells UP back when it is rich and re-buys it
   cheap later, using real competition for the asks, is the next thing to test.
