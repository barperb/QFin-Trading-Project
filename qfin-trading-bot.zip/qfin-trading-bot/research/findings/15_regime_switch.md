# Step 15 findings: the Oct 15 regime flip, v15/v16 and the DOWN-mode caps

## What happened
- On Oct 15 UP won only 11 of 92 5m windows (~12%), and ties fell from 38% to 0%.
- v14.2's off-switch shut the open UP buy (−7c/contract), but the other UP-buy paths kept loading: model takes −37c,
  resting bids −47c, 60m buys −50c.
- Fruit/ETF market making still made money (+$630), so it is the regime-proof base. Daily P&L sd jumped, which cut the score.

## v15: gate every UP buy on the regime
`OPTIONS.regime_gate`: no UP buying on any path when UP has won < 50% of the last 12 closes (needs >= 8 closes). The history
is fed from the exchange's settled windows, not the ETF trade tape (which is empty live).

## v16: trade both sides
| UP share, last 12 (5m) | Options behaviour |
|---|---|
| >= 50% | UP mode: buy UP, settle push defends up |
| 25–50% | Neutral: no new option risk |
| <= 25% | DOWN mode: short 5m UP (cap 500), settle push defends down |

## Cap sweep (`bot/tools/short_sweep.py`, `short_sweep_60m.py`)
Replay on Oct 6–12 live books, model short-takes, real outcomes:

| 5m gate | cap 200 | cap 350 | cap 500 | cap 800 |
|---|---|---|---|---|
| UP <= 25% | +$9 | +$75 | +$129 | +$257 |
| UP <= 35% | −$442 | −$697 | −$956 | −$1,477 |
| UP <= 45% | −$3,849 | −$6,584 | −$9,181 | −$14,003 |

- An open-of-window sell sweep lost money at every cap, so DOWN mode uses model takes and the resting ask only.
- 60m shorts lost at every cap from 50 to 500, so there is no 60m DOWN mode.
- Caveat: the recorded days had few deep-down stretches and the outcomes include UP pushes, so the short results are
  pessimistic and thin. On Oct 15 the 25% gate would have been on for ~57 windows, with DOWN winning ~86% of them.
