# Step 4 findings: fair values

Scripts: `04_fair_value.py` does the fitting and testing. `fair_value.py` is the live estimator for the bot. The model is fitted on 1–7 Jan and tested out-of-sample on 28 other days.

## The model: two layers of mean reversion

```
fast layer (seconds)   mid(t+1) - mid(t) = theta * (fair(t) - mid(t)) + noise
                       fair(t+1) = fair(t) + small random step
slow layer (hours)     fair drifts back toward a long-run level, half-life ~3–7 h
```

**Why this form.** The market maker's price only moves when someone trades (step 3), and informed bots trade toward fair value. So on average the mid gets pulled toward a hidden fair value. The Kalman filter works backwards from this. Each second it looks at how the mid moved and asks how far away fair must be to explain that move.

### Fitted parameters

| | how fast mid reverts to fair (half-life) | fair value volatility | noise in each 1-second mid move |
|---|---|---|---|
| apples | 18 s | 0.50c/√s | 1.10c |
| bananas | 19 s | 0.53c/√s | 1.09c |
| oranges | 18 s | 0.55c/√s | 1.09c |
| strawberries | 20 s | 0.73c/√s | 1.11c |
| watermelon | **38 s** | **1.16c/√s** | 1.67c |

### What the filter does (apples, mid jumps +1c)

| seconds after the jump | fair estimate if the move sticks | fair estimate if the move reverses after 10s |
|---|---|---|
| 0 | +0.45c | +0.45c |
| 10 | +0.54c | +0.09c |
| 60 | +0.80c | +0.04c |
| 300 | +1.00c | 0 |

**In plain words:** a move only counts as real if it doesn't reverse. Most noise-driven moves reverse, so the filter mostly ignores them.

## Which one is the fair value? Out-of-sample test

A true fair value should best predict where the mid goes next, and the relationship should have a slope close to 1 over long horizons.

| | R² at 60s | slope at 30 min |
|---|---|---|
| **apples** | | |
| fair = mid | 0 | – |
| 30s moving average | 0.035 | 0.73 |
| Kalman | 0.071 | 0.98 |
| **joint Kalman** | **0.095** | **0.98** |
| **oranges** | | |
| 30s moving average | 0.020 | 0.65 |
| joint Kalman | **0.082** | **1.00** |
| **bananas** | | |
| Kalman (joint is the same) | **0.081** | 1.07 |
| **strawberries** | | |
| joint Kalman | **0.026** | 1.21 |
| **watermelon** | | |
| Kalman (only works over 5 minutes or more) | 0.004 | 0.9–1.3 |
| **ETF** | | |
| the ETF's own Kalman | 0.002 | fails |
| basket mid (sum of fruit mids) | 0.10 | 0.55 |
| **sum of fruit Kalman fairs** | **0.23** | 0.83–0.89 |

**Verdict:**
- **Fruits:** fair value is the Kalman estimate. Use the joint version, which lets apples and oranges inform each other because their fair values are correlated at 0.65.
- **Moving averages:** at every horizon they're worse than the Kalman, and their slopes are well below 1.
- **Watermelon:** the Kalman only helps over 5 minutes or more. Over shorter horizons the mid is as good.
- **ETF:** its fair value is the sum of the fruit fair values. The ETF's own price history tells you nothing.
- **What didn't help:**
  - Feeding the ETF price into the fruit filter made it worse, which confirms the ETF follows the fruits and not the other way round.
  - Adjusting the filter for the time-of-day volatility pattern also made it worse.

## What the informed ETF bot reacts to

Chance of a size-30 ETF trade in the next second, by the gap between the ETF and each candidate:

| gap | 0–5c | 5–8c | 8–10c | 10–12c | 12–15c | 15–20c | 20–30c |
|---|---|---|---|---|---|---|---|
| vs sum of fruit **mids** | **0.000** | 0.001 | 0.015 | 0.039 | 0.062 | 0.087 | 0.124 |
| vs sum of fruit Kalman fairs | 0.004 | 0.019 | 0.041 | 0.067 | 0.088 | 0.119 | 0.155 |

The trigger is cleanest when measured against the sum of fruit **mids**: the bot never fires below 5c, and its size-30 trades start at about 8.5c. **Rule for our ETF quotes:** once the ETF is about 8–10c away from the basket mid, expect size-30 trades that push it back.

## The slow layer: fair values return to a long-run level

- **Long-run levels** (averages across the sample): apples 10.70, bananas 8.57, oranges 11.75, strawberries 9.54 and watermelon 12.74. They sum to 53.29, the same as the ETF's average.
- **Out-of-sample test:** I took the long-run averages from the first half of the sample days and tested on the second half. The gap to the long-run level predicts the next 4 hours with **correlation 0.45–0.57**. About 35–60% of the gap closes, which implies a **half-life of about 3–7 hours**.
- **A trailing 24–48 hour average works as well as a fixed level** (correlation 0.43–0.68 for the next 4 hours). This is safer for the live exchange.
- **Caveats:**
  - The levels drift: January averaged lower than Feb–Jun.
  - The data started on 1 Jan at round numbers: 10, 8, 11, 9 and 12, summing to 50.
  - The live exchange may start somewhere else, so re-estimate the level on the live exchange.
- **Size of the opportunity:** a 1-standard-deviation gap is about 67c, and about 40% of it closes in 4 hours, so the expected move is about 25c. The fruit spread is about 6c and price impact is 0.06c per unit, so this is worth holding within a day. Positions reset daily in the training phase.

## How the bot should use this

- **Market making:** centre fruit quotes on the Kalman fair value rather than the mid, plus a small lean toward the long-run level.
- **Holding positions over hours:** hold inventory against the gap between the Kalman fair and the long-run level. Size it for the scoring rule (average daily PnL minus its standard deviation).
- **ETF:** use the sum of fruit Kalman fairs to predict the ETF. Watch the basket-mid gap for the bot trigger.
- **Options:** the `sum_fruit_kalman` value can replace the drift term in the step 3 option model (not tested yet).
