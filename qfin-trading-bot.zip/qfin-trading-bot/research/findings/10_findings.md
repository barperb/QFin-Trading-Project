# Step 10 findings: v10.4 live review (Oct 11, 07:38–12:58 UTC) and notes for v11

Data: our fills for Oct 11, settled option windows, leaderboard snapshots.
v10.4 ran 5.3 h: P&L from +$12.8k to +$21.7k (+$8.9k, ~$1.7k/h). Late pushes 45/45 won. No restarts, no loss stop.

## 1. Is shorting making money? Not really.

**Short book only.** Opened shorts are matched FIFO to their covers, and anything left open is matched to the settle.
- 9,545 contracts were shorted across 20 windows. Net **+$77**, which is break-even.
- In the 9 DOWN windows the shorts made +$1,065.
- In the 11 UP windows they lost −$987. The worst were:
  - 11:30, −$294;
  - 08:25, −$258: shorted at 46c, covered at 90c;
  - 12:45, −$217.

**Whole up5 window P&L, by whether the bot shorted:**

| | windows | avg P&L | total |
|---|---|---|---|
| no short, UP | 34 | +$231 | +$7,858 |
| no short, DOWN | 11 | −$100 | −$1,104 |
| shorted, UP | 11 | −$30 | −$332 |
| shorted, DOWN | 9 | +$111 | +$998 |

**Counterfactual.** If the 20 shorted windows had played like the unshorted ones, they'd have made about +$1,640 instead of
+$666. So shorting cost roughly **−$1k over 5.3 h**.
- This is rough: there is selection bias. Shorted windows ended UP 55% of the time, against 76% for the rest.
- **Why it costs money:**
  - The short fires 2–20 s after the window opens, when the bid is rich (bid − v_short > 15c).
  - In doing so it replaces the cheap long position we would otherwise build at the open.
  - Shorting at about 46c needs UP to win less than about 46% of the time. Even the windows the signal picks still win UP 55%.

**Shorts held into the settle.** 300 contracts were still short at the settle, despite cover_s=60:
- 210 at 08:30 and 90 at 10:35.
- Both were DOWN windows, where UP was near 0 and there were no asks to cover into, so this was harmless both times. It is still unbounded risk if UP ever spikes late.

**Trims:** only 78 contracts, −$43 against holding. Negligible.

**v11 recommendation:** turn off the open-window short (`option_short_swap=False`), or only allow shorting late in the window with a much bigger edge. Also make the cover robust.

## 2. Fruit / ETF since 07:38: about +$800 in total (~$150/h)

| product | P&L | volume | maker markout, ¢/unit at 60 s |
|---|---|---|---|
| apples | +$96 | 17.3k | +0.39 |
| bananas | +$285 | 30.5k | +0.80 |
| oranges | +$48 | 18.2k | −0.21 |
| strawberries | +$221 | 27.9k | +0.56 |
| watermelon | +$181 | 13.3k | +1.02 |
| etf | −$25 | 2.4k | maker +1.24, taker −7.05 |

- We trade about 107k fruit units for under 1c of edge per unit. Almost all of our money comes from up5 options.
- **v11 ideas:**
  - wider or skewed fruit quotes, and possibly fewer but more profitable fills;
  - an apples/oranges pair trade;
  - look at why oranges market making is negative.
