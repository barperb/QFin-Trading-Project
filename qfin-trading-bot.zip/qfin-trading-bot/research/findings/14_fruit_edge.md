# Step 14 findings: can fruit market making close the option speed gap? (Oct 14)

Question: our open UP buy fills in the 2.06 s option match instead of the first (1.06 s) one, which costs roughly
5c x 500 x 12 = ~$300/hr. Can fruit market making make that up?

## P&L by source, Oct 14 00:00-04:20 UTC (our fills, marked to market)
| Source | P&L | Per hour | Volume |
|---|---|---|---|
| Options (open UP buy) | +$11,590 | $2,719/hr | 25k contracts |
| Fruit MM | +$892 | $209/hr | 194k units |
| ETF MM | -$39 | -$9/hr | 2k units |

## Maker-fill markouts, Oct 12-13
Indicative only (about 10% of fills had a clean mid). 60 s markout per unit: apples ~0.57c, bananas ~0.34c,
watermelon ~0.77c, strawberries ~0.05c, oranges ~-0.04c.

## Levers tested
- **Wider quotes** (keep only fills with edge-at-fill >= 0.25..2c): per-unit markout does NOT rise; the bigger-edge fills are
  the adversely selected ones. Widening only cuts volume. Rejected.
- **Drop weak fruit** (oranges, strawberries ~0c/unit): they make ~nothing, so dropping them changes P&L by ~0.
- **Inventory skew:** no consistent pattern; worth maybe ~$100/day. Noise-level. Rejected.

## Conclusion
Fruit edge is ~0.3-0.6c/unit, set by adverse selection, not quote width. No tested fruit change gets near +$200/hr, so fruit
cannot close the option speed gap. Options earn ~13x fruit per hour; the priority is options robustness (a working
off-switch) and consistency.
