# Step 5 findings: pre-build exploration and simulator

Script: `05_simulator.py`. Chart: `charts/20_simulated_market_making.png`. Uses the 36 sample days, plus all 182 days for option outcomes.

## Read this first: what the $ numbers mean
The simulator replays history with our quotes and orders added. **Absolute dollars are an upper bound**, because:
- **The market maker's price path is replayed unchanged.** If flow trades with us instead of the market maker, its price would really move less.
- **There's no competition.** Other teams will quote 1c inside too and split the flow.
- **The option market maker is assumed passive.** We assume it doesn't react to our trades and refills 50 lots at the touch.

**What is reliable:** the comparisons between variants (mid vs Kalman, with vs without the settle nudge, historical vs random flow) and the per-unit and per-contract edges.

## 1. How the option market maker prices
- **Model:** the quote fits **P(up) = Φ((smoothed ETF − strike) / (σ·√time left))**, with σ ≈ 1.55c/√s. The ETF is smoothed over roughly 20–40s.

  | ETF input the quote is fitted to | R² |
  |---|---|
  | live ETF mid | 0.85 |
  | 20s moving average of the ETF | 0.93 |

- **Why it's beatable** (all three are things our model accounts for):
  1. It ignores **settle noise**, so it's overconfident.
  2. It **lags the ETF by about 10–20s**, so its quotes are stale after moves.
  3. It ignores the ETF's **drift toward the basket**.
- **It doesn't react to option trades:** about 0.01c per contract, so it's effectively passive. Its quote changes in only 27% of seconds (5-minute) and 9% (60-minute).
- **Book:** 50 lots at the touch, usually 7c wide.
- **Depth beyond the touch:** fill prices beyond the touch, by trade size:

  | trade size | extra cost vs touch |
  |---|---|
  | 30 contracts or fewer | ~0c |
  | 60–80 | ~0.5c |
  | 80+ | ~1c |

  **Practical capacity is about 50–100 contracts per signal.**
- **Market volume:** about 800 contracts per 5-minute window and about 2,600 per 60-minute window.

## 2. Option quotes at the open
- **The market does react to the strike at the open,** but not enough. The correlation between the open mid and our model is 0.84.
- **The model–market gap is about 7.5–8.7c at every point in the window.** There's no special free window right at the open; the edge is spread across the whole window.

## 3. Option edges are stable (checked across months)
- **Strike bias:**

  | month | Jan | Feb | Mar | Apr | May | Jun |
  |---|---|---|---|---|---|---|
  | P(up), strike set more than 5c below the mid | 0.66 | 0.64 | 0.64 | 0.64 | 0.62 | 0.66 |
  | P(up), strike set more than 5c above the mid | 0.35 | 0.36 | 0.36 | 0.38 | 0.37 | 0.36 |

- **Streak effect (all 182 days):** P(up | previous window up) was 0.42–0.45 in every month.

## 4. Settle second
- **Other trades in the close second:** another ETF trade happens in the 5-minute close second 27.7% of the time, the same as any other second (27.3%). The historical bots don't target the close.
- **Implication:** a late 1-lot from us becomes the settle about 72% of the time. That rate will fall if other teams do the same.

## 5. Simulated option strategy
Take when |model − touch| > 5c, with at most 50 contracts held per window (reversing allowed).

| | mean daily $ | sd | score | contracts/day |
|---|---|---|---|---|
| 5m | 5,575 | 435 | 5,140 | 70.6k |
| **5m + settle nudge** | **6,541** | **422** | **6,119** | 70.6k (about 20 flips/day) |
| 60m | 635 | 187 | 448 | 9.6k |
| 60m + nudge | 653 | 192 | 461 | |

- **Edge per contract:** about 8c after reversals.
- **Scale:** in this model PnL grows roughly in line with the position cap (20 → 50 → 100 contracts). In reality, other teams and the option market maker reacting will limit it.
- **Settle nudge:** adds about 17% to 5-minute PnL and slightly lowers the standard deviation.

## 6. Simulated fruit and ETF market making
Setup: quote 20 lots, 1c inside the market maker, lean 0.03c per unit of inventory, inventory cap ±300. The ETF uses 5 lots, a ±5c half-width and a ±50 cap.

| score $/day | centre on mid | centre on Kalman fair |
|---|---|---|
| apples | 2,374 | **4,767** |
| bananas | 2,494 | **4,974** |
| oranges | 2,611 | **4,887** |
| strawberries | 3,064 | **4,860** |
| watermelon | 765 | **2,391** |
| ETF | 1,681 | **1,825** (sum of fruit fairs) |

**Random-flow stress test** (trade directions shuffled, market maker price rebuilt from its per-unit rule):

| score $/day | centre on mid | centre on Kalman fair |
|---|---|---|
| fruits | about **2,800 each** (watermelon 1,290) | 600–2,000, watermelon **negative** |
| ETF | **2,159** | negative* |

\* In the random-flow test the ETF and fruit prices are generated independently, which overstates how badly the ETF does here.

- **Decision rule confirmed:** if live flow still snaps prices back, centre on the Kalman fair (about 2× profit). If it's random, centre on the mid; Kalman centring then loses money.
- **The fruit volume in the simulator** (about 300k units/day per fruit, roughly a third of all volume) is the least realistic number. Expect much less once other teams compete.
- **Capital:** inventory caps of ±300 per fruit is about $3k per fruit at $10–13 each. Check this against the margin rules once they're published.

## 7. Combining strategies (lower risk)
Daily PnL correlations are low or negative. Fruit market making is −0.28 against 5-minute options and −0.36 against 60-minute options.

| | mean | sd | score |
|---|---|---|---|
| all four strategies combined | $32.2k | $675 | **$31.5k** |
| sum of their separate scores | | | $30.8k |

**Run all strategies together.** Combining them lowers the variance more than it costs.

## 8. End of day
- **Late-evening volatility:** ETF 5-minute moves in 23:xx windows are 42c (sd) vs 31c on average. The midnight volatility peak lines up with the day reset.
- **Plan:** flatten fruit inventory and avoid new 60-minute option positions in the last hour before the reset, unless we learn the reset time is different.

## Still open (needs the organisers or the live exchange)
- **Fees and margin:** the ETF create/redeem fee, plus margin and short-selling rules.
- **Exchange API:** order types, how orders are timestamped within a second, and rate limits.
- **Competition:** how much flow and option edge survives once every team is quoting.
- **Live flow check:** whether live flow is informed (the variance ratio test).
