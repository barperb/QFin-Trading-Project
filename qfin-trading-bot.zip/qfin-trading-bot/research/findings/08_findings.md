# Step 8 findings: the late-push bug, early vs late option entries, competitors, the final test, and v9.2

**Data:**
- Live market data to 15:59 UTC on Oct 10 (downloaded at 15:59). Earlier days are as in step 7.
- Our own fills for Oct 10 to 16:07 UTC.
- The positions board and volume matrix at 15:55 UTC.
- The team P&L history to 13:27 UTC.
- 15 historical days.

**Tools:** the scripts are in `bot_v9_2/tools/`.

## 1. v9 / v9.1 lost windows to its own late print

v9 ran from 13:10 UTC. In that time we held long UP in 34 five-minute windows, and UP won 17 of them. We printed in the close second in 20 windows and won 13 (65%). The bot's own log reads "late pushes sent 15, won 10".

In 6 windows, our late push's last print was below the strike, and that print became the settle:

| close (UTC) | UP held | strike | our early print (close − 0.94 s) | other trades after it | our late print = settle |
|---|---|---|---|---|---|
| 14:15 | 550 | 56.14 | 56.14 | sell 16 @ 55.994 in the close second | 56.086 |
| 14:25 | 500 | 56.10 | 56.10 | sell 19 @ 55.969 in the second before | 56.095 |
| 14:55 | 500 | 56.25 | 56.26 | none | 56.21 |
| 15:30 | 500 | 55.57 | 55.58 | none | 55.56 |
| 15:50 | 500 | 55.44 | 55.44 (a tie counts UP) | none | 55.402 |
| 16:05 | 290 | 55.90 | 55.91 | no public data yet | 55.85 |

- **What it cost:** 2,840 contracts, about $2.8k of payout, in under 3 hours.
- **Three were already won.** At 14:55, 15:30 and 15:50 the early push had won and nobody else traded. The late push alone flipped the result.

**Cause:**
- The early push takes the ETF asks below the strike, and the house refills them within the next 0.7 s.
- The late push's walk order was limited to the last level we had seen, so the refilled asks survived it.
- The 1-unit print order and the resting "wall" (a bid at the strike) then bought those asks below the strike.
- The exchange records each order's average fill price as one trade, so our last order's average became the settle.

**v9.2 fix:**
- The walk (order A) is limited to the last tick below the strike, and it can take 30 units more than it saw. It clears every level below the strike but never buys at or above it.
- The 1-unit print (order B) may fill up to 40c past the strike.
- The walls go first in the batch, so A and B override any print a wall makes against a stale level.
- If margin would clip A, nothing is sent: no print is better than a wrong print.
- The early push gets the same limits.

**Test:** a small matching engine replays these books against both batches. v9.1's last print lands below the strike; v9.2's lands above it, and the DOWN side mirrors this.

## 2. Option entries: too early, so pickier

**v9.1 spends its cap in the first minute.** It bought on average 481 contracts per 5m window, and 465 of them were bought with more than 60 s left.

Our 5m take fills by time left (v9 hours):

| seconds left | contracts | avg price | win rate | ¢ per contract |
|---|---|---|---|---|
| 240–300 | 11,472 | 48.9c | 60% | +11.4 |
| 180–240 | 1,579 | 37.9c | 11% | −26.5 |
| 120–180 | 2,081 | 46.4c | 59% | +12.8 |
| < 120 | 640 | – | – | −$266 in total |

**What the replay says.** The replay uses our live option books: it takes at the touch when model − ask beats the edge, with a 500 cap and real outcomes. It shows the cap is better saved for later in the window. 5m P&L:

| early edge (>60 s left), 10c after | Oct 7 | Oct 8 | Oct 9 | Oct 10 (to 10:30) | total | Oct 10 to 15:54 |
|---|---|---|---|---|---|---|
| 10c (v9.1) | −$0.4k | $17.8k | $12.5k | $10.6k | $40.6k | $11.6k |
| 15c | $2.1k | $20.8k | $14.2k | $11.3k | $48.4k | $12.6k |
| **20c (v9.2)** | $5.7k | $23.6k | $15.1k | $10.8k | **$55.1k** | $12.3k |
| 25c | $8.0k | $25.4k | $16.8k | $10.3k | $60.4k | $11.7k |
| 30c | $8.2k | $24.1k | $15.4k | $9.6k | $57.4k | – |

- **5m: 20c early.** It beats 10c on every day. 25c totals more, but the best early edge has been drifting down (Oct 10 prefers 15–20c).
- **60m:** 10c with more than 10 minutes left and 5c after, versus 5c throughout: $2.0k → $3.0k, better on all 4 days.
- **Historical backtest** (flat edges, 4 days): 25c beat 10c on all 4.

**Not built: selling UP late (holding DOWN).** It's mixed by day. For example, selling at ≥30c of edge at any time changed P&L by +$7.6k / +$1.3k / −$4.8k / −$1.7k on Oct 7 / 8 / 9 / 10. It gets worse as more teams push UP at the close.

## 3. Other teams

**P&L change per ~200 s snapshot interval, Oct 8–10.** 5m closes only; intervals containing a top-of-hour close are removed:

| team | no close | close, UP won | close, DOWN won |
|---|---|---|---|
| kai | +$33 | +$27 | +$89 |
| T4 | +$30 | +$43 | +$24 |
| Spudtrading | +$13 | +$61 | +$10 |
| **tacof (us)** | **+$3** | **+$107** | **−$78** |
| KnightCapital | $0 | +$80 | −$34 |
| Group 8 | +$6 | +$13 | +$10 |

**We are a one-way UP bet.** kai and T4 earn whichever way the window settles, and also earn steadily between closes, about $30 per interval, or ~$500 an hour. Our between-close P&L is about $3 per interval.

**Hourly P&L, mean − sd** (the final test scores daily P&L, and its days are 60 minutes; see §4):

| team | Oct 8–10 | Oct 10 only |
|---|---|---|
| Group 8 | +$70 (mean $171, sd $101) | +$40 |
| T4 | −$296 | **+$467** (mean $1,572, sd $1,106) |
| kai | −$10 | −$466 |
| **tacof (us)** | −$393 (mean $329, sd $722) | −$37 (mean $753, sd $790) |

**Positions board at 15:55 UTC:**
- **T4** holds +500 up5, the same side as us, so it helps our UP pushes.
- **qfingroup3** holds +484 up5.
- **T44** holds +150 up5 and −400 up60.
- **KnightCapital** holds +500 up60.
- **kai** holds only −207 ETF.

**Volume matrix.** T4 sold $697 to house-flow (uninformed) but only $53 to house-informed, about 13:1. For us the ratio is 2.5:1 ($823 vs $326). T4's market making avoids the informed bot. This is worth copying next: track the matrix over time and look at when T4 quotes.

## 4. The final test is 20 days of 60 minutes

**What the config says:** the exchange config gives `backtestDays 20`, `backtestDayMin 60`. Live days are `dayLengthMin 1440`.

**Score:** mean − sd of those 60-minute daily P&Ls.

**Our option book is close to break-even on that score.** In the replay with v9.2 edges and a 500 cap, its hourly mean ÷ sd by day was −0.07 / 0.27 / 1.08 / 0.77 / 1.40 (Oct 6–10). The score is positive only above 1, so changing its size barely moves the expected score.

**The 60m window is the clear risk.** In a 60-minute day it is a single coin flip of up to 500 contracts. Cutting it to 200 contracts improved the hourly score on 3 of the 5 days and cost a little on the other 2.

**v9.2 change for short days:** when the day is 180 minutes or shorter, the bot scales the 60m caps by 0.4 (200 contracts) and 15m by 0.6. It reads the day length from `config["dayLengthMin"]`, or from the gap between two day ends. Live days (1440 minutes) are unchanged.

**Market making is the steady part.** From our fills it makes about $74 an hour, sd about $42. A T4-style version that avoids house-informed is the most promising route to a positive final score.

## 5. Strawberry knowledge, used

**Built: 2-hour reversion on all fruits.** The strawberry buyer's push is given back over ~2 hours, and every fruit shows the same give-back:

    next-2h move = −0.27 … −0.35 × (mid now − mid 2 h ago)

That holds on 15 historical days plus live Oct 6–10.
- **Rule:** target inventory = expected move ÷ 15c × 75, capped at ±75.
- **Minute-grid sim:** live $311–423/day, historical $422–633/day, positive on every day (5 live, 15 historical).
- **In v9.2:** capped at 60 units per fruit (30 for watermelon), steering the normal quotes.
- **Backtest:** +$506/day, positive on all 4 days.

**Real-time size-150 detection: not possible from the book.**
- **No tape:** the pipe state carries only `lastTradePrice`.
- **Jump proxy fails:** a 1 s mid jump of 5c or more with an aggressive last trade catches the buyer only 5–12% of the time.
- **Following jumps loses:** fruit jumps revert. Live, an apples 1 s jump of 5c or more (6.8c on average) gives back 3.5c within 60 s, and a 10c+ jump gives back 8.6c of 12.4c. Strawberries give back less (1.7c of 7.0c).
- **Our quotes already cope.** Our maker fills right after a 5c+ move in our trade's direction lose only 0.18c a unit (7k units, −$13), against +0.72c overall, so mid-mode quoting doesn't need a jump lean.

## 6. v9.2 results and what's next

**Historical backtest** (4 days, `--share 0.25 --mode mid`): v9.2 makes $59,496/day (sd $2,878) against v9.1's $55,273 (sd $1,753), and it's better on all 4 days. The gain comes from:
- 5m takes: +$1.9k
- resting 5m quotes: +$1.6k (an optimistic fill model)
- 2-hour reversion: +$0.5k

The push fix can't be measured in the backtest. Live, it is worth roughly 2 windows an hour at the rate seen on Oct 10.

**Next:**
1. Watch the v9.2 late-push lines and its win rate (v9.1: 10 of 15).
2. Find out how T4 avoids house-informed; this is the market-making edge that scores well in 60-minute days.
3. Revisit selling UP late (holding DOWN) if the close-second fights tilt back toward DOWN.
