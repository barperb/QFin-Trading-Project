# Step 11 findings: 5m UP model and entry research (Oct 12), and v12

**Data:** live books, the public option tape, our fills and settled windows for Oct 6–12.

## Close-second check (Oct 11 and Oct 12)
- **Our late push** wins 96% of 5m windows when we send it (Oct 11) and 100% (Oct 12, 58 of 58). Every 5m loss on Oct 12
  was a window where the strike was out of reach.

## The regime changed on Oct 11–12
UP now wins much more than the hand model says:

| hand model value | actual UP rate, Oct 11 | actual UP rate, Oct 12 |
|---|---|---|
| 0.5–0.7 | 0.80 | 0.85 |
| 0.3–0.5 | 0.48 | 0.67 |

Refitting the push parameters (push weight 0.95, reach 15–20c) cuts log-loss from 0.39 to 0.34 (Oct 11) and from 0.45 to
0.36 (Oct 12). Gradient-boosting and logistic models did not beat the hand model out of sample.

## Better-calibrated values lose money
Trading on the recalibrated values loses about $3.5k/day on Oct 11. It buys earlier and pays more, because the 500 cap
binds. The conservative hand model works as a price filter, so we keep it.

## Also rejected
- **Dumping hopeless UP late:** −$1k to −$11k.
- **Shorting:** every setting was negative on Oct 11–12.
- **Looser trims:** about +$300/day, which is within noise.

## v12: change the 5m resting bid
v11 rested 10 contracts 3c under value. v12 rests 25 contracts 15c under value. Replay against v11's setting:

| day | gain |
|---|---|
| Oct 8 | +$1.6k |
| Oct 9 | +$1.8k |
| Oct 10 | +$2.2k |
| Oct 11 | +$3.1k |
| Oct 12 (part day) | +$0.6k |

Live check that supports it: v11's maker buys earn 27–30c a contract, and its taker buys about 39c.
