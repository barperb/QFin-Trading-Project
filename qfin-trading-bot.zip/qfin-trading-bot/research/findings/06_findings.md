# Step 6 findings: strawberry big buyer, activity U-shape, option skew and kurtosis

Scripts: `06_scripts/` (see its README). Charts: `charts/21_strawberry_informed_buyer.png`, `22_activity_u_shape.png`, `23_option_skew_kurtosis.png`.

**Samples**
- Trades: 31 historical days (every 6th day).
- Top of book and option books: 15 historical days (every 12th day).
- Live: Oct 8 (full day) and Oct 9 (about 5 hours). Live results rest on 2 days, so treat them as direction, not size.

## 1. Strawberries: there is a one-sided informed buyer, and it trades size 150

**What Harper saw is real.** Runs of 100+ lot strawberry *buys* keep pushing the price up for minutes. The runs are more than chance: there are 68 runs of 5 or more, against about 25 if trade sides were random. The cleanest fingerprint is a print of **exactly size 150**:

| strawberries, size = 150 | buys/day | sells/day | mid after the print (from 2s before) |
|---|---|---|---|
| historical | 28 | 2 | +10c in the print second, **+25c at 10s, +40c at 2 min**, flat after |
| live Oct 8–9 | 19.5 | 1 | same shape (chart 21, left) |

**Tradeable version:** buy at the ask 1 second after the print and mark to mid later.

| | n/day | P&L at 60s | P&L at 5 min | hit rate at 60s |
|---|---|---|---|---|
| historical | 28 | **+23.9c/unit** | +25.9c | 97% |
| live | 19.5 | **+22.6c/unit** | +18.6c | 95% |

Waiting 2 seconds instead of 1 costs only about 2c, so the bot's 1-second loop is fast enough.

**The runs, split by side** (100+ lots, same side, gaps ≤ 2 min; next-5-min move in the trade direction; chart 21, right):

| k-th trade in run | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| buy runs (historical) | −1.9c | +6.2c | **+14.2c** (t = 7.7) | **+17.5c** (80% hit) | +13.9c |
| sell runs (historical) | −6.6c | −8.4c | −8.1c | −10.0c | – |

- **Only buys carry information.** Sell runs reverse like ordinary big trades (the step 2 "fade 50+ trades" rule).
- **Historical halves agree:** for the 5th trade in a run (80+ lot version, both sides), Jan–Mar +6.1c and Apr–Jun +8.5c at 5 min.
- **Timing:** these runs follow the U-shape below. 151 size-150 buys land in minutes :00–:04, against 20 in :30–:34.

**Size 150 is an informed-bot size in the other fruits too:**
- **Apples, bananas, oranges:** it's mostly sells, and following them pays +9 to +20c historically. Live apples sells come 16.5 a day at +28.6c.
- **Watermelon:** size 150 is noise and reverses 25–35c within 5 minutes, which fits step 3's "watermelon jumps reverse".

**What this means for the bot** (nothing in `strategy.py` uses this yet):
1. **Defence (cheapest, do first).** When a size-150 strawberry buy prints, pull or raise our strawberry asks for about 2 minutes. Otherwise our resting asks get lifted just before a 25–40c move.
2. **Follow.** In the next second, send an IOC buy for up to about 30–50 units, or raise the strawberry target inventory, then unwind passively over 2–5 minutes.
   - Price impact is about 0.06c per unit, so 50 units costs about 3c, a small part of the 24c edge.
   - At about 20 signals a day and 30–50 units each, that's roughly **$150–250/day live**. It's worth having, but small next to the options.
3. **Generalise as a rule:** follow size-150 prints in apples, bananas, oranges and strawberries, and fade them in watermelon.
4. **The `big_moves` feature** ("follow strawberry jumps") is off and was neutral in the backtest. A size-150 trigger is a much sharper version of it.

**Caveat:** the live market includes other teams. If someone else also follows these prints, the move gets front-run and the edge shrinks.

## 2. Activity U-shape: confirmed live

| minute of hour | :00–04 | :10–14 | :25–34 | :50–54 | :55–59 |
|---|---|---|---|---|---|
| volume ÷ average, historical | 1.60 | 0.97 | 0.66 | 1.22 | 1.64 |
| volume ÷ average, live | 1.68 | 1.01 | 0.66 | 1.15 | 1.51 |

- **Minute of hour:** the top of the hour is about 2.5× as busy as the half hour, historically and live. Option volatility follows the same pattern (it's already in `option_params.json`).
- **Hour of day:**
  - **Historically,** 23:00–01:00 UTC (7–9 am Perth) is the busiest, 1.5–1.8× normal.
  - **Live,** 00:00–02:00 UTC is again the peak (1.6×). The live 23:00 hour has only one sample, so it's not reliable yet.
- **What it means:**
  - Informed flow (the strawberry buyer, and the size-30 ETF bot in step 2) bunches at the top of the hour, so quotes should be widest and size-150 alertness highest then.
  - The half hour is the quietest time for inventory to sit.

## 3. Option skew and kurtosis: is there money in the shape?

**What the options are.** They're binary up/down options on the ETF's last trade, and P(up) depends only on the distribution of the ETF move.

### Realised moves (strike → settle; windows opening at 00:00 UTC removed, since with every-6th-day sampling their strike came from a day not loaded)

| | n | skew [95% CI by day] | excess kurtosis [95% CI] | P(up) |
|---|---|---|---|---|
| 5m, raw | 8,897 | −0.13 [−0.23, −0.04] | 1.36 [1.04, 1.68] | 0.504 |
| 5m, adjusted for the minute/hour vol profile | | −0.12 | **0.86** [0.63, 1.13] | 0.504 |
| 60m, adjusted | 713 | −0.24 [−0.41, −0.08] | 0.00 [−0.32, 0.38] | 0.540 [0.51, 0.57] |

- **5m:** the moves are close to normal.
  - About a third of the raw kurtosis is just the U-shape: a mix of busy and quiet minutes.
  - What's left is a slightly tall middle (25th/75th percentiles at ±0.61 sd vs ±0.67 for a normal) and slightly fat tails (1% / 99% at −2.54 / +2.45 vs ±2.33).
  - There's no useful skew: P(up) is 0.504.
- **60m:** there's mild negative skew (small rises are more common, big falls rarer), but no excess kurtosis.
  - P(up) of 0.54 here is above the 50.8% found across all 182 days in step 3. Read it as sample luck, not a stable bias.

### Implied vs realised

**Implied:** the market's quotes fit a plain normal: the best-fitting Student-t has infinite degrees of freedom, so the quotes imply **zero kurtosis and zero skew**.

**Realised:** tail thickness comes from the log-loss of outcomes, with settle noise included.

| | best tail fit (Student-t) | log-loss gain over normal |
|---|---|---|
| 5m historical | ν ≈ 10–30 (almost normal) | 0.0001 (none) |
| 60m historical | **ν ≈ 6–10** | 0.0012 |

Chart 23 shows the market error by moneyness. For 5m, the existing normal + settle-noise model (green) already explains the whole gap between outcomes and quotes (blue). The bot already captures that gap: the "fat tails" near expiry are the settle noise.

### Does pricing in the shape make money? (take when |fair − touch| > 5c, hold to expiry, every 5s)

| fair-value model | 5m historical | 60m historical | 5m live |
|---|---|---|---|
| normal + settle noise (≈ current bot) | 10.6c/contract, 15/15 days up | 10.0c, 9/15 days | 8.9c |
| + fat tails (t, ν = 8) | 11.0c, 15/15 | **12.0c, 11/15** | 8.7c |
| + fat tails + up-skew (0.1 sd) | 9.1c (worse) | 12.3c, 12/15 | **15.1c** |

**Verdict:**
- **Kurtosis:**
  - **5m:** not worth adding, a gain of about +0.3c per contract, which is noise.
  - **60m:** a t-distribution with ν ≈ 8 adds about +2c per contract and makes more days positive. Deep out-of-the-money 60m UPs (ETF more than 2 sd below the strike) win 4.9% of the time against a 3.5c market mid.
  - **Change:** it's a small but cheap one in `models.py`, for 60m only.
- **Skew:**
  - **Historically:** there's none to trade in 5m.
  - **Live:** 5m outcomes are strongly skewed UP. P(up) is 0.67 when the ETF is at the strike, and live 5m UP won 59% of 337 windows.
  - **Cause:** the close second. When the ETF mid is 0–10c *above* the strike 5 seconds before the close, DOWN wins only **9%** live against 40% historically. The settle prints about +1.6c above the mid.
  - **What that means:** someone (our settle push, plus other teams long UP) defends UP at the close. This is the same effect behind v5's `settle_bias` and v6's "never sell 5m UP". The table shows it's worth about +6c per contract live.
  - **The catch:** it's not a property of the ETF. It lasts only while the UP side wins the close, and it disappears or flips if a team starts pushing DOWN. Keep it as a live-calibrated bias (as `LIVE.settle_bias` already is) and watch it daily rather than hard-coding a skew.

**Bottom line on options:**
- The profit is real (about 9–11c per contract historically and live), but it comes from settle noise, quote lag, ETF drift and, live, the close-second push.
- Skew and kurtosis of the ETF itself add little: 60m fat tails (about +2c per contract) are the only change worth making.

## Next steps
1. Add a `size150` signal to `strategy.py`: on a strawberry 150 buy, pull asks and follow for 2–5 minutes. Then follow the other fruits and fade watermelon. Backtest with `--share 0.25`.
2. For 60m only, switch the option model's normal CDF to a Student-t with ν ≈ 8, then re-check on held-out days.
3. Daily live check: the 5m P(up) when the ETF sits just above the strike 5s before the close (9% DOWN now, 40% historically). If it drifts back toward 40%, the push edge is being contested.
